export type Currency = {
    img: string
    symbol: string
    backdropIcon: string
    format: (value: number) => string
    formatNoLabel: (value: number) => string
}

export function numberWithCommas(x: number) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

export function fiatWithCommas(x: number) {
    return x.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

export const currencies: Map<string, Currency> = new Map();
currencies.set('OSRS', {
    img: 'osrs.png',
    backdropIcon: '/assets/gp.png',
    symbol: '',
    format: (value: number) => {
        return toRuneScapeFormatFromDecimal(value ?? 0) + ' OSRS';
    },
    formatNoLabel: (value: number) => {
        return toRuneScapeFormatFromDecimal(value ?? 0);
    }
})
currencies.set('RS3', {
    img: 'rs3.png',
    backdropIcon: '/assets/gp.png',
    symbol: '',
    format: (value: number) => {
        return toRuneScapeFormatFromDecimal(value ?? 0) + ' RS3';
    },
    formatNoLabel: (value: number) => {
        return toRuneScapeFormatFromDecimal(value ?? 0);
    }
})
currencies.set('GBP', {
    img: 'british-pound-currency.svg',
    backdropIcon: '/assets/currencies/british-pound-currency.svg',
    symbol: '£',
    format: (value: number) => {
        return fiatWithCommas(value);
    },
    formatNoLabel: (value: number) => {
        return fiatWithCommas(value);
    }
})
currencies.set('USD', {
    img: 'dollar-currency.svg',
    backdropIcon: '/assets/currencies/dollar-currency.svg',
     symbol: '$',
    format: (value: number) => {
        return fiatWithCommas(value);
    },
    formatNoLabel: (value: number) => {
        return fiatWithCommas(value);
    }
})
currencies.set('EUR', {
    img: 'eur-currency.svg',
    backdropIcon: '/assets/currencies/eur-currency.svg',
    symbol: '€',
    format: (value: number) => {
        return fiatWithCommas(value);
    },
    formatNoLabel: (value: number) => {
        return fiatWithCommas(value);
    }
})
currencies.set('BTC', {
    img: 'btc.svg',
    backdropIcon: '/assets/currencies/btc.svg',
    symbol: '₿ ',
    format: (value: number) => {
        return value.toFixed(3);
    },
    formatNoLabel: (value: number) => {
        return value.toFixed(3);
    }
})
currencies.set('ETH', {
    img: 'eth.png',
    backdropIcon: '/assets/currencies/eth.png',
    symbol: 'Ξ ',
    format: (value: number) => {
        return value.toFixed(3);
    },
    formatNoLabel: (value: number) => {
        return value.toFixed(3);
    }
})

export function toRuneScapeFormatFromExact(value: number): string {
    const negative = value < 0;
    if (negative) {
        value *= -1;
    }
    if (value >= 1_000_000_000) {
        const amountLeftOver = value % 1_000_000_000
        if (amountLeftOver > 100_000_000) {
            return (negative ? "-" : "") + (value / 1_000_000_000).toFixed(1) + 'B'
        }
        return (negative ? "-" : "") + (value - amountLeftOver) / 1_000_000_000 + 'B'
    }
    if (value >= 10_000_000) {
        const amountLeftOver = value % 1_000_000
        return (negative ? "-" : "") + (value - amountLeftOver) / 1_000_000 + 'M'
    }
    if (value >= 1_000_000) {
        const amountLeftOver = value % 100_000
        if (amountLeftOver == 0) {
            return (negative ? "-" : "") + (value / 1_000_000).toFixed(0) + 'M'
        }
        return (negative ? "-" : "") + ((value - amountLeftOver) / 1_000_000).toFixed(1) + 'M'
    }
    if (value >= 1_000) {
        const amountLeftOver = value % 1_000
        return (negative ? "-" : "") + ((value - amountLeftOver) / 1_000) + 'K'
    }
    return (negative ? "-" : "") + value.toString()
}

export function toRuneScapeFormatFromDecimal(decimal: number) {
    return toRuneScapeFormatFromExact((decimal / 0.01) * 10_000)
}