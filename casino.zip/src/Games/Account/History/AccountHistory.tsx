import React, {Component} from 'react';
import {axiosGet} from "../../../Utilities/HTTPClient";
import {AccountHistoryResponse} from "../../../API/Account/AccountHistoryResponse";
import {getLoadingBar} from "../../../Utilities/LoadingBar";
import {formatDateTime} from "../../../Components/Timeline/Timeline";
import {currencies} from "../../../Utilities/Currencies";

type HistoryState = {
    history?: AccountHistoryResponse
    transactionPageNumber: number
    wagerPageNumber: number
}

class AccountHistory extends Component<any, HistoryState> {

    constructor(props: any) {
        super(props);
        this.state = {
            transactionPageNumber: 0,
            wagerPageNumber: 0,
        }
        this.pageNumbers = this.pageNumbers.bind(this)
    }

    getAccountHistory = async (transactionPage: number, wagerPage: number): Promise<AccountHistoryResponse> => axiosGet(`/admin/auth/history?transaction=${transactionPage}&wager=${wagerPage}`)

    componentDidMount() {
        this.getAccountHistory(this.state.transactionPageNumber, this.state.wagerPageNumber).then((history: AccountHistoryResponse) => {
            this.setState({history: history})
        }).catch(e => {
            //@ts-ignore
            window.location.href = 'https://shane.onyxtechnology.co.uk/'
        })
    }

    pageNumbers(count: number, transactions: boolean): JSX.Element {
        const length = count / 25;
        let vals = []
        for (let i = 0; i < length; i++) {
            vals.push(i + 1)
        }
        return <div className="Pagination">
            <ul className="PageNumbers">
                {
                    vals.map((val, key) => {
                        const selected = key === (transactions ? this.state.transactionPageNumber : this.state.wagerPageNumber);
                        return <li className={`PageNumber ${selected ? 'Selected' : ''}`} onClick={()=> {
                            let changes: any;
                            if (transactions) {
                                changes = {transactionPageNumber: val - 1}
                            } else {
                                changes = {wagerPageNumber: val - 1}
                            }
                            if (changes) {
                                this.setState({
                                    ...changes
                                }, () => {
                                    this.getAccountHistory(this.state.transactionPageNumber, this.state.wagerPageNumber).then((history: AccountHistoryResponse) => {
                                        this.setState({history: history})
                                    }).catch(e => {
                                        //@ts-ignore
                                        window.location.href = 'https://shane.onyxtechnology.co.uk/'
                                    })
                                })
                            }
                        }}>{val}</li>
                    })
                }
            </ul>
        </div>
    }

    render() {
        if (!this.state.history) {
            return (
                <div className="AltContainer">
                    <div className="AccountActivity">
                        {getLoadingBar(true, "Fetching Information...")
                        }
                    </div>
                </div>)
        }
        return (
            <div className="AltContainer">

                <div className="TransactionHistory">
                    <div className="TransactionTable">
                        <div className="MetricSplash">
                            <div className="MetricSplashFilter">
                                <div className='performance_title'>Transaction History
                                </div>
                                <select>
                                    <option>All Time</option>
                                </select>
                            </div>
                            <div className="TableHeader">
                                <ul>
                                    <li style={{width: '200px'}}>Date</li>
                                    <li style={{width: 'calc(100% - 800px)'}}>Description</li>
                                    <li style={{width: '150px'}}>Amount</li>
                                    <li style={{width: '150px'}}>Status</li>
                                    <li style={{width: '300px'}}>Balance Change</li>
                                </ul>
                            </div>
                            {
                                this.state.history.transactions.map((e, i) => {
                                    return (<ul className="TableValueRow">
                                        <li style={{width: '230px'}}>20th March 2023</li>
                                        <li style={{width: 'calc(100% - 650px)'}}>Withdrawal of balance.</li>
                                        <li style={{width: '150px'}}>£30.29</li>
                                        <li style={{width: '150px'}} className="Status">Pending</li>
                                        <li style={{width: '300px'}}>£0.00 <span>£-30.29</span></li>
                                    </ul>)
                                })
                            }
                            {
                                this.pageNumbers(this.state.history.totalTransactions, true)
                            }
                        </div>

                        <div className="MetricSplash">
                            <div className="MetricSplashFilter">
                                <div className='performance_title'>Wager History
                                </div>
                                <select>
                                    <option>All Time</option>
                                </select>
                            </div>
                            <div className="TableHeader">
                                <ul>
                                    <li style={{width: '200px'}}>Date</li>
                                    <li style={{width: 'calc(100% - 800px)'}}>Game</li>
                                    <li style={{width: '150px'}}>Amount</li>
                                    <li style={{width: '150px'}}>Result</li>
                                    <li style={{width: '300px'}}>Balance Change</li>
                                </ul>
                            </div>
                            {
                                this.state.history.wagers.reverse().map((wager, i) => {
                                    return (<ul className="TableValueRow">
                                        <li style={{width: '230px'}}>{ formatDateTime(wager.date) }</li>
                                        <li style={{width: 'calc(100% - 650px)'}}>{wager.game}</li>
                                        <li style={{width: '150px'}}>{currencies.get(this.props.currency)!!.symbol + currencies.get(this.props.currency)!!.format(wager.amount)}</li>
                                        <li style={{width: '150px'}} className={`Status ${wager.change > 0 ? 'Success' : 'Error'}`}>{wager.change > 0 ? 'Won' : 'Lost'}</li>
                                        <li style={{width: '300px'}}>{currencies.get(this.props.currency)!!.symbol + currencies.get(this.props.currency)!!.format(wager.newBalance)} <span className={`${wager.change > 0 ? 'Success' : 'Error'}`}>{wager.change < 0 ? '-' : ''}{currencies.get(this.props.currency)!!.symbol + currencies.get(this.props.currency)!!.format(wager.change * (wager.change < 0 ? -1 : 1))}</span></li>
                                    </ul>)
                                })
                            }
                            {
                                this.pageNumbers(this.state.history.totalWagers, false)
                            }
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}


export default AccountHistory;