import Draggable from "react-draggable";
import {toRuneScapeFormatFromDecimal} from "../../../Utilities/Currencies";
import React from "react";
import {Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, YAxis} from "recharts";

export const gameModal = (
    show: boolean,
    closeModal: any,
    resetData: any,
    earnings: number,
    wins: number,
    losses: number,
    showHistoryChart: boolean,
    winningsData: Array<any>,
): JSX.Element => {
    return (<Draggable>
            <div className={`modalhistory ${show && "active"}`} draggable="true">
                <div className="history-header">
                    <p>Live Stats</p>
                    <span onClick={() => closeModal()}>&times;</span>
                </div>
                <div className="history_container">
                    <div className="select">
                        <select className="history-select">
                            <option>All Time</option>
                            <option>1 Min</option>
                            <option>15 Min</option>
                            <option>1 Hour</option>
                        </select>
                        <div>
                            <img src="/assets/games/refresh.svg" alt="" onClick={() => resetData()} />
                        </div>
                    </div>
                    <div className="first">
                        <div>
                            <p>Net Gain</p>
                            {earnings >= 0 ? <span className="success text-green">{toRuneScapeFormatFromDecimal(Math.abs(earnings))}</span> :
                                <span className="success text-red">-{toRuneScapeFormatFromDecimal(Math.abs(earnings))}</span>}
                            <p>Amount</p>
                            <span>{earnings.toFixed(1)}</span>
                        </div>
                        <div>
                            <p>Wins</p>
                            <span className="success">{wins}</span>
                            <p>Losses</p>
                            <span className="error">{losses}</span>
                        </div>
                    </div>
                    <div className="second">
                        {/* <span className="success">{this.state.gain}</span> */}
                        {
                            showHistoryChart &&
                            <HistoryChart winningsData={winningsData} />
                        }
                    </div>
                    <div className="third">
                        <p style={{ color: 'white' }}>Provably fair Roulette.</p>
                        {/* <option value="">{this.state.gain} SC Race - 24 Hours</option> */}
                        {/* <div>
                <div>
                  <SemiCircleProgressBar
                    percentage={this.state.percent}
                    stroke="rgb(0, 208, 132)"
                    strokeWidth={4}
                    showPercentValue
                    diameter={130}
                  />
                  <p>{this.state.order}</p>
                </div>
                <div>
                  <p>Prize</p>
                  <span className="success">{this.state.prize}</span>
                  <p>Amount</p>
                  <span>{this.state.wagerAmount}</span>
                </div>
              </div> */}
                    </div>
                </div>
            </div>
        </Draggable >
    );
}

const HistoryChart = ({ winningsData }: { winningsData: Array<any> }) => {
    return (
        <ResponsiveContainer width='100%' height='100%' aspect={3}>
            <AreaChart
                width={320} height={100}
                data={winningsData}
                style={winningsData.length > 1 && { marginLeft: "-20px" }}
            >
                <defs>
                    <linearGradient id="color" x1="0" y1="0">
                        {
                            winningsData.length > 0 &&
                            winningsData.map((ele, id) => {
                                    if (id) {
                                        if (ele.earnings > 0) {

                                            if (winningsData[id - 1].earnings >= 0)
                                                return <stop offset={`${100 * (id + 1) / winningsData.length}%`} stopColor="#1DB954" stopOpacity={0.5} />
                                            else {
                                                return (
                                                    <>
                                                        <stop offset={`${100 * (id) / winningsData.length}%`} stopColor="#f34223" stopOpacity={0.5} />
                                                        <stop offset={`${100 * (id) / winningsData.length}%`} stopColor="#1DB954" stopOpacity={0.5} />
                                                    </>
                                                )
                                            }

                                        } else {

                                            if (winningsData[id - 1].earnings <= 0)
                                                return <stop offset={`${100 * (id + 1) / winningsData.length}%`} stopColor="#f34223" stopOpacity={0.5} />
                                            else {
                                                return (
                                                    <>
                                                        <stop offset={`${100 * (id) / winningsData.length}%`} stopColor="#1DB954" stopOpacity={0.5} />
                                                        <stop offset={`${100 * (id) / winningsData.length}%`} stopColor="#f34223" stopOpacity={0.5} />
                                                    </>
                                                )
                                            }
                                        }
                                    }
                                }
                            )
                        }
                    </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="2 2" vertical={false} />

                {
                    winningsData.length > 1 &&
                    <YAxis tick={{ fill: 'white' }} tickFormatter={tick => {
                        return toRuneScapeFormatFromDecimal(tick);
                    }} >
                        {/* <Label value={Math.min(...winningsData.map(ele => ele.earnings)).toFixed(0)} position="insideBottomLeft" style={{ color: 'white' }} stroke="white" /> */}
                    </YAxis>
                }

                <Tooltip content={
                    //@ts-ignore
                    <CustomTooltip />
                } />
                <Area type="natural" dataKey="earnings" stroke="url(#color)" strokeWidth={2} fill="url(#color)" />
            </AreaChart>
        </ResponsiveContainer>
    )
}

// @ts-ignore
const CustomTooltip = ({ active, payload, label }) => {
    if (active) {
        return (
            <div className="ChartTooltip">
                <ul className="Headings">
                    <li>
                        <span>Date</span>
                    </li>
                    <li>
                        <span>Amount</span>
                    </li>
                </ul>
                <ul className="Values">
                    <li>
                        <span>{new Date(label).toString().substr(0, 10)}</span>
                    </li>
                    <li>
                        <span>{toRuneScapeFormatFromDecimal(payload[0].value)}</span>
                    </li>
                </ul>
            </div>
        );
    }

    return null;
};