export interface ProvablyFairSet {
    serverSeed: string
    clientSeed: string
    nonce: string
    value?: number
    game: string
}