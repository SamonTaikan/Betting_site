export const calculatorChip = (chipValue: string, currentValue: string) => {

    if (Number(currentValue) === 0) {
        return chipValue;
    }

    var regex = /[\d|,|.|E|\+]+/g;
    let chipV = chipValue.match(regex)?.join("");
    let currentV = currentValue.match(regex)?.join("");
    let current_unit = currentValue[currentValue.length - 1];
    let chip_unit = chipValue[chipValue.length - 1];
    let NewchipV: number = 0.0;
    switch (current_unit) {
        case "B":
            NewchipV = ChangeVaule(chipV, chip_unit, 1);
            break;
        case "M":
            NewchipV = ChangeVaule(chipV, chip_unit, 2);
            break;
        case "K":
            NewchipV = ChangeVaule(chipV, chip_unit, 3);
            break;
    }

    let result = NewchipV + Number(currentV);

    if (result >= 1000000) {
        result /= 1000;
        if (result >= 1000) return displayDecimal(result / 1000) + (current_unit === "K" ? "M" : current_unit === "M" ? "B" : "T");
        return displayDecimal(result) + (current_unit === "K" ? "M" : current_unit === "M" ? "B" : "T");
    }

    if (result >= 1000) {
        return current_unit !== "B" ? (result / 1000) + (current_unit === "K" ? "M" : current_unit === "M" ? "B" : "T") : displayDecimal(result / 1000) + "T";
    }
    return displayDecimal(result) + current_unit;

}

export const calculatorChipNumber = (chipValue: string, currentValue: string) => {

    if (Number(currentValue) === 0) {
        return chipValue;
    }

    var regex = /[\d|,|.|E|\+]+/g;
    let chipV = chipValue.match(regex)?.join("");
    let currentV = currentValue.match(regex)?.join("");
    let current_unit = 'k';
    let chip_unit = chipValue[chipValue.length - 1];
    let NewchipV: number = 0.0;
    switch (current_unit) {
        case "B":
            NewchipV = ChangeVaule(chipV, chip_unit, 1);
            break;
        case "M":
            NewchipV = ChangeVaule(chipV, chip_unit, 2);
            break;
        case "K":
            NewchipV = ChangeVaule(chipV, chip_unit, 3);
            break;
    }

    let result = NewchipV + Number(currentV);

    return displayDecimal(result);

}

export const calculatorChipMinusNumber = (chipValue: string) => {


    var regex = /[\d|,|.|E|\+]+/g;
    let chipV = chipValue.match(regex)?.join("");
    let chip_unit = chipValue[chipValue.length - 1];
    if(Number(chipV) <= 10 && chip_unit === "K") {
        return "10K";
    }
    let current_unit = 'K';
    let NewchipV: number = 0.0;
    switch (current_unit) {
        case "B":
            NewchipV = ChangeVaule(chipV, chip_unit, 1);
            break;
        case "M":
            NewchipV = ChangeVaule(chipV, chip_unit, 2);
            break;
        case "K":
            NewchipV = ChangeVaule(chipV, chip_unit, 3);
            break;
    }

    let result = NewchipV / 2;

    if (result >= 1000000) {
        result /= 1000;
        if (result >= 1000) return displayDecimal(result / 1000) + (current_unit === "K" ? "M" : current_unit === "M" ? "B" : "T");
        return displayDecimal(result) + (current_unit === "K" ? "M" : current_unit === "M" ? "B" : "T");
    }

    if (result >= 1000) {
        return current_unit !== "B" ? (result / 1000) + (current_unit === "K" ? "M" : current_unit === "M" ? "B" : "T") : displayDecimal(result / 1000) + "T";
    }
    return displayDecimal(result) + current_unit;
}

const ChangeVaule = (chipV: any, chip_unit: string, balance: number) => {

    switch (balance) {
        case 1:
            if (chip_unit === "B")
                return Number(chipV);
            else if (chip_unit === "M")
                return Number(chipV) / 1000;
            else return Number(chipV) / (1000 * 1000);
        case 2:
            if (chip_unit === "B")
                return Number(chipV) * 1000;
            else if (chip_unit === "M")
                return Number(chipV);
            else return Number(chipV) / (1000);
        case 3:
            if (chip_unit === "B")
                return Number(chipV) * 1000 * 1000;
            else if (chip_unit === "M")
                return Number(chipV) * 1000;
            else return Number(chipV);
        default:
            return Number(chipV);
    }

}

const displayDecimal = (num: number) => {
    if (Number.isInteger(num)) {
        return num;
    } else {
        return num.toFixed(2);
    }
}
