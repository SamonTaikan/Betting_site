import React, { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { AiOutlineUndo, AiOutlineClear } from 'react-icons/ai';
import { calculatorChip, calculatorChipMinusNumber, calculatorChipNumber } from './calculatorChipValue';

interface HistroyProps {
    index: number,
    currentValue: string,
    chipId: string
}

export type ButtonProps = {
    options: Array<number>;
    ballScreen: Array<string>;
    setBallScreen: Function;
    chipValue: string;
    IndexNumber: any;
    label: string;
    minValue: number;
    maxValue: number;
    color_list: Array<number>;
    history: HistroyProps[];
    setHistory: Function;
    setChipCount: Function;
    chipCount: Array<number>;
    rest: number
}

export type Chipcomponentprops = {
    ballScreen: Array<string>,
    history: HistroyProps[],
    chipCount: Array<number>,
    chipIndex: number,
    index: number
}

const EffectButton: React.FC<ButtonProps> = (props: ButtonProps) => {

    const {
        options,
        ballScreen,
        setBallScreen,
        chipValue,
        IndexNumber,
        label,
        minValue,
        maxValue,
        color_list,
        history,
        setHistory,
        chipCount,
        setChipCount,
        rest
    } = props

    const brihtness_change = (event: any, ele: number, id: number, brightnessValue: number) => {
        switch (label) {
            case '1 to 12':
                if (id % 12 >= minValue && id % 12 < maxValue) { } else {
                    document.getElementById(id.toString())!.style.filter = "brightness(" + brightnessValue + ")";
                }
                break;
            case '13 to 24':
                if (id % 12 >= minValue && id % 12 < maxValue) { } else {
                    document.getElementById(id.toString())!.style.filter = "brightness(" + brightnessValue + ")";
                }
                break;
            case '25 to 36':
                if (id % 12 >= minValue && id % 12 < maxValue) { } else {
                    document.getElementById(id.toString())!.style.filter = "brightness(" + brightnessValue + ")";
                }
                break;
            case '1 to 18':
                if (ele < 19) { } else {
                    document.getElementById(id.toString())!.style.filter = "brightness(" + brightnessValue + ")";
                }
                break;
            case 'Even':
                if (ele % 2 === 0) { } else {
                    document.getElementById(id.toString())!.style.filter = "brightness(" + brightnessValue + ")";
                }
                break;
            case '':
                if (color_list.find((item: any) => item === ele)) { } else {
                    document.getElementById(id.toString())!.style.filter = "brightness(" + brightnessValue + ")";
                }
                break;
            case ' ':
                if (!color_list.find((item: any) => item === ele)) { } else {
                    document.getElementById(id.toString())!.style.filter = "brightness(" + brightnessValue + ")";
                }
                break;
            case 'Odd':
                if (ele % 2 === 1) { } else {
                    document.getElementById(id.toString())!.style.filter = "brightness(" + brightnessValue + ")";
                }
                break;
            case '19 to 36':
                if (ele >= 19) { } else {
                    document.getElementById(id.toString())!.style.filter = "brightness(" + brightnessValue + ")";
                }
                break;
            default:
                break;
        }
    }

    return (
        <div
            className={label === '' ? 'red' : ''}
            onMouseOver={(event: any) => {
                options.map((ele, id) => {
                    brihtness_change(event, ele, id, 0.7);
                })
            }}
            onMouseLeave={(event: any) => {
                options.map((ele, id) => {
                    brihtness_change(event, ele, id, 1);
                })
            }}
            onClick={(event: any) => {
                let audio = new Audio("/assets/games/online/roulette/kenoAutoPick.46756983.mp3")
                if (localStorage.getItem("mute-sounds") != "true")
                    audio.play()
                setBallScreen(ballScreen.map((el, i) => {
                    if (i === IndexNumber) {
                        chipValue !== "0" && setHistory([...history, { index: IndexNumber, currentValue: el, chipId: chipValue }]);
                        return (el ? calculatorChip(chipValue, el) : chipValue)
                    } else {
                        return el
                    }
                }))
                history.map((ele) => {
                    ele.index === IndexNumber && chipValue !== "0" && setChipCount(chipCount.map((e, i) => i === IndexNumber ? e + 1 : e));
                })
            }}>
            <span>
                {(ballScreen[IndexNumber] && Number(ballScreen[IndexNumber]) !== 0) ? '' : label}
                {
                    <ChipComponent ballScreen={ballScreen} history={history} chipCount={chipCount} chipIndex={rest} index={IndexNumber} />
                }</span>
        </div >
    )
}

const chip_list: Array<string> = [
    "10K",
    "100K",
    "1M",
    "10M",
    "100M",
    "100K",
    "1M",
    "10M",
    "100M",
    "1B",
];
let Interval: any;
let Animate_Interval: any;
let startAngle = 0;
let Animate_setTimeout: any;
var spinTimeout: any = null;

const ChipComponent = (props: Chipcomponentprops) => {
    const {
        ballScreen,
        history,
        chipCount,
        chipIndex,
        index
    } = props;

    return (
        <>
            {
                (ballScreen[index] && Number(ballScreen[index]) !== 0) && [...new Array(chipCount[index] > 4 ? 4 : chipCount[index])].map((ele, i) => {
                    let currentChip = history.filter(ele => ele.index === index)[history.filter(ele => ele.index === index).length - 1].chipId
                    let lastChip = history.filter(ele => ele.index === index)[history.filter(ele => ele.index === index).length - 2 > 0 ? history.filter(ele => ele.index === index).length - 2 : 0].chipId
                    let chip_index = chip_list.indexOf(currentChip) < 0 ? (chip_list.indexOf(lastChip) < 0 ? 6 : chip_list.indexOf(lastChip)) : chip_list.indexOf(currentChip);
                    return <div style={{ top: - (i) * 5 + "px" }} className={(Number(ballScreen[index].match(/[\d|,|.|E|\+]+/g)?.join("")) >= 1 && (ballScreen[index][ballScreen[index].length - 1] === "B")) ? 'ball-9 text-green' : ((Number(ballScreen[index].match(/[\d|,|.|E|\+]+/g)?.join("")) >= 10 && (ballScreen[index][ballScreen[index].length - 1] === "M" || ballScreen[index][ballScreen[index].length - 1] === "B")) ? ((Number(ballScreen[index].match(/[\d|,|.|E|\+]+/g)?.join("")) >= 100 && (ballScreen[index][ballScreen[index].length - 1] === "M" || ballScreen[index][ballScreen[index].length - 1] === "B")) ? 'ball-4' + ' text-green ' : 'ball-3' + ' text-green ') : ((Number(ballScreen[index].match(/[\d|,|.|E|\+]+/g)?.join("")) >= 1 && (ballScreen[index][ballScreen[index].length - 1] === "M" || ballScreen[index][ballScreen[index].length - 1] === "B")) ? 'ball-' + chip_index + ' ' : 'ball-' + chip_index + ''))}>{i === (chipCount[index] - 1 > 3 ? 3 : chipCount[index] - 1) && ballScreen[index]}</div>
                })
            }
        </>
    )
}

const Roulette: any = (rest: any) => {

    const canvasRef = useRef<HTMLCanvasElement>(null);
    const RoulettePanel = useRef<HTMLDivElement>(null);
    const ImgRef = useRef<HTMLImageElement>(null);
    let roulette: any = canvasRef.current;
    const [size, setSize] = useState<Array<number>>([400, 200]);
    const [betList, setBetList] = useState<Array<number>>([]);
    const [chipValue, setChipValue] = useState("0");
    const [ballScreen, setBallScreen] = useState<Array<string>>([]);
    const [history, setHistory] = useState<HistroyProps[]>([]);
    const [chipCount, setChipCount] = useState<Array<number>>([]);
    const [chipIndex, setChipIndex] = useState<number>(0);
    const [BetDisplay, setBetDisplay] = useState(false);
    const [currentState, setCurrentState] = useState<Array<any>>([]);
    const img = new Image();
    img.src = '/assets/games/online/roulette/Wheel.svg';
    let chip_index: number = 0;

    useLayoutEffect(() => {
        function updateSize() {
            roulette = RoulettePanel.current;
            setSize([
                roulette!.clientWidth,
                roulette!.clientHeight,
            ]);
        }
        window.addEventListener("resize", updateSize);
        updateSize();
        return () => window.removeEventListener("resize", updateSize);
    }, []);

    var options = [0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10, 5, 24, 16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26];

    var color_list = [1, 3, 5, 7, 9, 12, 14, 16, 18, 21, 19, 23, 27, 25, 30, 32, 34, 36];

    var button_list = ['1 to 18', 'Even', '', ' ', 'Odd', '19 to 36'];

    var arc = Math.PI / (options.length / 2);
    var spinTime = 0;
    var spinAngleStart = 0;

    var ctx: any;

    window.onscroll = (e) => {
        e.preventDefault();
    }

    useMemo(() => {
        spin();
        setBallScreen(
            [...new Array(50)].map(ele => '')
        )
        setChipCount(
            [...new Array(50)].map(ele => 1)
        )

    }, []);

    useEffect(() => {
        setChipValue(rest.chip_value)

        if (rest.doubleChip) {
            setCurrentState([...currentState, 'doubleChip']);
            setBallScreen(ballScreen.map((el, i) => {
                rest.handleCurrentChip(Number(calculatorChipNumber(el, el)))
                return calculatorChip(el, el)
            }));
            (rest.chip_value !== "0") && setChipCount(chipCount.map((e, i) => history.find((ele) => i === ele.index) ? e * 2 : e));
        }
        if (rest.divide) {
            setCurrentState([...currentState, 'divide']);
            setBallScreen(ballScreen.map((el, i) => {
                if (el.length) {
                    return calculatorChipMinusNumber(el)
                } else {
                    return el
                }
            }));
            (rest.chip_value !== "0") && setChipCount(chipCount.map((e, i) => history.find((ele) => i === ele.index) ? parseInt((e / 2 < 1 ? 1 : e / 2).toFixed(2)) : e));

        }
    }, [rest.chip_value, rest.doubleChip, rest.divide]);

    useEffect(() => {
        let currentChipPosition: Array<number> = [];
        rest.setBorderData([...history.filter((ele, id) => {
            if (currentChipPosition[ele.index] !== ele.index) {
                currentChipPosition[ele.index] = ele.index;
                return ele;
            }
        })].map((eles, id) => {
            return ({
                chipId: eles.chipId,
                chipPosition: eles.index,
                chipCount: chipCount[eles.index]
            })
        }))
    }, [history]);

    useEffect(() => {
        if (ballScreen.length) {
            let total = "0K";
            ballScreen.map((ele, id) => {
                if (ele) total = calculatorChip(total, ele);
            });
            rest.setState(total[total.length - 1] === "M" ? Number(total.slice(0, total.length - 1)) * 1000 : (total[total.length - 1] === "B" ? Number(total.slice(0, total.length - 1)) * 1000 * 1000 : Number(total.slice(0, total.length - 1))))

        }
    }, [ballScreen]);

    useEffect(() => {

        if (rest.onAnimation && window.innerWidth > 800) {
            let audio = new Audio("/assets/games/online/roulette/spinning.6587b785.mp3")
            if (localStorage.getItem("mute-sounds") != "true")
                audio.play()
            if (rest.bet_number) {
                clearInterval(Interval);

                const canvas = canvasRef.current;
                ctx = canvas!.getContext("2d");
                if (window.innerWidth > 800) {
                    ballAnimation(ctx, canvas);
                }
                setTimeout(() => {
                    setBetList([rest.bet_number, ...betList]);
                    setBetDisplay(true);

                    clearInterval(Animate_Interval);
                    Interval = setInterval(() => {
                        var regex = /[\d|,|.|E|\+]+/g;
                        var strings: any = ImgRef.current?.style.transform;
                        var matches = strings.match(regex);
                        ctx.clearRect(0, 0, 500, 500);
                        let index: number = 0;
                        options.map((ele, id) => ele === rest.bet_number ? index = id : "");
                        let degree = - (Number(matches[0]) % 360) + (360 / 37 * index);
                        ctx.clearRect(0, 0, canvas?.clientWidth, canvas?.clientHeight);
                        ctx.beginPath();
                        ctx.save();
                        if (window.innerWidth > 800) {
                            ctx.translate(150, 160);
                            ctx.rotate(degree * Math.PI / 180);
                            ctx.arc(8, -98, 9, 0, 2 * Math.PI);
                            ctx.fillStyle = "#ffffff";
                            ctx.fill();
                        }
                        ctx.restore();

                    }, 5)
                }, 2700);
            }
        } else {
            if (rest.bet_number) {
                let audio = new Audio("/assets/games/online/roulette/spinning.6587b785.mp3")
                if (localStorage.getItem("mute-sounds") != "true")
                    audio.play()
                clearInterval(Interval);
                clearInterval(Animate_Interval);
                setBetList([rest.bet_number, ...betList]);
                ctx.clearRect(0, 0, 500, 500);

                const canvas = canvasRef.current;
                ctx = canvas!.getContext("2d");
                setBetDisplay(true);

                Interval = setInterval(() => {
                    var regex = /[\d|,|.|E|\+]+/g;
                    var strings: any = ImgRef.current?.style.transform;
                    var matches = strings.match(regex);
                    ctx.clearRect(0, 0, 500, 500);
                    let index: number = 0;
                    options.map((ele, id) => ele === rest.bet_number ? index = id : "");
                    let degree = - (Number(matches[0]) % 360) + (360 / 37 * index);
                    ctx.clearRect(0, 0, canvas?.clientWidth, canvas?.clientHeight);
                    ctx.beginPath();
                    ctx.save();
                    if (window.innerWidth > 800) {
                        ctx.translate(150, 160);
                        ctx.rotate(degree * Math.PI / 180);
                        ctx.arc(8, -98, 9, 0, 2 * Math.PI);
                        ctx.fillStyle = "#ffffff";
                        ctx.fill();
                    }
                    ctx.restore();
                }, 5)
            }
        }
        // setBetDisplay(false);

    }, [rest.bet_number]);

    const ballAnimation = (ctx: CanvasRenderingContext2D, canvas: any) => {
        let speed: number = 0;
        let degree = 0;

        Animate_Interval = setInterval(() => {

            ctx.clearRect(0, 0, 500, 500);
            degree = 500 / 120 * speed;
            ctx.beginPath();
            ctx.save();
            ctx.translate(150, 160);
            ctx.rotate(degree * Math.PI / 180);
            ctx.arc(8, -140, 9, 0, 2 * Math.PI);
            ctx.fillStyle = "#ffffff";
            ctx.fill();
            ctx.restore();
            speed += 1;

        }, 10);

        Animate_setTimeout = setTimeout(() => {
            let distance = 140 - 100;
            let id = 0;
            speed = 0;
            let between = 50;
            clearInterval(Animate_Interval);
            let between_degree: number = 0;
            let width = -140;
            Animate_Interval = setInterval(() => {

                var regex = /[\d|,|.|E|\+]+/g;
                var strings: any = ImgRef.current?.style.transform;
                var matches = strings.match(regex);
                ctx.clearRect(0, 0, 500, 500);
                let index: number = 0;
                options.map((ele, id) => ele === rest.bet_number ? index = id : "");
                if (between_degree === 0)
                    between_degree = (- (Number(matches[0]) % 360) + (360 / 37 * index) + 25 + between) > 0 ? - (Number(matches[0]) % 360) + (360 / 37 * index) - 25 + 220 + between : - (Number(matches[0]) % 360) + (360 / 37 * index) + 250 + 360 + between;
                    // if ((- (Number(matches[0]) % 360) + (360 / 37 * index) + 25 + between) > 0) between_degree = - (Number(matches[0]) % 360) + (360 / 37 * index) - 25 + 220 + between
                    // else {
                    //     clearInterval(Animate_Interval);
                    //     clearTimeout(Animate_setTimeout);
                    //     setTimeout(() =>
                    //         ballAnimation(ctx, canvas), 10)
                    // }
                ctx.beginPath();
                ctx.save();
                ctx.translate(150, 160);
                if (id <= 100) {
                    degree = -220 + (between_degree / 100) * id - (between_degree / 500) * id;

                    ctx.rotate(degree * Math.PI / 180);
                    if (Math.floor(id / 10) % 2 !== 0) {
                        width = width + (distance / -45);

                    } else {
                        width = width + (distance / 25);
                    }
                    ctx.arc(8, width, 9, 0, 2 * Math.PI);
                    ctx.fillStyle = "#ffffff";
                    ctx.fill();
                    ctx.restore();
                } else {
                    ctx.rotate(degree * Math.PI / 180);
                    if (Math.floor(id / 5) % 2 !== 0) {
                        width = - 100 - (distance / 540);

                    } else {
                        width = -103.5 + (distance / 540);
                    }
                    ctx.arc(8, width, 9, 0, 2 * Math.PI);
                    ctx.fillStyle = "#ffffff";
                    ctx.fill();
                    ctx.restore();
                }
                id++;
            }, 13);
        }, 1200);
    }

    const number_order = () => {

        let number: Array<number> = [];
        let number1: Array<number> = [];
        let number2: Array<number> = [];
        [...new Array(36)].map((ele, id) => {
            if ((id + 1) % 3 === 0) {
                number.push(id + 1);
            }
            else if ((id + 1) % 3 === 2) {
                number1.push(id + 1);
            }
            else if ((id + 1) % 3 === 1) {
                number2.push(id + 1);
            }
        }
        )
        return number.concat(number1).concat(number2);
    }

    function drawRouletteWheel() {

        const canvas = canvasRef.current;
        if (canvas?.getContext) {

            ctx = canvas.getContext("2d");
            ctx.strokeStyle = "black";
            ctx.lineWidth = 2;

            ctx.font = 'bold 12px Helvetica, Arial';
            ctx.beginPath();

            ImgRef.current!.style.transform = "rotate(-" + startAngle * 180 / Math.PI + "deg)";
        }
    }

    function spin() {
        spinAngleStart = 0.6;
        spinTime = 0;
        rotateWheel();
    }

    function rotateWheel() {
        clearTimeout(spinTimeout)
        var spinAngle = spinAngleStart
        startAngle += (spinAngle * Math.PI / 180);
        drawRouletteWheel();
        spinTimeout = setTimeout(() => rotateWheel(), 30);
    }

    drawRouletteWheel();

    return (
        <div className='game-roulette'>
            <div className='game_top'>
                <div className='main'>
                    <div className='display_bet'>
                        {
                            BetDisplay &&
                                rest.bet_number ? (
                                rest.bet_number == 0 ?
                                    <div className="green">{rest.bet_number}</div> :
                                    color_list.find(item => item === rest.bet_number) ?
                                        <div className="red">{betList[0]}</div> :
                                        <div className="grey">{betList[0]}</div>
                            ) :
                                <div className="grey"></div>
                        }
                    </div>
                    <div className='roulette-panel' ref={RoulettePanel}>
                        <canvas id="canvas" width="300" height="300" ref={canvasRef}></canvas>
                        <img src='/assets/games/online/roulette/Wheel.svg' className='wheel' ref={ImgRef} />
                    </div>
                    <div className='betting_history'>
                        {
                            betList.length !== 0 && (
                                betList.map((ele, id) => ele == 0 ?
                                    <div className="green" key={id} style={{ opacity: 1 - id / 6 }}>{ele}</div> :
                                    color_list.find(item => item === ele) ?
                                        <div className="red" style={{ opacity: 1 - id / 6 }}>{ele}</div> :
                                        <div className="grey" style={{ opacity: 1 - id / 6 }}>{ele}</div>
                                )
                            )
                        }
                    </div>
                </div>
                <div className='number'>
                    <div className='number-area'>
                        <div className='zero green'
                            onMouseOver={(event: any) => {
                                event.target.style.filter = "brightness(1.3)";
                            }}
                            onMouseLeave={(event: any) => {
                                event.target.style.filter = "brightness(1)";
                            }}
                            onClick={(event: any) => {
                                let audio = new Audio("/assets/games/online/roulette/kenoAutoPick.46756983.mp3")
                                if (localStorage.getItem("mute-sounds") != "true")
                                    audio.play()
                                setCurrentState([...currentState, '']);
                                event.target.style.filter = "brightness(1)"; setBallScreen(ballScreen.map((el, i) => {
                                    if (i === 48) {
                                        chipValue !== "0" && setHistory([...history, { index: 48, currentValue: el, chipId: chipValue }]);
                                        return (el ? calculatorChip(chipValue, el) : chipValue)
                                    } else {
                                        return el
                                    }
                                }))
                                history.map((ele) => {
                                    (ele.index === 48 && chipValue !== "0") && setChipCount(chipCount.map((e, i) => i === 48 ? e + 1 : e));
                                })
                            }}>{'0'}
                            <ChipComponent ballScreen={ballScreen} history={history} chipCount={chipCount} chipIndex={chipIndex} index={48} />
                        </div>
                        <div className='tops'>
                            <div className='number_list'>
                                {
                                    number_order().map((ele, id) =>
                                        color_list.find(item => item === ele) ?
                                            <div
                                                key={id}
                                                className="red"
                                                id={id.toString()}
                                                onMouseOver={(event: any) => {
                                                    event.target.style.filter = "brightness(1.5)";
                                                }}
                                                onMouseLeave={(event: any) => {
                                                    event.target.style.filter = "brightness(1)";
                                                }}
                                                onClick={(event: any) => {
                                                    let audio = new Audio("/assets/games/online/roulette/kenoAutoPick.46756983.mp3")
                                                    if (localStorage.getItem("mute-sounds") != "true")
                                                        audio.play()
                                                    setCurrentState([...currentState, '']);
                                                    event.target.style.filter = "brightness(1)";
                                                    setBallScreen(ballScreen.map((el, i) => {
                                                        if (i === id) {
                                                            chipValue !== "0" && setHistory([...history, { index: id, currentValue: el, chipId: chipValue }]);
                                                            return (el ? calculatorChip(chipValue, el) : chipValue)
                                                        } else {
                                                            return el
                                                        }
                                                    }))
                                                    history.map((ele) => {
                                                        (ele.index === id && chipValue !== "0") && setChipCount(chipCount.map((e, i) => i === id ? e + 1 : e));
                                                    })
                                                }}>{ele}
                                                <ChipComponent ballScreen={ballScreen} history={history} chipCount={chipCount} chipIndex={chipIndex} index={id} />
                                            </div> :
                                            <div
                                                key={id}
                                                className="grey"
                                                id={id.toString()}
                                                onMouseOver={(event: any) => {
                                                    event.target.style.filter = "brightness(1.5)";
                                                }}
                                                onMouseLeave={(event: any) => {
                                                    event.target.style.filter = "brightness(1)";
                                                }}
                                                onClick={(event: any) => {
                                                    let audio = new Audio("/assets/games/online/roulette/kenoAutoPick.46756983.mp3")
                                                    if (localStorage.getItem("mute-sounds") != "true")
                                                        audio.play()
                                                    setCurrentState([...currentState, '']);
                                                    event.target.style.filter = "brightness(1)";
                                                    setBallScreen(ballScreen.map((el, i) => {
                                                        if (i === id) {
                                                            chipValue !== "0" && setHistory([...history, { index: id, currentValue: el, chipId: chipValue }]);
                                                            return (el ? calculatorChip(chipValue, el) : chipValue)
                                                        } else {
                                                            return el
                                                        }
                                                    }))
                                                    history.map((ele) => {
                                                        (ele.index === id && chipValue !== "0") && setChipCount(chipCount.map((e, i) => i === id ? e + 1 : e));
                                                    })
                                                }}>{ele}
                                                <ChipComponent ballScreen={ballScreen} history={history} chipCount={chipCount} chipIndex={chipIndex} index={id} />
                                            </div>
                                    )
                                }
                            </div>

                            <div className='number_bottom'>
                                <div className='main'>
                                    <div>
                                        <EffectButton
                                            options={options}
                                            ballScreen={ballScreen}
                                            setBallScreen={setBallScreen}
                                            chipValue={chipValue}
                                            IndexNumber={36}
                                            label={'1 to 12'}
                                            minValue={0}
                                            maxValue={4}
                                            color_list={color_list}
                                            history={history}
                                            setHistory={setHistory}
                                            chipCount={chipCount}
                                            setChipCount={setChipCount}
                                            rest={chipIndex}
                                        />
                                        <EffectButton
                                            options={options}
                                            ballScreen={ballScreen}
                                            setBallScreen={setBallScreen}
                                            chipValue={chipValue}
                                            IndexNumber={37}
                                            label={'13 to 24'}
                                            minValue={4}
                                            maxValue={8}
                                            color_list={color_list}
                                            history={history}
                                            setHistory={setHistory}
                                            chipCount={chipCount}
                                            setChipCount={setChipCount}
                                            rest={chipIndex}
                                        />
                                        <EffectButton
                                            options={options}
                                            ballScreen={ballScreen}
                                            setBallScreen={setBallScreen}
                                            chipValue={chipValue}
                                            IndexNumber={38}
                                            label={'25 to 36'}
                                            minValue={8}
                                            maxValue={12}
                                            color_list={color_list}
                                            history={history}
                                            setHistory={setHistory}
                                            chipCount={chipCount}
                                            setChipCount={setChipCount}
                                            rest={chipIndex}
                                        />
                                    </div>
                                    <div>
                                        {
                                            button_list.map((ele, id) =>
                                                <EffectButton
                                                    key={id}
                                                    options={number_order()}
                                                    ballScreen={ballScreen}
                                                    setBallScreen={setBallScreen}
                                                    chipValue={chipValue}
                                                    IndexNumber={id + 39}
                                                    label={ele}
                                                    minValue={8}
                                                    maxValue={12}
                                                    color_list={color_list}
                                                    history={history}
                                                    setHistory={setHistory}
                                                    chipCount={chipCount}
                                                    setChipCount={setChipCount}
                                                    rest={chip_index}
                                                />
                                            )
                                        }
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className='space'>
                            <div
                                onMouseOver={(event: any) => {
                                    number_order().map((ele, id) => {
                                        if (id < 12) { } else {
                                            document.getElementById(id.toString())!.style.filter = "brightness(0.7)";
                                            event.target.style.filter = "brightness(1.3)";
                                        }
                                    })
                                }}
                                onMouseLeave={(event: any) => {
                                    number_order().map((ele, id) => {
                                        if (id < 12) { } else {
                                            document.getElementById(id.toString())!.style.filter = "brightness(1)";
                                            event.target.style.filter = "brightness(1)";
                                        }
                                    })
                                }}
                                onClick={(event: any) => {
                                    let audio = new Audio("/assets/games/online/roulette/kenoAutoPick.46756983.mp3")
                                    if (localStorage.getItem("mute-sounds") != "true")
                                        audio.play()
                                    setCurrentState([...currentState, '']);

                                    event.target.style.filter = "brightness(1)"; setBallScreen(ballScreen.map((el, i) => {
                                        if (i === 45) {
                                            chipValue !== "0" && setHistory([...history, { index: 45, currentValue: el, chipId: chipValue }]);
                                            return (el ? calculatorChip(chipValue, el) : chipValue)
                                        } else {
                                            return el
                                        }
                                    }))
                                    history.map((ele) => {
                                        ele.index === 45 && chipValue !== "0" && setChipCount(chipCount.map((e, i) => i === 45 ? e + 1 : e));
                                    })
                                }}>{'2:1'}
                                <ChipComponent ballScreen={ballScreen} history={history} chipCount={chipCount} chipIndex={chipIndex} index={45} />
                            </div>
                            <div
                                onMouseOver={(event: any) => {
                                    number_order().map((ele, id) => {
                                        if (id >= 12 && id < 24) { } else {
                                            document.getElementById(id.toString())!.style.filter = "brightness(0.7)";
                                            event.target.style.filter = "brightness(1.3)";

                                        }
                                    })
                                }}
                                onMouseLeave={(event: any) => {
                                    number_order().map((ele, id) => {
                                        if (id >= 12 && id < 24) { } else {
                                            document.getElementById(id.toString())!.style.filter = "brightness(1)";
                                            event.target.style.filter = "brightness(1)";
                                        }
                                    })
                                }}
                                onClick={(event: any) => {
                                    let audio = new Audio("/assets/games/online/roulette/kenoAutoPick.46756983.mp3")
                                    if (localStorage.getItem("mute-sounds") != "true")
                                        audio.play()
                                    setCurrentState([...currentState, '']);

                                    event.target.style.filter = "brightness(1)"; setBallScreen(ballScreen.map((el, i) => {
                                        if (i === 46) {
                                            chipValue !== "0" && setHistory([...history, { index: 46, currentValue: el, chipId: chipValue }]);
                                            return (el ? calculatorChip(chipValue, el) : chipValue)
                                        } else {
                                            return el
                                        }
                                    }))
                                    history.map((ele) => {
                                        ele.index === 46 && chipValue !== "0" && setChipCount(chipCount.map((e, i) => i === 46 ? e + 1 : e));
                                    })
                                }}>{'2:1'}
                                <ChipComponent ballScreen={ballScreen} history={history} chipCount={chipCount} chipIndex={chipIndex} index={46} />
                            </div>
                            <div
                                onMouseOver={(event: any) => {
                                    number_order().map((ele, id) => {
                                        if (id >= 24 && id < 36) { } else {
                                            document.getElementById(id.toString())!.style.filter = "brightness(0.7)";
                                            event.target.style.filter = "brightness(1.3)";

                                        }
                                    })
                                }}
                                onMouseLeave={(event: any) => {
                                    number_order().map((ele, id) => {
                                        if (id >= 24 && id < 36) { } else {
                                            document.getElementById(id.toString())!.style.filter = "brightness(1)";
                                            event.target.style.filter = "brightness(1)";
                                        }
                                    })
                                }}
                                onClick={(event: any) => {
                                    let audio = new Audio("/assets/games/online/roulette/kenoAutoPick.46756983.mp3")
                                    if (localStorage.getItem("mute-sounds") != "true")
                                        audio.play()
                                    setCurrentState([...currentState, '']);
                                    event.target.style.filter = "brightness(1)"; setBallScreen(ballScreen.map((el, i) => {
                                        if (i === 47) {
                                            chipValue !== "0" && setHistory([...history, { index: 47, currentValue: el, chipId: chipValue }]);
                                            return (el ? calculatorChip(chipValue, el) : chipValue)
                                        } else {
                                            return el
                                        }
                                    }))
                                    history.map((ele) => {
                                        ele.index === 47 && chipValue !== "0" && setChipCount(chipCount.map((e, i) => i === 47 ? e + 1 : e));
                                    })
                                }}>{'2:1'}
                                <ChipComponent ballScreen={ballScreen} history={history} chipCount={chipCount} chipIndex={chipIndex} index={47} />
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <div className='controls'>
                <div
                    onClick={(e) => {
                        if (!currentState[currentState.length - 1].length) {
                            e.preventDefault();
                            setBallScreen(ballScreen.map((ele, id) => id === history[history.length - 1].index ? history[history.length - 1].currentValue : ele));
                            setHistory(history.filter((ele, id) => id !== history.length - 1));
                            setChipCount(
                                chipCount.map((ele, id) => id === history[history.length - 1].index ? ele - 1 : ele)
                            )
                        } else {
                            if (currentState[currentState.length - 1] === 'doubleChip') {
                                setBallScreen(ballScreen.map((el, i) => {
                                    if (el.length) {
                                        return calculatorChipMinusNumber(el)
                                    } else {
                                        return el
                                    }
                                }))
                                history.map((ele) => {
                                    (rest.chip_value !== "0") && setChipCount(chipCount.map((e, i) => i === ele.index ? parseInt((e / 2 < 1 ? 1 : e / 2).toFixed(2)) : e));
                                })
                            } else if (currentState[currentState.length - 1] === 'divide') {
                                setBallScreen(ballScreen.map((el, i) => {
                                    rest.handleCurrentChip(Number(calculatorChipNumber(el, el)))
                                    return calculatorChip(el, el)
                                }))
                                history.map((ele) => {
                                    (rest.chip_value !== "0") && setChipCount(chipCount.map((e, i) => i === ele.index ? e * 2 : e));
                                })
                            }
                        }
                        setCurrentState(currentState.filter((ele, id) => id !== currentState.length - 1))
                    }}>
                    <i><AiOutlineUndo /></i>
                    <p>Undo</p>
                </div>
                <div
                    onClick={(e) => {
                        e.preventDefault();
                        setBallScreen(
                            [...new Array(50)].map(ele => '')
                        )
                        setHistory(
                            []
                        )
                        setChipCount(
                            [...new Array(50)].map(ele => 1)
                        )

                    }}>
                    <p>Clear</p>
                    <i><AiOutlineClear /></i>
                </div>
            </div>
        </div>
    )
}

export default Roulette;
