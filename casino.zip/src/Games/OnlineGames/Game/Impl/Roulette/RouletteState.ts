export type Roulettes = {
  spinning?: boolean;
  wagerId?: number;
  stopOnMultiplier?: number;
  bet_number: any;
  chip_value: string;
  current_chip: number;
  open: boolean;
  onHistory: boolean;
  balance: number,
  rollOver: boolean,
  skipUpdate?: boolean,
  rolling: boolean,
  rollThreshold: number,
  winChance: number,
  wagerAmount: number,
  onWin: number,
  onWinIncreaseBy: number,
  onLoss: number,
  onLossIncreaseBy: number,
  stopOnLoss: number,
  stopOnWin: number,
  sessionProfit: number,
  previousResult: number | null,
  earnings: number
  autoing: boolean
  wonPrevious: boolean
  wagered: number
  wager: number
  profit: number
  wins: number | undefined
  losses: number | undefined
  winningsData: Array<any>
  betRoll_list: Array<any>
  startingBalance: number
  onAnimation: boolean
  onModal: boolean
  selectChipIndex: number,
  doubleChip: boolean,
  divide: boolean,
  currentChip: number,
  gain: number,
  percent: number,
  order: string,
  prize: number
};

