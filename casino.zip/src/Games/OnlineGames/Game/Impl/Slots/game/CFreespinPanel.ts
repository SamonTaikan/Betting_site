import {CMain} from "./CMain";
import {createBitmap, playSound} from "./ctl_utils";
import {CTLText} from "./CTLText";
import {CGame} from "./CGame";

export class CFreespinPanel {
    private _oFade: any;
    private _oTextCongrats: any;
    private _oTextWin: any;
    private _oContainerPanel: any;
    private _oContainer: any;
    private _oParentContainer: any;

    constructor(oParentContainer: any) {
        this._oParentContainer = oParentContainer;
        this._init();
    }

    private _init = () => {
        this._oContainer = new createjs.Container();
        this._oContainer.on("click", function () {
        });
        this._oContainer.visible = false;
        this._oParentContainer.addChild(this._oContainer);

        this._oFade = new createjs.Shape();
        this._oFade.graphics.beginFill("black").drawRect(0, 0, CMain.CANVAS_WIDTH, CMain.CANVAS_HEIGHT);
        this._oContainer.addChild(this._oFade);

        var oSprite = CMain.s_oSpriteLibrary!!.getSprite("msg_box_small");

        this._oContainerPanel = new createjs.Container();
        this._oContainerPanel.x = CMain.CANVAS_WIDTH / 2;
        this._oContainerPanel.y = CMain.CANVAS_HEIGHT / 2;
        this._oContainerPanel.regX = oSprite.width / 2;
        this._oContainerPanel.regY = oSprite.height / 2;
        this._oContainer.addChild(this._oContainerPanel);


        var oBg = createBitmap(oSprite);

        this._oContainerPanel.addChild(oBg);

        this._oTextCongrats = new CTLText(this._oContainerPanel,
            50, 80, oSprite.width - 100, 74,
            74, "center", "#fede00", CMain.FONT_GAME_1, 1,
            0, 0,
            CMain.TEXT_CONGRATS,
            true, true, true,
            false);


        this._oTextWin = new CTLText(this._oContainerPanel,
            50, 200, oSprite.width - 100, 180,
            60, "center", "#fede00", CMain.FONT_GAME_1, 1,
            0, 0,
            " ",
            true, true, true,
            false);

    };

    private show = (iTotFreespin: any) => {

        this._oTextWin.refreshText(CMain.TEXT_YOU_WIN + " " + iTotFreespin + " " + CMain.TEXT_FREESPINS);

        this._oContainer.visible = true;

        this._oContainerPanel.scale = 0;
        this._oFade.alpha = 0;

        var oParent = this;
        createjs.Tween.get(this._oFade).to({alpha: 0.7}, 300, createjs.Ease.quartOut)
        createjs.Tween.get(this._oContainerPanel).to({scale: 1}, 1000, createjs.Ease.elasticOut).call(function () {
            setTimeout(function () {
                oParent.hide();
            }, 3000);
        });


        playSound("bonus_end", 1, false);
    };

    private hide = () => {

        createjs.Tween.get(this._oFade).to({alpha: 0}, 500, createjs.Ease.quartOut)
        createjs.Tween.get(this._oContainerPanel).to({scale: 0}, 500, createjs.Ease.backIn).call(function () {
            CGame.s_oGame?.exitFromFreespinPanel();
        });
    }

}