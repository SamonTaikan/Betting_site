export class CSpriteLibrary {

    private _oLibSprites: any = {};
    private _oSpritesToLoad: any;
    private _iNumSprites: number = 0;
    private _iCntSprites: number = 0;
    private _cbCompleted?: any;
    private _cbTotalCompleted?: number;
    private _cbOwner?: any;

    public init = (cbCompleted: any, cbTotalCompleted: any, cbOwner: any) => {
        this._oSpritesToLoad = {};
        this._iNumSprites = 0;
        this._iCntSprites = 0;
        this._cbCompleted = cbCompleted;
        this._cbTotalCompleted = cbTotalCompleted;
        this._cbOwner     = cbOwner;
    };
    public addSprite = (szKey: string, szPath: string): boolean => {
        if (this._oLibSprites.hasOwnProperty(szKey) ){
            return false;
        }
        var oImage = new Image();
        this._oLibSprites[szKey] = this._oSpritesToLoad[szKey] = { szPath:szPath, oSprite: oImage ,bLoaded:false};
        this._iNumSprites++;

        return true;
    };
    public getSprite = (szKey: any) => {
        if (!this._oLibSprites.hasOwnProperty(szKey)){
            return null;
        }else{
            return this._oLibSprites[szKey].oSprite;
        }
    };
    public _onSpritesLoaded = () => {
        this._iNumSprites = 0;
        //@ts-ignore
        this._cbTotalCompleted.call(this._cbOwner);
    };
    public _onSpriteLoaded = () => {
        this._cbCompleted.call(this._cbOwner);
        if (++this._iCntSprites === this._iNumSprites) {
            this._onSpritesLoaded();
        }
    };
    public loadSprites = () => {

        for (var szKey in this._oSpritesToLoad) {
            this._oSpritesToLoad[szKey].oSprite["oSpriteLibrary"] = this;
            this._oSpritesToLoad[szKey].oSprite["szKey"] = szKey;
            this._oSpritesToLoad[szKey].oSprite.onload = function(){
                this.oSpriteLibrary.setLoaded(this.szKey);
                this.oSpriteLibrary._onSpriteLoaded(this.szKey);
            };
            this._oSpritesToLoad[szKey].oSprite.onerror  = function(evt: any){
                var oSpriteToRestore = evt.currentTarget;
                const _oSpritesToLoad = this._oSpritesToLoad;
                setTimeout(function(){
                    _oSpritesToLoad[oSpriteToRestore.szKey].oSprite.src = _oSpritesToLoad[oSpriteToRestore.szKey].szPath;
                },500);
            };
            this._oSpritesToLoad[szKey].oSprite.src = this._oSpritesToLoad[szKey].szPath;
        }
    };
    public setLoaded = (szKey: any) => {
        this._oLibSprites[szKey].bLoaded = true;
    };
    public isLoaded = (szKey: any): boolean => {
        return this._oLibSprites[szKey].bLoaded;
    };
    public getNumSprites = (): number => {
        return this._iNumSprites!!;
    };

}