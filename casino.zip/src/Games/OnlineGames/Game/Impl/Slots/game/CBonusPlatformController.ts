import {createBitmap, createSprite, playSound, formatEntries} from "./ctl_utils";
import {CMain} from "./CMain";
import {CBonusPanel} from "./CBonusPanel";
import {CScoreText} from "./CScoreText";
import {CBonusCharacter} from "./CBonusCharacter";
import {CBonusBut} from "./CBonusBut";

export class CBonusPlatformController{
    private _bCorrectJump: any;
    private _bEndBonus: any;
    private _bFinalPrize: any;
    private _iCurMultPrize: any;
    private _iClickedButton: any;
    private _iPlatformWidth: any;
    private _iCurBet: any;
    private _iIdInterval: any;
    private _aPlatformButton: any;
    private _pStartPosrmButton: any;
    private _oPot: any = null;
    private _oCorrectPlatform: any;
    private _oGoalPlatform: any = null;
    private _oCharacter: any;
    private _oContainer: any;
    private _oContainerPlatform: any;
    private _oParentContainer: any;

    constructor(
        iX: any,
        iY: any,
        oParentContainer: any
    ){
        this._oParentContainer = oParentContainer;
        this._init(iX,iY);
    }

    private _init = (iX: any,iY: any) => {
        this._pStartPosrmButton = {x:iX,y:iY};
        this._aPlatformButton = new Array();

        this._oContainer = new createjs.Container();
        this._oContainer.x = iX;
        this._oContainer.y = iY;
        this._oParentContainer.addChild(this._oContainer);

        this._oContainerPlatform = new createjs.Container();
        this._oContainer.addChild(this._oContainerPlatform);

        var oSprite = CMain.s_oSpriteLibrary!!.getSprite("platform_0");
        var oPlatform = createBitmap(oSprite);
        this._oContainerPlatform.addChild(oPlatform);


        this._oCharacter = new CBonusCharacter(400,60,this._oContainer);
        this._oCharacter.addEventListener(CMain.ON_CHARACTER_END_JUMP,this._onEndJump,this);

        this.addPlatforms(false);
    };
    private reset = () => {
        this._bFinalPrize = false;
        this._bEndBonus = false;
        this._oContainerPlatform.removeAllChildren();
        this._oGoalPlatform = null;

        if(this._oPot !== null){
            this._oContainer.removeChild(this._oPot);
            this._oPot = null;
        }

        this._oContainer.x = this._pStartPosrmButton.x;
        this._oContainer.y = this._pStartPosrmButton.y;

        var oSprite = CMain.s_oSpriteLibrary!!.getSprite("platform_0");
        var oPlatform = createBitmap(oSprite);
        this._oContainerPlatform.addChild(oPlatform);

        this._oCharacter.reset();

        this.addPlatforms(false);

        this._oContainer.setChildIndex(this._oContainerPlatform,0);
        this._oContainer.setChildIndex(this._oCharacter.getContainer(),1);
    };
    private startBonus = (iCurBet: any) => {
        this._iCurBet = iCurBet;

        this._oCharacter.idle();
    };

    private addPlatforms = (bFinalPrize: any) => {
        this._bFinalPrize = bFinalPrize;
        for(var i=0;i<this._aPlatformButton.length;i++){
            this._aPlatformButton[i].unload();
        }

        this._aPlatformButton = new Array();


        var iCont = 1;
        var iX = this._oCharacter.getX() + 484;
        for(var i=0;i<3;i++){
            var oSprite = CMain.s_oSpriteLibrary!!.getSprite("platform_"+iCont);

            var oPlatform = new CBonusBut(iX,CMain.CANVAS_HEIGHT,bFinalPrize,oSprite,this._oContainerPlatform);
            oPlatform.addEventListenerWithParams(CMain.ON_MOUSE_DOWN,this._onPlatformClick,this,i);


            this._iPlatformWidth = oSprite.width/2;

            iX += this._iPlatformWidth+38;

            this._aPlatformButton.push(oPlatform);

            oPlatform.moveY(115,1000,500 + (200*iCont),createjs.Ease.backOut);
            iCont++;
        }

        var oParent = this;
        this._iIdInterval = setInterval(function(){oParent.shakeRandPlatform();},2500);
    };

    private unload = () => {
        this._removePlatforms();
    };

    private _removePlatforms = (bEndBonus?: any) => {
        clearInterval (this._iIdInterval);

        if(this._oGoalPlatform !== null){
            //ATTACH FAKE PLATFORM WHERE IS PLACED THE HERO
            var oSprite = CMain.s_oSpriteLibrary!!.getSprite("platform_"+(this._iClickedButton+1));
            var oData = {   // image to use
                images: [oSprite],
                // width, height & registration point of each sprite
                frames: {width: oSprite.width/2, height: oSprite.height,regX:oSprite.width/4,regY:oSprite.height/2},
                animations: {  state_0: 0,state_1:1 }
            };

            var oSpriteSheet = new createjs.SpriteSheet(oData);
            var oPlatform = createSprite(oSpriteSheet, "state_1",oSprite.width/4,oSprite.height/2,oSprite.width/2,oSprite.height);
            oPlatform.x = this._oGoalPlatform.getX();
            oPlatform.y = this._oGoalPlatform.getY();
            oPlatform.alpha = 0;
            this._oContainerPlatform.addChild(oPlatform);

            var oParent = this;
            createjs.Tween.get(oPlatform).to({alpha:1}, 1000).call(function(){
                oParent.addPlatforms(bEndBonus);
            });
        }
    };

    private shakeRandPlatform = () => {
        var iRandPlatform = Math.floor(Math.random()*3);
        this._aPlatformButton[iRandPlatform].trembleAnimation();
    };

    private jumpCharacter = (iClickedIndex: any,iMult: any,bCorrectJump: any) => {
        this._bCorrectJump = bCorrectJump;
        this._iCurMultPrize = iMult;

        this._oGoalPlatform = this._aPlatformButton[iClickedIndex];
        var pPos;
        var iTime = 1000 + (iClickedIndex*200);
        var aFallingPlatform = new Array();
        if(bCorrectJump){
            pPos = {x:this._oGoalPlatform.getX(),y:77};
            for(var i=0;i<3;i++){
                if(i !== iClickedIndex){
                    aFallingPlatform.push(i);
                }
            }

            this._oCorrectPlatform = this._oGoalPlatform;
        }else{
            pPos = {x:this._oGoalPlatform.getX()+100,y:845};
            iTime += 500;

            aFallingPlatform.push(iClickedIndex);

            for(var i=0;i<3;i++){
                if(i !== iClickedIndex){
                    aFallingPlatform.push(i);
                    break;
                }
            }

            for(var k=0;k<this._aPlatformButton.length;k++){
                if(aFallingPlatform.indexOf(k) === -1){
                    this._oCorrectPlatform = this._aPlatformButton[k];
                    break;
                }
            }

        }

        //FALLING WRONG PLATFORM
        for(var j=0;j<aFallingPlatform.length;j++){
            this._aPlatformButton[aFallingPlatform[j]].moveY(CMain.CANVAS_HEIGHT,1000,0,createjs.Ease.cubicOut);
        }

        this._oCharacter.jump(pPos,iTime);

        if(this._bFinalPrize){
            //this._oContainer.swapChildren(this._oContainerPlatform,this._oCharacter.getContainer());
            this._oContainer.setChildIndex(this._oContainerPlatform,1);
            this._oContainer.setChildIndex(this._oCharacter.getContainer(),0);
        }
    };

    private _onEndJump = () => {
        var iAmount: any = 0;
        if(this._bCorrectJump){
            if(this._bEndBonus){
                this._oCharacter.hide();

                this._oGoalPlatform.playPotAnim();
                playSound("character_landing_pot",1,false);

                setTimeout(function(){CBonusPanel.s_oBonusPanel.endBonus();},1500);
            }else{
                playSound("character_landing",1,false);
                this._oCharacter.moveDown();

                createjs.Tween.get(this._oGoalPlatform.getButtonImage()).to({y:this._oGoalPlatform.getY() + 26}, 500, createjs.Ease.cubicOut).
                to({y:this._oGoalPlatform.getY() }, 500, createjs.Ease.cubicOut).call(function(){
                    CBonusPanel.s_oBonusPanel.scrollLeft();
                });
            }

            iAmount = formatEntries(this._iCurMultPrize);
            new CScoreText(iAmount,this._oCorrectPlatform.getX(),this._oCorrectPlatform.getY(),this._oContainer);
            playSound("bonus_mult",1,false);

            CBonusPanel.s_oBonusPanel.refreshScoreAmount();
        }else{
            //SHOW FINAL PANEL
            playSound("character_falling",1,false);
            setTimeout(function(){CBonusPanel.s_oBonusPanel.endBonus();},1500);
        }


    };

    private _onPlatformClick = (iIndex: any) => {
        for(var i=0;i<this._aPlatformButton.length;i++){
            this._aPlatformButton[i].setClickable(false);
        }

        this._iClickedButton = iIndex;
        CBonusPanel.s_oBonusPanel._onButtonRelease(iIndex);
    };

    private scrollLeft = (bLastPlatform: any) => {
        this._bEndBonus = bLastPlatform;
        this._removePlatforms(this._bEndBonus);

        var iNewX = this._oContainerPlatform.x - this._oGoalPlatform.getX() + 384;
        createjs.Tween.get(this._oContainer).to({x:iNewX}, 2000, createjs.Ease.cubicOut);
    };
}