import {CMain} from "./CMain";
import {createSprite, playSound} from "./ctl_utils";
import {CGame} from "./CGame";
import {CSlotSettings} from "./CSlotSettings";

export class CReelColumn {
    private _bUpdate: any;
    private _bReadyToStop: boolean = false;
    private _bContainsFinalSymbols: any;
    private _bPlayingReelStopAudio: any;
    private _iIndex: any;
    private _iCol: any;
    private _iDelay: any;
    private _iContDelay: any;
    private _iCurState: any;
    private _iCntFrames: any;
    private _iMaxFrames: any;
    private _iStartY: any;
    private _iCurStartY: any;
    private _iFinalY: any;
    private _aSymbols: any;
    private _aSymbolValues: any;
    private _oContainer: any;
    private _oParentContainer: any;

    constructor(
        iIndex: any,
        iXPos: any,
        iYPos: any,
        iDelay: any,
        aSymbols: any,
        oParentContainer: any
    ){
        this._oParentContainer = oParentContainer;
        this._init(iIndex,iXPos,iYPos,iDelay,aSymbols);
    }

    private _init = (iIndex: any,iXPos: any,iYPos: any,iDelay: any,aSymbols: any) => {
        this._bUpdate = false;
        this._bReadyToStop = false;
        this._bContainsFinalSymbols = false;
        this._bPlayingReelStopAudio = false;
        this._iContDelay = 0;
        this._iIndex = iIndex;
        this._iDelay = iDelay;

        if(this._iIndex < CMain.NUM_REELS){
            this._iCol = this._iIndex;
        }else{
            this._iCol = this._iIndex - CMain.NUM_REELS;
        }

        this._iCntFrames = 0;
        this._iMaxFrames = CMain.MAX_FRAMES_REEL_EASE;
        this._iCurState = CMain.REEL_STATE_START;
        this._iCurStartY = this._iStartY = iYPos;
        this._iFinalY = this._iCurStartY + ( (CMain.SYMBOL_HEIGHT + CMain.SPACE_HEIGHT_BETWEEN_SYMBOLS) * CMain.NUM_ROWS)-CMain.OFFSET_Y_SYMBOLS;

        this.initContainer(iXPos,iYPos,aSymbols);
    };

    private initContainer = (iXPos: any,iYPos: any,aSymbols: any) => {
        this._oContainer = new createjs.Container();
        this._oContainer.x = iXPos;
        this._oContainer.y = iYPos;

        var iX = 0;
        var iY = -CMain.OFFSET_Y_SYMBOLS;
        this._aSymbols = new Array();
        this._aSymbolValues = new Array();

        for(var i=0;i<CMain.NUM_ROWS;i++){
            var oSprite = createSprite(CSlotSettings.s_aSymbolData[aSymbols[i]], "static",0,0,CMain.SYMBOL_WIDTH,CMain.SYMBOL_HEIGHT);
            oSprite.stop();
            oSprite.x = iX;
            oSprite.y = iY;
            this._oContainer.addChild(oSprite);

            this._aSymbols[i] = oSprite;
            this._aSymbolValues[i] = aSymbols[i];

            iY += CMain.SYMBOL_HEIGHT + CMain.SPACE_HEIGHT_BETWEEN_SYMBOLS;
        }

        this._oParentContainer.addChild(this._oContainer);
    };

    private unload = () => {
        this._oParentContainer.removeChild(this._oContainer);
    };

    private activate = () => {
        this._iCurStartY = this._oContainer.y;
        this._iFinalY = this._iCurStartY + ((CMain.SYMBOL_HEIGHT + CMain.SPACE_HEIGHT_BETWEEN_SYMBOLS) * CMain.NUM_ROWS)-CMain.OFFSET_Y_SYMBOLS;
        this._bUpdate = true;
    };

    private _setSymbol = (aSymbols: any) => {

        var iX = 0;
        var iY = 0;
        for(var i=0;i<aSymbols.length;i++){
            this._aSymbols[i].spriteSheet = CSlotSettings.s_aSymbolData[aSymbols[i]];
            this._aSymbols[i].gotoAndStop("static");
            this._aSymbols[i].x = iX;
            this._aSymbols[i].y = iY;

            this._aSymbolValues[i] = aSymbols[i];

            iY += CMain.SYMBOL_HEIGHT + CMain.SPACE_HEIGHT_BETWEEN_SYMBOLS;
        }
    };

    private forceStop = (aSymbols: any,iYPos: any) => {
        if(aSymbols !== null){
            this._setSymbol(aSymbols);
        }
        this._oContainer.y = iYPos;
        this._bUpdate = false;
        this._iCntFrames = 0;
        this._iMaxFrames = CMain.MAX_FRAMES_REEL_EASE;
        this._iCurState = CMain.REEL_STATE_START;
        this._iContDelay = 0;
        this._bReadyToStop = false;
        this._bContainsFinalSymbols = false;
    };

    private setVisible = (iRow: any,bVisible: any) => {
        this._aSymbols[iRow].visible = bVisible;
    };

    private restart = (aSymbols: any,bReadyToStop: any) => {
        this._oContainer.y = this._iCurStartY = CMain.REEL_START_Y;
        this._iFinalY = this._iCurStartY + ((CMain.SYMBOL_HEIGHT + CMain.SPACE_HEIGHT_BETWEEN_SYMBOLS) * CMain.NUM_ROWS)-CMain.OFFSET_Y_SYMBOLS;
        this._setSymbol(aSymbols);

        this._bReadyToStop = bReadyToStop;
        if (this._bReadyToStop) {
            this._iCntFrames = 0;
            this._iMaxFrames = CMain.MAX_FRAMES_REEL_EASE;
            this._iCurState = CMain.REEL_STATE_STOP;
            for (var i = 0; i < CMain.NUM_ROWS; i++) {
                this._aSymbols[i].gotoAndStop("static");
            }
            this._bContainsFinalSymbols = true;

        }else{
            for (var i = 0; i < CMain.NUM_ROWS; i++) {
                this._aSymbols[i].gotoAndStop("moving");
            }
        }
    };

    private setReadyToStop = () => {
        this._iCntFrames = 0;
        this._iMaxFrames = CMain.MAX_FRAMES_REEL_EASE;
        this._iCurState = CMain.REEL_STATE_STOP;
    };

    private isReadyToStop = (): boolean => {
        return this._bReadyToStop;
    };

    private getPosUpLeft = (iRow: any) => {
        var iX = this._oContainer.x;
        var iY = this._oContainer.y + (CMain.SYMBOL_HEIGHT + CMain.SPACE_HEIGHT_BETWEEN_SYMBOLS) * iRow;
        return {x:iX,y:iY};
    };

    private getY = () => {
        return this._oContainer.y;
    };

    private _updateStart = () => {
        if(this._iCntFrames === 0 && this._iIndex < CMain.NUM_REELS){
            playSound("start_reel",1,false);
        }

        this._iCntFrames++;
        if ( this._iCntFrames > this._iMaxFrames ){
            this._iCntFrames = 0;
            this._iMaxFrames /= 2;
            this._iCurState++;
            this._iCurStartY = this._oContainer.y;
            this._iFinalY = this._iCurStartY + ((CMain.SYMBOL_HEIGHT + CMain.SPACE_HEIGHT_BETWEEN_SYMBOLS) * CMain.NUM_ROWS)-CMain.OFFSET_Y_SYMBOLS;
        }

        var fLerpY = CGame.s_oTweenController.easeInBack( this._iCntFrames, 0 ,1, this._iMaxFrames);

        var iValue = CGame.s_oTweenController.tweenValue( this._iCurStartY, this._iFinalY, fLerpY);
        this._oContainer.y = iValue;
    };

    private _updateMoving = () => {
        this._iCntFrames++;
        if ( this._iCntFrames > this._iMaxFrames ){
            this._iCntFrames = 0;
            this._iCurStartY = this._oContainer.y;
            this._iFinalY = this._iCurStartY + ( (CMain.SYMBOL_HEIGHT + CMain.SPACE_HEIGHT_BETWEEN_SYMBOLS)* CMain.NUM_ROWS)-CMain.OFFSET_Y_SYMBOLS;
        }

        var fLerpY = CGame.s_oTweenController.easeLinear( this._iCntFrames, 0 ,1, this._iMaxFrames);
        var iValue = CGame.s_oTweenController.tweenValue( this._iCurStartY, this._iFinalY, fLerpY);
        this._oContainer.y = iValue;
    };

    private _updateStopping = () => {
        this._iCntFrames++;

        if ( this._iCntFrames >= this._iMaxFrames ){
            this._bUpdate = false;
            this._iCntFrames = 0;
            this._iMaxFrames = CMain.MAX_FRAMES_REEL_EASE;
            this._iCurState = CMain.REEL_STATE_START;
            this._iContDelay = 0;
            this._bReadyToStop = false;
            this._bPlayingReelStopAudio = false;

            if(this._bContainsFinalSymbols){
                this._bContainsFinalSymbols = false;
                this._oContainer.y = this._iFinalY;
            }

            CGame.s_oGame?.stopNextReel();
        }else{
            var fLerpY = CGame.s_oTweenController.easeOutBack( this._iCntFrames, 0 ,1, this._iMaxFrames);
            var iValue = CGame.s_oTweenController.tweenValue( this._iCurStartY, this._iFinalY, fLerpY);
            this._oContainer.y = iValue;


            if(this._bPlayingReelStopAudio === false && this._iCntFrames >= (this._iMaxFrames*0.7) && this._bContainsFinalSymbols){
                this._bPlayingReelStopAudio = true;
                if((this._aSymbolValues[0] === CMain.BONUS_SYMBOL || this._aSymbolValues[1] === CMain.BONUS_SYMBOL || this._aSymbolValues[2] === CMain.BONUS_SYMBOL ) ){
                    playSound("reel_stop_bonus",1,false);
                }else if((this._aSymbolValues[0] === CMain.FREESPIN_SYMBOL || this._aSymbolValues[1] === CMain.FREESPIN_SYMBOL || this._aSymbolValues[2] === CMain.FREESPIN_SYMBOL )){
                    playSound("reel_stop_freespin",1,false);
                }else{
                    playSound("reel_stop",1,false);
                }
            }
        }
    };

    private update = () => {
        if (this._bUpdate === false) {
            return;
        }

        this._iContDelay++;

        if (this._iContDelay > this._iDelay) {
            if(this._bReadyToStop === false && (this._oContainer.y > CMain.REEL_ARRIVAL_Y) && this._iCurState !== CMain.REEL_STATE_STOP){
                CGame.s_oGame?.reelArrived(this._iIndex, this._iCol);
            }
            switch(this._iCurState) {
                case CMain.REEL_STATE_START: {
                    this._updateStart();
                    break;
                }
                case CMain.REEL_STATE_MOVING: {
                    this._updateMoving();
                    break;
                }
                case CMain.REEL_STATE_STOP: {
                    this._updateStopping();
                    break;
                }
            }
        }
    };
}