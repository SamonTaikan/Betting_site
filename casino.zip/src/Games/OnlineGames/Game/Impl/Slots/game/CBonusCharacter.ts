import {createSprite, playSound} from "./ctl_utils";
import {CMain} from "./CMain";

export class CBonusCharacter {

    private _pStartPos: any;
    private _aCbCompleted: any;
    private _aCbOwner: any;
    private _oFinalPosInfos: any;

    private _oAnimIdle: any;
    private _oAnimJump: any;
    private _oContainer: any;
    private _oParentContainer: any;

    constructor(
        iX: any,
        iY: any,
        oParentContainer: any
    ){
        this._oParentContainer = oParentContainer;
        this._init(iX,iY);
    }

    private _init = (iX: any,iY: any) => {
        this._pStartPos = {x:iX,y:iY};
        this._aCbCompleted=new Array();
        this._aCbOwner =new Array();

        this._oContainer = new createjs.Container();
        this._oContainer.x = iX;
        this._oContainer.y = iY;
        this._oParentContainer.addChild(this._oContainer);

        var aSprites = new Array();
        for(var k=0;k<119;k++){
            aSprites.push(CMain.s_oSpriteLibrary!!.getSprite("character_idle_"+k));
        }

        var oData = {
            images: aSprites,
            // width, height & registration point of each sprite
            frames: {width: 276, height: 257, regX: 138, regY: 257},
            animations: {start:0,anim:[0,118]}
        };

        var oSpriteSheet = new createjs.SpriteSheet(oData);
        this._oAnimIdle = createSprite(oSpriteSheet, "start",138,257,276,257);
        this._oContainer.addChild(this._oAnimIdle);


        aSprites = new Array();
        for(var k=0;k<97;k++){
            aSprites.push(CMain.s_oSpriteLibrary!!.getSprite("character_jump_"+k));
        }

        // @ts-ignore
        var oData = {
            images: aSprites,
            // width, height & registration point of each sprite
            frames: {width: 276, height: 257, regX: 138, regY: 257},
            //animations: {start:0,start_jump:[0,8,"before_jump"],before_jump:[9,12,"jumping"],jumping:[13,28],landing:[29,47,"start"]}
            animations: {start:0,start_jump:[0,10,"before_jump"],"before_jump":[11,28,"jumping"],jumping:[29,57],landing:[58,96,"start"]}
        };

        var oSpriteSheet = new createjs.SpriteSheet(oData);
        this._oAnimJump = createSprite(oSpriteSheet, "start",138,257,276,257);
        this._oContainer.addChild(this._oAnimJump);
        this._oAnimJump.on("animationend",this._onEndAnimJump,this);
    };

    private addEventListener = ( iEvent: any,cbCompleted: any, cbOwner: any ) => {
        this._aCbCompleted[iEvent]=cbCompleted;
        this._aCbOwner[iEvent] = cbOwner;
    };

    private hide = () => {
        this._oAnimIdle.visible = false;
        this._oAnimJump.visible = false;
        this._oAnimJump.gotoAndStop("start");
        this._oAnimIdle.gotoAndStop("start");
    };

    private reset = () => {
        this._oContainer.x = this._pStartPos.x;
        this._oContainer.y = this._pStartPos.y;
    };

    private idle = () => {
        this._oAnimIdle.visible = true;
        this._oAnimJump.visible = false;
        this._oAnimJump.gotoAndStop("start");
        this._oAnimIdle.gotoAndPlay("anim");
    };

    private jump = (pPos: any,iTime: any) => {
        this._oFinalPosInfos = {pos:pPos,time:iTime};

        this._oAnimIdle.visible = false;
        this._oAnimJump.visible = true;
        this._oAnimIdle.gotoAndStop("start");
        this._oAnimJump.gotoAndPlay("start_jump");

        playSound("character_jump",1,false);
    };

    private _onEndAnimJump = (evt: any) => {
        if(evt.name === "start_jump"){
            var iTime = this._oFinalPosInfos.time;
            var pPos = this._oFinalPosInfos.pos;

            var iHeight = 200 + Math.random()*50;
            createjs.Tween.get(this._oContainer).to({y:this._oContainer.y - iHeight}, iTime/2, createjs.Ease.cubicOut).to({y: pPos.y}, iTime/2, createjs.Ease.cubicIn);
            const _oThis = this;
            createjs.Tween.get(this._oContainer).to({x:pPos.x}, iTime, createjs.Ease.linear).call(function(){
                _oThis.endJump();
            });
        }
    };

    private endJump = () => {
        this._oAnimJump.gotoAndPlay("landing");

        if(this._aCbCompleted[CMain.ON_CHARACTER_END_JUMP]){
            this._aCbCompleted[CMain.ON_CHARACTER_END_JUMP].call(this._aCbOwner[CMain.ON_CHARACTER_END_JUMP]);
        }
    };

    private moveDown = () => {
        const _oThis = this;
        createjs.Tween.get(this._oAnimJump).to({y:this._oAnimJump.y + 20}, 500, createjs.Ease.cubicOut).to({y:this._oAnimJump.y }, 500, createjs.Ease.cubicOut).call(function(){
            _oThis.idle();
        });
    };

    private getX = () => {
        return this._oContainer.x;
    };

    private getContainer = () => {
        return this._oContainer;
    };

}