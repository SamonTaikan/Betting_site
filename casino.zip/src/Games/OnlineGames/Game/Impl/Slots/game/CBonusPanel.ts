import {createBitmap, createSprite, formatEntries, playSound, setVolume, stopSound} from "./ctl_utils";
import {CMain} from "./CMain";
import {CGame} from "./CGame";
import {CBonusPlatformController} from "./CBonusPlatformController";
import {CBonusParallax} from "./CBonusParallax";
import {CBonusResultPanel} from "./CBonusResultPanel";

export class CBonusPanel{
    public static s_oBonusPanel: CBonusPanel;
    private _bUpdate: any;
    private _bSpriteLoaded = false;
    private _bFinalPriz: any;
    private _iGameState: any;
    private _iMaskWidth: any;
    private _iMaskHeight: any;
    private _iCurResourcesght: any;
    private _iTotResources: any;
    private _iTotWin: any;
    private _iCurBet: any;
    private _iCurMult: any;
    private _aBonusSeqrMult: any;
    private _oMaskPreloader: any;
    private _oListenerBlock: any;
    private _pStartPosScore: any;

    private _oBg: any;
    private _oBgLoading: any;
    private _oLoadingText: any;
    private _oProgressBar: any;
    private _oParallax: any;
    private _oPlatform: any;
    private _oResultPanel: any;
    private _oScoreText: any = null;
    private _oSparkleRainbow: any;
    private _oTextInstructions: any;
    private _oMultAmountText: any;
    private _oContainerScore: any;
    private _oBlock: any;
    private _oContainer: any;

    constructor(){
        CBonusPanel.s_oBonusPanel = this;
    }

    private _init = () => {
        this._bUpdate = false;
        this._bSpriteLoaded = true;
        this._iGameState = -1;

        this._oContainer.removeAllChildren();
        this._oContainer.visible = false;
        if (!CMain.s_oSpriteLibrary) return;

        var oSpriteBg = CMain.s_oSpriteLibrary.getSprite('bg_bonus');
        this._oBg = createBitmap(oSpriteBg);
        this._oContainer.addChild(this._oBg);

        this._oBlock = new createjs.Shape();
        this._oBlock.graphics.beginFill("rgba(0,0,0,0.01)").drawRect(0,0, CMain.CANVAS_WIDTH,CMain.CANVAS_HEIGHT);
        this._oListenerBlock = this._oBlock.on("click",function(){});
        this._oContainer.addChild(this._oBlock);

        var aSprites = new Array();
        for(var t=0;t<76;t++){
            aSprites.push(CMain.s_oSpriteLibrary.getSprite("particle_rainbow_"+t));
        }

        var oData = {
            images: aSprites,
            // width, height & registration point of each sprite
            frames: {width: 800, height: 260},
            animations: {start:0,anim:[0,75]}
        };

        var oSpriteSheet = new createjs.SpriteSheet(oData);
        this._oSparkleRainbow = createSprite(oSpriteSheet, "start",0,0,800,260);
        this._oSparkleRainbow.x = 584;
        this._oSparkleRainbow.y = 132;
        this._oContainer.addChild(this._oSparkleRainbow);

        this._oParallax = new CBonusParallax(0,CMain.CANVAS_HEIGHT,this._oContainer);

        this._oPlatform = new CBonusPlatformController(0,580,this._oContainer);

        this._pStartPosScore = {x:10,y:10};
        this._oContainerScore = new createjs.Container();
        this._oContainerScore.x = this._pStartPosScore.x;
        this._oContainerScore.y = this._pStartPosScore.y;
        this._oContainer.addChild(this._oContainerScore);

        var oSpiteScoreBg = CMain.s_oSpriteLibrary.getSprite("amount_bonus_win");
        var oBgScore = createBitmap(oSpiteScoreBg);
        this._oContainerScore.addChild(oBgScore);

        this._oMultAmountText = new createjs.Text(formatEntries(0),"56px "+CMain.FONT_GAME_1, "#fede00");
        this._oMultAmountText.textAlign="center";
        this._oMultAmountText.textBaseline = "alphabetic";
        this._oMultAmountText.x = oSpiteScoreBg.width/2;
        this._oMultAmountText.y = 64;
        this._oContainerScore.addChild(this._oMultAmountText);

        this._oTextInstructions = new createjs.Text(CMain.TEXT_BONUS_HELP,"60px "+CMain.FONT_GAME_1, "#fede00");
        this._oTextInstructions.x = CMain.CANVAS_WIDTH/2;
        this._oTextInstructions.y = 150;
        this._oTextInstructions.textAlign = "center";
        this._oTextInstructions.textBaseline = "alphabetic";
        this._oTextInstructions.lineWidth = 900;
        this._oTextInstructions.shadow = new createjs.Shadow("#000", 1, 1, 1);
        this._oContainer.addChild(this._oTextInstructions);


        this._startBonus();
    };
    private _loadAllResources = () => {

        this._oContainer = new createjs.Container();
        CMain.s_oAttachSection.addChild(this._oContainer);
        if (!CMain.s_oSpriteLibrary) return;

        var oSprite = CMain.s_oSpriteLibrary.getSprite('bg_loading_bonus');
        this._oBgLoading = createBitmap(oSprite);
        this._oContainer.addChild(this._oBgLoading);

        var oSprite = CMain.s_oSpriteLibrary.getSprite('progress_bar');
        this._oProgressBar  = createBitmap(oSprite);
        this._oProgressBar.x = CMain.CANVAS_WIDTH/2 - (oSprite.width/2);
        this._oProgressBar.y = CMain.CANVAS_HEIGHT - 91;
        this._oContainer.addChild(this._oProgressBar);

        this._iMaskWidth = oSprite.width;
        this._iMaskHeight = oSprite.height;
        this._oMaskPreloader = new createjs.Shape();
        this._oMaskPreloader.graphics.beginFill("rgba(255,255,255,0.01)").drawRect(this._oProgressBar.x, this._oProgressBar.y, 1,this._iMaskHeight);
        this._oContainer.addChild(this._oMaskPreloader);

        this._oProgressBar.mask = this._oMaskPreloader;

        this._oLoadingText = new createjs.Text("","21px "+CMain.FONT_GAME_1, "#fff");
        this._oLoadingText.x = CMain.CANVAS_WIDTH/2;
        this._oLoadingText.y = CMain.CANVAS_HEIGHT - 59;
        this._oLoadingText.shadow = new createjs.Shadow("#000", 2, 2, 2);
        this._oLoadingText.textBaseline = "alphabetic";
        this._oLoadingText.textAlign = "center";
        this._oContainer.addChild(this._oLoadingText);

        CMain.s_oSpriteLibrary.init( this._onResourceBonusLoaded,this._onAllImagesLoaded, this );

        //LOAD BONUS SPRITES
        CMain.s_oSpriteLibrary.addSprite("bg_bonus","./sprites/bonus/bg_bonus.jpg");
        CMain.s_oSpriteLibrary.addSprite("platform_0","./sprites/bonus/platform_0.png");
        CMain.s_oSpriteLibrary.addSprite("platform_1","./sprites/bonus/platform_1.png");
        CMain.s_oSpriteLibrary.addSprite("platform_2","./sprites/bonus/platform_2.png");
        CMain.s_oSpriteLibrary.addSprite("platform_3","./sprites/bonus/platform_3.png");
        CMain.s_oSpriteLibrary.addSprite("rock_0","./sprites/bonus/rock_0.png");
        CMain.s_oSpriteLibrary.addSprite("rock_1","./sprites/bonus/rock_1.png");

        for(var t=0;t<76;t++){
            CMain.s_oSpriteLibrary.addSprite("particle_rainbow_"+t,"./sprites/bonus/particle_rainbow/particle_rainbow_"+t+".png");
        }

        for(var k=0;k<119;k++){
            CMain.s_oSpriteLibrary.addSprite("character_idle_"+k,"./sprites/bonus/character/idle/character_idle_"+k+".png");
        }

        for(var k=0;k<97;k++){
            CMain.s_oSpriteLibrary.addSprite("character_jump_"+k,"./sprites/bonus/character/jump/character_jump_"+k+".png");
        }

        for(var k=0;k<56;k++){
            CMain.s_oSpriteLibrary.addSprite("character_pot_"+k,"./sprites/bonus/character/pot/character_pot_"+k+".png");
        }

        this._iCurResourcesght = 0;

        this._iTotResources = CMain.s_oSpriteLibrary.getNumSprites();
        if(this._iTotResources === 0){
            this._startBonus();
        }else{
            CMain.s_oSpriteLibrary.loadSprites();
        }

    };
    // CALLBACK FOR LOADED RESOURCES
    private _onResourceBonusLoaded = () => {
        this._iCurResourcesght++;
        var iPerc = Math.floor(this._iCurResourcesght/this._iTotResources *100);
        this._oLoadingText.text = iPerc+"%";
        this._oMaskPreloader.graphics.clear();
        var iNewMaskWidth = Math.floor((iPerc*this._iMaskWidth)/100);
        this._oMaskPreloader.graphics.beginFill("rgba(255,255,255,0.01)").drawRect(this._oProgressBar.x, this._oProgressBar.y, iNewMaskWidth,this._iMaskHeight);

        if(this._iCurResourcesght === this._iTotResources){
            this._init();
        }
    };
    private refreshButtonPos = () => {
        if(this._oContainerScore !== undefined){
            this._oContainerScore.x = this._pStartPosScore.x + CGame.s_iOffsetX;
            this._oContainerScore.y = this._pStartPosScore.y + CGame.s_iOffsetY;
        }
    };
    private unload = () => {
        this._oBlock.off("click",this._oListenerBlock);

        this._oPlatform.unload();
    };
    private _onAllImagesLoaded = () => {

    };
    private reset = () => {
        this._oResultPanel.unload();
        this._oPlatform.reset();

        if(this._oScoreText !== null){
            this._oScoreText.unload();
            this._oScoreText = null;
        }

        this._oMultAmountText.text = formatEntries(0);

        this._oParallax.reset();
        this._oSparkleRainbow.gotoAndStop("start");
    };
    private show = (aBonusSeq: any,iCurBet: any,bFinalPrize: any) => {
        this._iCurBet = iCurBet;
        this._aBonusSeqrMult = aBonusSeq;

        this._bFinalPriz = bFinalPrize;


        if(this._bSpriteLoaded){
            this._startBonus();
        }else{
            this._loadAllResources();
        }
    };
    public hide = () => {
        this._bUpdate = false;

        stopSound("soundtrack_bonus");
        setVolume("ambience_game",1);

        this._oBg.off("click",function(){});
        this._oContainer.visible = false;

        this.reset();
        CGame.s_oGame?.exitFromBonus(this._iTotWin);
    };
    private _startBonus = () => {
        this._iTotWin = 0;

        playSound("soundtrack_bonus",1,true);


        this._oSparkleRainbow.gotoAndPlay("anim");

        this._oPlatform.startBonus(this._iCurBet);
        this._oTextInstructions.alpha = 0;
        createjs.Tween.get(this._oTextInstructions).to({alpha:1}, 800);

        this._oBg.on("click",function(){});
        this._oContainer.visible = true;
        this._bUpdate = true;
        this._iGameState = CMain.STATE_BONUS_IDLE;

        this.refreshButtonPos();
    };
    public endBonus = () => {
        this._oResultPanel = new CBonusResultPanel(this._iTotWin,this._oContainer);

        if(this._bFinalPriz){
            playSound("bonus_end_win",1,false);
        }else{
            playSound("bonus_end",1,false);
        }
        stopSound("soundtrack_bonus");
    };
    public refreshScoreAmount = () => {
        this._oMultAmountText.text = formatEntries(this._iTotWin);
    };
    private prepareForJump = (iClickedIndex: any) => {
        if(this._aBonusSeqrMult.length-1 === 0){
            /*if(this._bFinalPriz){
                //REACH GOLD POT
                this._oPlatform.jumpCharacter(iClickedIndex,this._aBonusSeqrMult[0],true);
            }else{*/
            //MAKE A RIGHT JUMP
            this._iCurMult = this._aBonusSeqrMult.shift();
            this._iTotWin += this._iCurMult//*this._iCurBet;
            this._oPlatform.jumpCharacter(iClickedIndex,this._iCurMult,true);
            //}
        }else if(this._aBonusSeqrMult.length === 0){
            this._oPlatform.jumpCharacter(iClickedIndex,0,false);
        }else{
            this._iCurMult = this._aBonusSeqrMult.shift();
            this._iTotWin += this._iCurMult//*this._iCurBet;

            //MAKE A RIGHT JUMP
            this._oPlatform.jumpCharacter(iClickedIndex,this._iCurMult,true);
        }
    };
    public scrollLeft = () => {
        var bLastPlatform = false;

        if(this._aBonusSeqrMult.length-1 === 0){
            if(this._bFinalPriz){
                //REACH GOLD POT
                bLastPlatform = true;
            }
        }else if(this._aBonusSeqrMult.length === 0){
            var iRand = Math.random();

            bLastPlatform = iRand>0.5?true:false;
        }

        this._oPlatform.scrollLeft(bLastPlatform);
        this._oParallax.scrollLeft();

        createjs.Tween.get(this._oTextInstructions).to({alpha:1}, 800);
    };
    public _onButtonRelease = (iIndex: any) => {
        createjs.Tween.get(this._oTextInstructions).to({alpha:0}, 500);
        CBonusPanel.s_oBonusPanel!!.prepareForJump(iIndex);
    };
}