import {createSprite, playSound} from "./ctl_utils";
import {CMain} from "./CMain";

export class CBetBut{
    private _bDisable: any;
    private iXPos: any;
    private iYPos: any;
    private _szLabel: any;
    private _aCbCompleted: any;
    private _aCbOwner: any;
    private _aParams: any = [];

    private _oButton: any;
    private _oContainer: any;
    private _oParentContainertainer: any;

    constructor(
        iXPos: any,
        iYPos: any,
        szLabel: any,
        oParentContainer: any
    ) {
        this.iXPos = iXPos;
        this.iYPos = iYPos;
        this._szLabel = szLabel;
        this._oParentContainertainer = oParentContainer;
        this._oParentContainertainer = oParentContainer;
        this._init(iXPos,iYPos,szLabel);
    }
    private _init = (iXPos: any,iYPos: any,szLabel: any) => {
        this._bDisable = false;

        this._aCbCompleted = new Array();
        this._aCbOwner = new Array();

        this._oContainer = new createjs.Container();
        this._oContainer.x = iXPos;
        this._oContainer.y = iYPos;
        this._oParentContainertainer.addChild(this._oContainer);

        var oData = {   // image to use
            images: [CMain.s_oSpriteLibrary!!.getSprite("bet_but")],
            // width, height & registration point of each sprite
            frames: {width: 102, height: 82},
            animations: {
                bet_but1_on: 0, bet_but1_off: 1,
                bet_but2_on: 2, bet_but2_off: 3,
                bet_but3_on: 4, bet_but3_off: 5,
                bet_but4_on: 6, bet_but4_off: 7,
                bet_but5_on: 8, bet_but5_off: 9,
                bet_but6_on: 10, bet_but6_off: 11,
                bet_but7_on: 12, bet_but7_off: 13,
                bet_but8_on: 14, bet_but8_off: 15,
                bet_but9_on: 16, bet_but9_off: 17,
                bet_but10_on: 18, bet_but10_off: 19,
                bet_but11_on: 20, bet_but11_off: 21,
                bet_but12_on: 22, bet_but12_off: 23,
                bet_but13_on: 24, bet_but13_off: 25,
                bet_but14_on: 26, bet_but14_off: 27,
                bet_but15_on: 28, bet_but15_off: 29,
                bet_but16_on: 30, bet_but16_off: 31,
                bet_but17_on: 32, bet_but17_off: 33,
                bet_but18_on: 34, bet_but18_off: 35,
                bet_but19_on: 36, bet_but19_off: 37,
                bet_but20_on: 38, bet_but20_off: 39
            }
        };

        var oSpriteSheet = new createjs.SpriteSheet(oData);
        this._oButton = createSprite(oSpriteSheet, szLabel + "_on", 0, 0, 102, 82);
        this._oButton.stop();
        this._oButton.cursor = "pointer";
        this._oContainer.addChild(this._oButton);

        this._initListener();
    }

    private unload = () => {
        this._oButton.off("mousedown", this.buttonDown);
        this._oButton.off("pressup", this.buttonRelease);

        this._oParentContainertainer.removeChild(this._oButton);
    }

    private disable = (bDisable: any) => {
        this._bDisable = bDisable;
    }

    private setVisible = (bVisible: any) => {
        this._oButton.visible = bVisible;
    }

    private setOn = () => {
        this._oButton.gotoAndStop(this._szLabel + "_on");
    }

    private setOff = () => {
        this._oButton.gotoAndStop(this._szLabel + "_off");
    }

    private _initListener = () => {
        this._oButton.on("mousedown", this.buttonDown);
        this._oButton.on("pressup", this.buttonRelease);
    }

    private addEventListener = ( iEvent: any,cbCompleted: any, cbOwner: any ) => {
        this._aCbCompleted[iEvent] = cbCompleted;
        this._aCbOwner[iEvent] = cbOwner;
    }

    public addEventListenerWithParams = (iEvent: any,cbCompleted: any, cbOwner: any,aParams: any) => {
        this._aCbCompleted[iEvent] = cbCompleted;
        this._aCbOwner[iEvent] = cbOwner;
        this._aParams = aParams;
    }

    private buttonRelease = () => {
        if (this._aCbCompleted[CMain.ON_MOUSE_UP] && this._bDisable === false) {
            playSound("press_but", 1, false);

            this._aCbCompleted[CMain.ON_MOUSE_UP].call(this._aCbOwner[CMain.ON_MOUSE_UP], this._aParams);
        }
    }

    private buttonDown = () => {
        if (this._aCbCompleted[CMain.ON_MOUSE_DOWN] && this._bDisable === false) {
            this._aCbCompleted[CMain.ON_MOUSE_DOWN].call(this._aCbOwner[CMain.ON_MOUSE_DOWN], this._aParams);
        }
    }

    private setPosition = (iXPos: any,iYPos: any) => {
        this._oButton.x = iXPos;
        this._oButton.y = iYPos;
    }

    private setX = (iXPos: any) => {
        this._oButton.x = iXPos;
    }

    private setY = (iYPos: any) => {
        this._oButton.y = iYPos;
    }

    private getButtonImage = () => {
        return this._oButton;
    }

    private getX = () => {
        return this._oButton.x;
    }

    private getY = () => {
        return this._oButton.y;
    }
}