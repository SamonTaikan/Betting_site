import {createSprite, playSound} from "./ctl_utils";
import {CMain} from "./CMain";

export class CToggle{

    private _bActive: boolean = false;
    private _aCbCompleted: any;
    private _aCbOwner: any;
    private _oButton: any;
    private _oListenerMouseDown: any;
    private _oListenerMouseUp: any;
    private _oParentContainer: any;

    private _init = (iXPos: any, iYPos: any, oSprite: any, bActive: any, oParentContainer: any) => {
        if (oParentContainer !== undefined) {
            this._oParentContainer = oParentContainer;
        } else {
            this._oParentContainer = CMain.s_oStage;
        }

        this._aCbCompleted = new Array();
        this._aCbOwner = new Array();

        var oData = {
            images: [oSprite],
            // width, height & registration point of each sprite
            frames: {width: oSprite.width / 2, height: oSprite.height, regX: (oSprite.width / 2) / 2, regY: oSprite.height / 2},
            animations: {state_true: [0], state_false: [1]}
        };


        var oSpriteSheet = new createjs.SpriteSheet(oData);

        this._bActive = bActive;

        this._oButton = createSprite(oSpriteSheet, "state_" + this._bActive, (oSprite.width / 2) / 2, oSprite.height / 2, oSprite.width / 2, oSprite.height);

        this._oButton.x = iXPos;
        this._oButton.y = iYPos;
        this._oButton.stop();

        if (!CMain.s_bMobile)
            this._oButton.cursor = "pointer";

        this._oParentContainer.addChild(this._oButton);

        this._initListener();
    };
    private unload = () => {
        this._oButton.off("mousedown", this._oListenerMouseDown);
        this._oButton.off("pressup", this._oListenerMouseUp);

        this._oParentContainer.removeChild(this._oButton);
    };
    private _initListener = () => {
        this._oListenerMouseDown = this._oButton.on("mousedown", this.buttonDown);
        this._oListenerMouseUp = this._oButton.on("pressup", this.buttonRelease);
    };
    private addEventListener = (iEvent: any, cbCompleted: any, cbOwner: any) => {
        this._aCbCompleted[iEvent] = cbCompleted;
        this._aCbOwner[iEvent] = cbOwner;
    };
    private setCursorType = (szValue: any) => {
        this._oButton.cursor = szValue;
    };
    private setActive = (bActive: any) => {
        this._bActive = bActive;
        this._oButton.gotoAndStop("state_" + this._bActive);
    };
    private buttonRelease = () => {
        this._oButton.scaleX = 1;
        this._oButton.scaleY = 1;


        playSound("press_but",1,false);


        this._bActive = !this._bActive;
        this._oButton.gotoAndStop("state_" + this._bActive);

        if (this._aCbCompleted[CMain.ON_MOUSE_UP]) {
            this._aCbCompleted[CMain.ON_MOUSE_UP].call(this._aCbOwner[CMain.ON_MOUSE_UP], this._bActive);
        }
    };
    private buttonDown = () => {
        this._oButton.scaleX = 0.9;
        this._oButton.scaleY = 0.9;

        if (this._aCbCompleted[CMain.ON_MOUSE_DOWN]) {
            this._aCbCompleted[CMain.ON_MOUSE_DOWN].call(this._aCbOwner[CMain.ON_MOUSE_DOWN]);
        }
    };
    private setPosition = (iX: any, iY: any) => {
        this._oButton.x = iX;
        this._oButton.y = iY;
    };

    constructor(
        iXPos: any,
        iYPos: any,
        oSprite: any,
        bActive: boolean,
        oParentContainer?: any
    ) {
        this._init(iXPos, iYPos, oSprite, bActive, oParentContainer);
    }
}