import {createBitmap} from "./ctl_utils";
import {CMain} from "./CMain";

export class CBonusParallax {

    private _oContainer: any;
    private _oParentContainer:any;

    private _init = (iX: any,iY: any) => {
        this._oContainer = new createjs.Container();
        this._oContainer.x = iX;
        this._oContainer.y = iY;
        this._oParentContainer.addChild(this._oContainer);

        var oSprite = CMain.s_oSpriteLibrary!!.getSprite("rock_0");
        var oRock = createBitmap(oSprite);
        oRock.regY = oSprite.height;
        oRock.x = -50;
        oRock.y = 0;
        this._oContainer.addChild(oRock);

        oSprite = CMain.s_oSpriteLibrary!!.getSprite("rock_1");
        var oRock = createBitmap(oSprite);
        oRock.regY = oSprite.height;
        oRock.x = 1000;
        oRock.y = 100;
        this._oContainer.addChild(oRock);


        var oSprite = CMain.s_oSpriteLibrary!!.getSprite("rock_0");
        var oRock = createBitmap(oSprite);
        oRock.regY = oSprite.height;
        oRock.x = 2600;
        oRock.y = 200;
        oRock.scaleX = -1;
        this._oContainer.addChild(oRock);

        oSprite = CMain.s_oSpriteLibrary!!.getSprite("rock_1");
        var oRock = createBitmap(oSprite);
        oRock.regY = oSprite.height;
        oRock.x = 3500;
        oRock.y = 150;
        this._oContainer.addChild(oRock);

    };
    private reset = () => {
        this._oContainer.x = 0;
    };
    private scrollLeft = () => {
        createjs.Tween.get(this._oContainer).to({x:this._oContainer.x - 100 }, 2000, createjs.Ease.cubicOut);
    };
    constructor(
        iX: any,
        iY: any,
        oParentContainer: any
    ){
        this._oParentContainer = oParentContainer;
        this._init(iX,iY);
    }
}