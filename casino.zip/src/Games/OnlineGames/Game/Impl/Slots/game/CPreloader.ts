import {CMain} from "./CMain";
import {createBitmap} from "./ctl_utils";

export class CPreloader {

    private _iMaskWidth: number = 0;
    private _iMaskHeight: number = 0;
    private static _oLoadingText: any;
    private static _oProgressBar?: any;
    private static _oMaskPreloader?: any;
    private _oFade?: any;
    private _oIcon?: any;
    private _oIconMask?: any;
    private _oContainer?: any;

    constructor() {
        this._init();
    }

    private _init = () => {
        CMain.s_oSpriteLibrary!!.init(this._onImagesLoaded, this._onAllImagesLoaded, this);
        CMain.s_oSpriteLibrary!!.addSprite("progress_bar", "http://localhost:3000/assets/games/online/slots/sprites/progress_bar.png");
        CMain.s_oSpriteLibrary!!.addSprite("200x200", "http://localhost:3000/assets/games/online/slots/sprites/200x200.jpg");
        CMain.s_oSpriteLibrary!!.loadSprites();

        this._oContainer = new createjs.Container();
        // s_oStage.addChild(_oContainer);

    };
    public unload = () => {
        this._oContainer.removeAllChildren();
    };
    public _onImagesLoaded = () => {};
    public _onAllImagesLoaded = () => {

        this.attachSprites();

        CMain.s_oMain.preloaderReady();

    };
    public attachSprites = () => {
        console.log("Attaching sprites!!")
        var oBg = new createjs.Shape();
        oBg.graphics.beginFill("black").drawRect(0, 0, CMain.CANVAS_WIDTH, CMain.CANVAS_HEIGHT);
        this._oContainer.addChild(oBg);

        var oSprite = CMain.s_oSpriteLibrary!!.getSprite('200x200');
        this._oIcon = createBitmap(oSprite);
        this._oIcon.regX = oSprite.width * 0.5;
        this._oIcon.regY = oSprite.height * 0.5;
        this._oIcon.x = CMain.CANVAS_WIDTH/2;
        this._oIcon.y = CMain.CANVAS_HEIGHT/2 - 120;
        // _oContainer.addChild(_oIcon);

        this._oIconMask = new createjs.Shape();
        this._oIconMask.graphics.beginFill("rgba(0,0,0,0.01)").drawRoundRect(this._oIcon.x - 100, this._oIcon.y - 100, 200, 200, 10);
        this._oContainer.addChild(this._oIconMask);

        this._oIcon.mask = this._oIconMask;

        var oSprite = CMain.s_oSpriteLibrary!!.getSprite('progress_bar');
        CPreloader._oProgressBar = createBitmap(oSprite);
        CPreloader._oProgressBar.x = CMain.CANVAS_WIDTH/2 - (oSprite.width / 2);
        CPreloader._oProgressBar.y = CMain.CANVAS_HEIGHT/2 + 50;
        this._oContainer.addChild(CPreloader._oProgressBar);

        this._iMaskWidth = oSprite.width;
        this._iMaskHeight = oSprite.height;
        CPreloader._oMaskPreloader = new createjs.Shape();
        CPreloader._oMaskPreloader.graphics.beginFill("rgba(0,0,0,0.01)").drawRect(CPreloader._oProgressBar.x, CPreloader._oProgressBar.y, 1, this._iMaskHeight);

        this._oContainer.addChild(CPreloader._oMaskPreloader);

        CPreloader._oProgressBar.mask = CPreloader._oMaskPreloader;

        CPreloader._oLoadingText = new createjs.Text("", "30px " + CMain.FONT_GAME_1, "#fede00");
        CPreloader._oLoadingText.x = CMain.CANVAS_WIDTH/2;
        CPreloader._oLoadingText.y = CMain.CANVAS_HEIGHT/2 +120;
        CPreloader._oLoadingText.textBaseline = "alphabetic";
        CPreloader._oLoadingText.textAlign = "center";
        this._oContainer.addChild(CPreloader._oLoadingText);



        this._oFade = new createjs.Shape();
        this._oFade.graphics.beginFill("black").drawRect(0, 0, CMain.CANVAS_WIDTH, CMain.CANVAS_HEIGHT);
        this._oContainer.addChild(this._oFade);
        const _oFade = this._oFade;
        const _oContainer = this._oContainer;
        createjs.Tween.get(_oFade).to({alpha: 0}, 500).call(function () {
            createjs.Tween.removeTweens(_oFade);
            _oContainer.removeChild(_oFade);
        });


    };
    public refreshLoader = (iPerc: number) => {
        CPreloader._oLoadingText.text = iPerc + "%";

        if (iPerc === 100) {
            CMain.s_oMain._onRemovePreloader();
            CPreloader._oLoadingText.visible = false;
            CPreloader._oProgressBar.visible = false;
        };

        CPreloader._oMaskPreloader.graphics.clear();
        var iNewMaskWidth = Math.floor((iPerc * this._iMaskWidth) / 100);
        CPreloader._oMaskPreloader.graphics.beginFill("rgba(0,0,0,0.01)").drawRect(CPreloader._oProgressBar.x, CPreloader._oProgressBar.y, iNewMaskWidth, this._iMaskHeight);
    };
}