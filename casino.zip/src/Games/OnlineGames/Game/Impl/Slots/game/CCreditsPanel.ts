import {createBitmap} from "./ctl_utils";
import {CMain} from "./CMain";
import {CGfxButton} from "./CGfxButton";

export class CCreditsPanel{

    private _oListenerLogo: any;
    private _oListenerBlock: any;
    private _oFade: any;
    private _oContainerPanel: any;
    private _oButExit: any;
    private _oLogo: any;
    private _oPanel: any;
    private _oContainer: any;
    private _pStartPanelPos: any;

    constructor(){
        this._init();
    };

    private _init = () => {

        this._oContainer = new createjs.Container();
        CMain.s_oStage.addChild(this._oContainer);

        this._oFade = new createjs.Shape();
        this._oListenerBlock = this._oFade.on("click",function(){});
        this._oFade.alpha = 0;
        this._oFade.graphics.beginFill("black").drawRect(0,0,CMain.CANVAS_WIDTH,CMain.CANVAS_HEIGHT);
        this._oContainer.addChild(this._oFade);

        this._oContainerPanel = new createjs.Container();
        this._oContainer.addChild(this._oContainerPanel);

        var oSprite = CMain.s_oSpriteLibrary!!.getSprite('msg_box');
        this._oPanel = createBitmap(oSprite);
        this._oPanel.regX = oSprite.width/2;
        this._oPanel.regY = oSprite.height/2;
        this._oContainerPanel.addChild(this._oPanel);
        this._oListenerLogo = this._oPanel.on("click",this._onLogoButRelease);

        this._oContainerPanel.x = CMain.CANVAS_WIDTH/2;
        this._oContainerPanel.y = CMain.CANVAS_HEIGHT/2;
        this._pStartPanelPos = {x: this._oContainerPanel.x, y: this._oContainerPanel.y};


        var oLink = new createjs.Text("www.codethislab.com","52px "+CMain.FONT_GAME_1, "#fede00");
        oLink.y = 210;
        oLink.textAlign = "center";
        oLink.textBaseline = "alphabetic";
        oLink.lineWidth = 300;
        this._oContainerPanel.addChild(oLink);

        var oSprite = CMain.s_oSpriteLibrary!!.getSprite('ctl_logo');
        this._oLogo = createBitmap(oSprite);
        this._oLogo.y = -70;
        this._oLogo.regX = oSprite.width/2;
        this._oLogo.regY = oSprite.height/2;
        this._oContainerPanel.addChild(this._oLogo);

        var oSprite = CMain.s_oSpriteLibrary!!.getSprite('but_yes');
        this._oButExit = new CGfxButton(0, 360, oSprite, this._oContainerPanel);
        this._oButExit.addEventListener(CMain.ON_MOUSE_UP, this.hide, this);

        this._oContainerPanel.scale = 0;
        this._oFade.alpha = 0;
        createjs.Tween.get(this._oFade).to({alpha: 0.7}, 300, createjs.Ease.quartOut)
        createjs.Tween.get(this._oContainerPanel).to({scale:1}, 1000, createjs.Ease.elasticOut);
    };

    private unload = () => {
        const _oContainer = this._oContainer;
        const _oButExit = this._oButExit;
        createjs.Tween.get(this._oContainer).to({alpha:0},500).call(function(){
            CMain.s_oStage.removeChild(_oContainer);
            _oButExit.unload();
        });

        this._oFade.off("click",this._oListenerBlock);
        this._oPanel.off("click",this._oListenerLogo);
    };

    private _onLogoButRelease = () => {

        window.open("http://www.codethislab.com/index.php?&l=en");
    };

    private hide = () => {
        this._oButExit.disable();
        const _oThis = this;
        createjs.Tween.get(this._oFade).to({alpha: 0}, 500, createjs.Ease.quartOut)
        createjs.Tween.get(this._oContainerPanel).to({scale: 0}, 500, createjs.Ease.backIn).call(function(){
            _oThis.unload();
        });
    }
}


