import {createBitmap, createSprite, playSound, stopSound, formatEntries} from "./ctl_utils";
import {CGame} from "./CGame";
import {CMain} from "./CMain";
import {CSlotSettings} from "./CSlotSettings";
import {CTLText} from "./CTLText";

export class CStaticSymbolCell {

    private _iNumCycles: any;
    private _iTotAnimCycle: any;
    private _iRow: any;
    private _iCol: any;
    private _iStartX: any;
    private _iStartY: any;
    private _iCurSpriteAnimating: any = -1;
    private _iLastAnimFrame: any;
    private _aSprites: any;
    private _oWinningFrame: any;
    private _oWinningFrameBig: any;
    private _oAmountText: any;

    private _oAmountBg: any;
    private _oImageAttach: any;
    private _oContainer: any;
    
    constructor(
        iRow: any,
        iCol: any,
        iXPos: any,
        iYPos: any
    ){
        this._init(iRow,iCol,iXPos,iYPos);
    }

    private _init = (iRow: any,iCol: any,iXPos: any,iYPos: any) => {
        this._iRow = iRow;
        this._iCol = iCol;
        this._iStartX = iXPos;
        this._iStartY = iYPos;
        this._iNumCycles = 0;

        this._oContainer = new createjs.Container();
        this._oContainer.visible = false;
        CMain.s_oAttachSection.addChild(this._oContainer);

        this._oImageAttach = new createjs.Container();
        this._oImageAttach.visible = false;
        this._oImageAttach.x = iXPos;
        this._oImageAttach.y = iYPos;

        this._oContainer.addChild(this._oImageAttach);
        this._oImageAttach.scaleX = this._oImageAttach.scaleY = 0.5 * CMain.REEL_SCALE;
        var oParent= this;
        this._aSprites = new Array();
        for(var i=0;i<CMain.NUM_SYMBOLS;i++){
            var oSprite = createSprite(CSlotSettings.s_aSymbolAnims[i], "static",0,0,CMain.SYMBOL_ANIM_WIDTH,CMain.SYMBOL_ANIM_HEIGHT);
            oSprite.on("animationend", oParent._onAnimEnded, null, false);
            this._oImageAttach.addChild(oSprite);

            this._aSprites[i] = oSprite;
            this._aSprites[i].visible = false;
        }


        var oData = {   // image to use
            images: [CMain.s_oSpriteLibrary!!.getSprite('win_frame_anim_big_0'),
                CMain.s_oSpriteLibrary!!.getSprite('win_frame_anim_big_1'),
                CMain.s_oSpriteLibrary!!.getSprite('win_frame_anim_big_2'),
                CMain.s_oSpriteLibrary!!.getSprite('win_frame_anim_big_3'),
                CMain.s_oSpriteLibrary!!.getSprite('win_frame_anim_big_4'),
                CMain.s_oSpriteLibrary!!.getSprite('win_frame_anim_big_5'),
                CMain.s_oSpriteLibrary!!.getSprite('win_frame_anim_big_6'),
                CMain.s_oSpriteLibrary!!.getSprite('win_frame_anim_big_7')],
            framerate:60,
            // width, height & registration point of each sprite
            frames: {width: CMain.WIN_BIG_ANIM_WIDTH, height: CMain.WIN_BIG_ANIM_HEIGHT},
            animations: {  static: 0,anim:[1,64] }
        };

        var oSpriteSheet = new createjs.SpriteSheet(oData);

        this._oWinningFrameBig = createSprite(oSpriteSheet, "static",0,0,CMain.WIN_BIG_ANIM_WIDTH,CMain.WIN_BIG_ANIM_HEIGHT);
        this._oWinningFrameBig.x = -36;
        this._oWinningFrameBig.y = -40;
        this._oImageAttach.addChild(this._oWinningFrameBig);


        var oSpriteAmount = CMain.s_oSpriteLibrary!!.getSprite("amount_bonus_win");
        this._oAmountBg = createBitmap(oSpriteAmount);
        this._oAmountBg.regX = oSpriteAmount.width/2;
        this._oAmountBg.regY = oSpriteAmount.height/2;
        this._oAmountBg.x = CMain.SYMBOL_ANIM_WIDTH/2;
        this._oAmountBg.y = CMain.SYMBOL_ANIM_HEIGHT;
        this._oImageAttach.addChild(this._oAmountBg);


        this._oAmountText = new CTLText(this._oImageAttach,
            CMain.SYMBOL_ANIM_WIDTH/2 - 125, CMain.SYMBOL_ANIM_HEIGHT - 37, 250, 76,
            76, "center", "#fede00", CMain.FONT_GAME_1, 1.1,
            0, 0,
            " ",
            true, true, false,
            false );


        var oData = {   // image to use
            images: [CMain.s_oSpriteLibrary!!.getSprite('win_frame_anim_0'),
                CMain.s_oSpriteLibrary!!.getSprite('win_frame_anim_1')],
            framerate:40,
            // width, height & registration point of each sprite
            frames: {width: 342, height: 336},
            animations: {  static: 0,anim:[0,42] }
        };

        var oSpriteSheet = new createjs.SpriteSheet(oData);

        this._oWinningFrame = createSprite(oSpriteSheet, "static",0,0,342,336);
        this._oWinningFrame.x = iXPos-60;
        this._oWinningFrame.y = iYPos-60;
        this._oWinningFrame.scaleX = this._oWinningFrame.scaleY = CMain.REEL_SCALE;
        this._oContainer.addChild(this._oWinningFrame);
    };
    private unload = () => {
        CMain.s_oAttachSection.removeChild(this._oContainer);
    };
    private hide = () => {
        if(this._iCurSpriteAnimating > -1){
            stopSound("symbol"+this._iCurSpriteAnimating);

            this._oWinningFrame.gotoAndStop("static");
            this._oWinningFrame.visible = false;
            this._oWinningFrameBig.gotoAndStop("static");
            this._oWinningFrameBig.visible = false;
            this._oAmountBg.visible = false;
            this._oAmountText.refreshText(" ");

            this._aSprites[this._iCurSpriteAnimating].gotoAndPlay("static");
            this._aSprites[this._iCurSpriteAnimating].visible = false;
            this._oContainer.visible = false;
            this._iCurSpriteAnimating = -1;
        }
    };
    private show = (iValue: any,iAmountWin: any,oPos: any,oRegPoint: any,iAnimCycle: any) => {
        this._iNumCycles = 0;
        this._iTotAnimCycle = iAnimCycle;

        for(var i=0;i<CMain.NUM_SYMBOLS;i++){
            if( (i+1) === iValue){
                this._aSprites[i].visible = true;
            }else{
                this._aSprites[i].visible = false;
            }
        }
        this._oAmountBg.visible = false;

        if(iAmountWin > 0){
            this._oAmountText.refreshText(formatEntries(iAmountWin));

            this._oAmountBg.visible = true;
        }else{
            this._oAmountText.refreshText(" ");
        }

        this._oWinningFrameBig.gotoAndPlay("anim");
        this._oWinningFrameBig.visible = true;

        this._aSprites[iValue-1].gotoAndPlay("anim");
        this._iCurSpriteAnimating = iValue-1;

        this._iLastAnimFrame = this._aSprites[iValue-1].spriteSheet.getNumFrames();
        this._oImageAttach.regX = oRegPoint.x;
        this._oImageAttach.regY = oRegPoint.y;
        this._oImageAttach.x = this._iStartX + oPos.x;
        this._oImageAttach.y = this._iStartY + oPos.y;
        this._oImageAttach.scaleX = this._oImageAttach.scaleY = 0.5*CMain.REEL_SCALE;
        this._oImageAttach.visible = true;
        this._oImageAttach.alpha = 1;
        this._oContainer.visible= true;

        createjs.Tween.get(this._oImageAttach).to({scaleX:CMain.REEL_SCALE,scaleY:CMain.REEL_SCALE }, 1000,createjs.Ease.cubicOut);

        playSound("symbol"+this._iCurSpriteAnimating,1,false);


    };
    private showWinFrame = () => {
        this._oWinningFrame.gotoAndPlay("anim");
        this._oWinningFrame.visible = true;
        this._oContainer.visible = true;
    };
    private hideWinFrame = () => {
        createjs.Tween.removeTweens(this._oImageAttach);

        this._oWinningFrame.gotoAndPlay("static");
        this._oWinningFrame.visible = false;
        this._oContainer.visible = false;
    };
    private _onAnimEnded = () => {
        this._iNumCycles++;
        if(this._iNumCycles === this._iTotAnimCycle && this._iCurSpriteAnimating > -1){
            //END WHOLE SYMBOL ANIMATION
            this._aSprites[this._iCurSpriteAnimating].stop();
            const _oThis = this;
            createjs.Tween.get(this._oImageAttach).to({scaleX:0.52,scaleY:0.52 ,alpha:0}, 500,createjs.Ease.cubicOut).call(function(){_oThis.stopAnim();CGame.s_oGame?.showWin();});
        }
    };
    private stopAnim = () => {
        if( this._iCurSpriteAnimating === -1 ){
            return;
        }

        stopSound("symbol"+this._iCurSpriteAnimating);


        this._aSprites[this._iCurSpriteAnimating].visible = false;
        this._oImageAttach.visible = false;

        this._oWinningFrame.gotoAndStop("static");
        this._oWinningFrame.visible = false;
    };
}