import {createBitmap, playSound} from "./ctl_utils";
import {CMain} from "./CMain";

export class CGfxButton {

    private _bDisabled: any;
    private _iScaleFactor: any;
    private _aCbCompleted: any;
    private _aCbOwner: any;
    private _aParams: any;
    private _oListenerPress: any;
    private _oListenerUp: any;
    private _oListenerOver: any;

    private _oButton: any;
    private _oTween: any;
    private _oParent: any;

    private iXPos: any;
    private iYPos: any;
    private oSprite: any;
    private oParentContainer: any;

    constructor(
        iXPos: any,
        iYPos: any,
        oSprite: any,
        oParentContainer: any
    ) {
        this.iXPos = iXPos;
        this.iYPos = iYPos;
        this.oSprite = oSprite;
        this.oParentContainer = oParentContainer;
        this._init(iXPos, iYPos, oSprite, oParentContainer);
    }
    private _init = (iXPos: any, iYPos: any, oSprite: any, oParentContainer: any) => {
        this._bDisabled = false;

        this._iScaleFactor = 1;

        this._aCbCompleted = new Array();
        this._aCbOwner = new Array();

        this._oButton = createBitmap(oSprite);
        this._oButton.x = iXPos;
        this._oButton.y = iYPos;
        this._oButton.scaleX = this._oButton.scaleY = this._iScaleFactor;
        this._oButton.regX = oSprite.width / 2;
        this._oButton.regY = oSprite.height / 2;

        oParentContainer.addChild(this._oButton);

        this._initListener();
    };
    private unload = () => {
        this._oButton.off("mousedown", this._oListenerPress);
        this._oButton.off("pressup", this._oListenerUp);

        if (!CMain.s_bMobile) {
            this._oButton.off("mouseover", this._oListenerOver);
        }
        createjs.Tween.removeTweens(this._oButton);

        this.oParentContainer.removeChild(this._oButton);
    };
    private setVisible = (bVisible: any) => {
        this._oButton.visible = bVisible;
    };
    private enable = () => {
        this._bDisabled = false;
    };
    private disable = () => {
        this._bDisabled = true;
    };
    private _initListener = () => {
        this._oListenerPress = this._oButton.on("mousedown", this.buttonDown);
        this._oListenerUp = this._oButton.on("pressup", this.buttonRelease);
        if (!CMain.s_bMobile) {
            this._oListenerOver = this._oButton.on("mouseover", this.buttonOver);
        }
    };
    private addEventListener = (iEvent: any, cbCompleted: any, cbOwner: any) => {
        this._aCbCompleted[iEvent] = cbCompleted;
        this._aCbOwner[iEvent] = cbOwner;
    };
    private addEventListenerWithParams = (iEvent: any, cbCompleted: any, cbOwner: any, aParams: any) => {
        this._aCbCompleted[iEvent] = cbCompleted;
        this._aCbOwner[iEvent] = cbOwner;
        this._aParams = aParams;
    };
    private buttonRelease = () => {
        if (this._bDisabled) {
            return;
        }
        this._oButton.scaleX = this._iScaleFactor;
        this._oButton.scaleY = this._iScaleFactor;

        playSound("press_but", 1, false);

        if (this._aCbCompleted[CMain.ON_MOUSE_UP]) {
            this._aCbCompleted[CMain.ON_MOUSE_UP].call(this._aCbOwner[CMain.ON_MOUSE_UP], this._aParams);
        }
    };
    private buttonDown = () => {

        if (this._bDisabled) {
            return;
        }
        this._oButton.scaleX = this._iScaleFactor * 0.9;
        this._oButton.scaleY = this._iScaleFactor * 0.9;

        if (this._aCbCompleted[CMain.ON_MOUSE_DOWN]) {
            this._aCbCompleted[CMain.ON_MOUSE_DOWN].call(this._aCbOwner[CMain.ON_MOUSE_DOWN], this._aParams);
        }
    };
    private buttonOver = (evt: any) => {
        if (!CMain.s_bMobile) {
            if (this._bDisabled) {
                return;
            }
            evt.target.cursor = "pointer";
        }
    };
    private pulseAnimation = () => {
        this._oTween = createjs.Tween.get(this._oButton, {loop: -1}).to({
            scaleX: this._iScaleFactor * 1.1,
            scaleY: this._iScaleFactor * 1.1
        }, 850, createjs.Ease.quadOut).to({
            scaleX: this._iScaleFactor,
            scaleY: this._iScaleFactor
        }, 650, createjs.Ease.quadIn);
    };
    private moveY = (iFinalY: any, iTime: any, iDelay: any, oEasing: any) => {
        this._oTween = createjs.Tween.get(this._oButton).wait(iDelay).to({y: iFinalY}, iTime, oEasing);
    };
    private setPosition = (iXPos: any, iYPos: any) => {
        this._oButton.x = iXPos;
        this._oButton.y = iYPos;
    };
    private setX = (iXPos: any) => {
        this._oButton.x = iXPos;
    };
    private setY = (iYPos: any) => {
        this._oButton.y = iYPos;
    };
    private getButtonImage = () => {
        return this._oButton;
    };
    private getX = () => {
        return this._oButton.x;
    };
    private getY = () => {
        return this._oButton.y;
    };
}