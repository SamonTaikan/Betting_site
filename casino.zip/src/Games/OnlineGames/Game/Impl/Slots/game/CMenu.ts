import {clearLocalStorage, createBitmap, getItem, sizeHandler} from "./ctl_utils";
import {CGfxButton} from "./CGfxButton";
import {CToggle} from "./CToggle";
import {CCreditsPanel} from "./CCreditsPanel";
import {CMain} from "./CMain";
import {CAreYouSurePanel} from "./CAreYouSurePanel";
import {CGame} from "./CGame";
import {screenfull_IsEnabled} from "./CInterface";

export class CMenu{

    public static s_oMenu: CMenu | null = null
    private _pStartPosAudio: any;
    private _pStartPosFullscreen: any;
    private _pStartPosCredits: any;
    private _pStartPosDelete: any;

    private _fRequestFullScreen: any = null;
    private _fCancelFullScreen: any = null;
    private _oBg: any;
    private _oButPlay: any;
    private _oButDeleteSavings: any;
    private _oAudioToggle: any;
    private _oButCredits: any;
    private _oButFullscreen: any;
    private _oFade: any;
    private _oAreYouSurePanel: any;

    private _init: () => void;
    private unload: () => void;
    public refreshButtonPos: (x?: number, y?: number) => void;
    private _onButPlayRelease: () => void;
    private _onAudioToggle: () => void;
    private _onButCreditsRelease: () => void;
    private resetFullscreenBut: () => void;
    private _onFullscreenRelease: () => void;
    private _onDeleteSavings: () => void;
    private _onExitYes: () => void;
    
    constructor(){

        this._init = function(){
            this._oBg = createBitmap(CMain.s_oSpriteLibrary!!.getSprite('bg_game'));
            // CMain.s_oAttachSection.addChild(this._oBg);

            var oSpriteLogo = CMain.s_oSpriteLibrary!!.getSprite("logo_menu");
            var oLogo = createBitmap(oSpriteLogo);
            oLogo.regX = oSpriteLogo.width/2;
            oLogo.regY = oSpriteLogo.height/2;
            oLogo.x = CMain.CANVAS_WIDTH/2;
            oLogo.y = CMain.CANVAS_HEIGHT/2+100;
            oLogo.alpha = 0;
            // CMain.s_oAttachSection.addChild(oLogo);

            var oSprite = CMain.s_oSpriteLibrary!!.getSprite('but_play');
            this._oButPlay = new CGfxButton((CMain.CANVAS_WIDTH/2)+450,CMain.CANVAS_HEIGHT -300, oSprite ,CMain.s_oAttachSection);
            this._oButPlay.addEventListener(CMain.ON_MOUSE_UP, this._onButPlayRelease, this);

            if(CMain.DISABLE_SOUND_MOBILE === false || CMain.s_bMobile === false){
                var oSprite = CMain.s_oSpriteLibrary!!.getSprite('audio_icon');
                this._pStartPosAudio = {x: CMain.CANVAS_WIDTH - (oSprite.width/4) - 4, y: (oSprite.height/2) + 4};

                this._oAudioToggle = new CToggle(this._pStartPosAudio.x,this._pStartPosAudio.y,'',CMain.s_bAudioActive);
                this._oAudioToggle.addEventListener(CMain.ON_MOUSE_UP, this._onAudioToggle, this);
            }

            if(CMain.SHOW_CREDITS){
                var oSprite = CMain.s_oSpriteLibrary!!.getSprite('but_credits');
                this._pStartPosCredits = {x:(oSprite.width/2) + 4,y:(oSprite.height/2) + 4};
                this._oButCredits = new CGfxButton(this._pStartPosCredits.x,this._pStartPosCredits.y, '',CMain.s_oAttachSection);
                this._oButCredits.addEventListener(CMain.ON_MOUSE_UP, this._onButCreditsRelease, this);

                this._pStartPosFullscreen = {x: this._pStartPosCredits.x + oSprite.width + 4,y:this._pStartPosCredits.y};
            }else{
                this._pStartPosFullscreen = {x:(oSprite.width/2) + 4,y:(oSprite.height/2) + 4};
            }

            var doc = window.document;
            var docEl = doc.documentElement;
            this._fRequestFullScreen = docEl.requestFullscreen/* || docEl.mozRequestFullScreen || docEl.webkitRequestFullScreen || docEl.msRequestFullscreen*/;
            this._fCancelFullScreen = doc.exitFullscreen/* || doc.mozCancelFullScreen || doc.webkitExitFullscreen || doc.msExitFullscreen*/;

            if(CMain.ENABLE_FULLSCREEN === false){
                this._fRequestFullScreen = false;
            }

            if (this._fRequestFullScreen && screenfull_IsEnabled){
                oSprite = CMain.s_oSpriteLibrary!!.getSprite('but_fullscreen');

                this._oButFullscreen = new CToggle(this._pStartPosFullscreen.x,this._pStartPosFullscreen.y,'',CMain.s_bFullscreen,CMain.s_oAttachSection);
                this._oButFullscreen.addEventListener(CMain.ON_MOUSE_UP, this._onFullscreenRelease, this);
            }

            var oSprite = CMain.s_oSpriteLibrary!!.getSprite("but_delete_savings")
            this._pStartPosDelete = {x:oSprite.width/2 +4,y:CMain.CANVAS_HEIGHT-oSprite.height/2-4};
            this._oButDeleteSavings = new CGfxButton(this._pStartPosDelete.x,this._pStartPosDelete.y,'oSprite',CMain.s_oAttachSection);
            this._oButDeleteSavings.addEventListener(CMain.ON_MOUSE_UP,this._onDeleteSavings,this);


            if(!CMain.s_bStorageAvailable){
                CMain.s_oMsgBox.show(CMain.TEXT_ERR_LS);
                this._oButDeleteSavings.setVisible(false);
            }else if(!CMain.RESTART_CREDIT && getItem(CMain.LOCALSTORAGE_STRING+"score")){
                CMain.TOTAL_MONEY = parseFloat(getItem(CMain.LOCALSTORAGE_STRING+"score")!!);
            }else{
                this._oButDeleteSavings.setVisible(false);
            }

            this._oAreYouSurePanel = new CAreYouSurePanel();
            this._oAreYouSurePanel.addEventListener(CMain.ON_BUT_YES_DOWN,this._onExitYes,this);

            this._oFade = new createjs.Shape();
            this._oFade.graphics.beginFill("black").drawRect(0,0,CMain.CANVAS_WIDTH,CMain.CANVAS_HEIGHT);

            CMain.s_oAttachSection.addChild(this._oFade);
            const _oFade = this._oFade;
            createjs.Tween.get(this._oFade).to({alpha:0}, 400).call(function(){_oFade.visible = false;});

            this.refreshButtonPos ();

            createjs.Tween.get(oLogo).to({alpha:1}, 800,createjs.Ease.quintOut);
        };

        this.unload = function(){
            this._oButPlay.unload();
            this._oButPlay = null;

            this._oButDeleteSavings.unload();

            if(CMain.DISABLE_SOUND_MOBILE === false || CMain.s_bMobile === false){
                this._oAudioToggle.unload();
                this._oAudioToggle = null;
            }
            if(CMain.SHOW_CREDITS){
                this._oButCredits.unload();
            }
            if (this._fRequestFullScreen && screenfull_IsEnabled){
                this._oButFullscreen.unload();
            }
            CMain.s_oAttachSection.removeChild(this._oBg);
            this._oBg = null;

            CMain.s_oAttachSection.removeChild(this._oFade);
            this._oFade = null;

            CMenu.s_oMenu = null;
        };

        this.refreshButtonPos = function(){
            if(CMain.DISABLE_SOUND_MOBILE === false || CMain.s_bMobile === false){
                this._oAudioToggle.setPosition(this._pStartPosAudio.x - CGame.s_iOffsetX,CGame.s_iOffsetY + this._pStartPosAudio.y);
            }
            if(CMain.SHOW_CREDITS){
                this._oButCredits.setPosition(this._pStartPosCredits.x + CGame.s_iOffsetX,this._pStartPosCredits.y + CGame.s_iOffsetY);
            }
            if (this._fRequestFullScreen && screenfull_IsEnabled){
                this._oButFullscreen.setPosition(this._pStartPosFullscreen.x + CGame.s_iOffsetX,this._pStartPosFullscreen.y + CGame.s_iOffsetY);
            }

            this._oButDeleteSavings.setPosition(this._pStartPosDelete.x + CGame.s_iOffsetX,this._pStartPosDelete.y - CGame.s_iOffsetY)
        };

        this._onButPlayRelease = function(){
            this.unload();
            // $(CMain.s_oMain).trigger("start_session"); // TODO TRIGGER: start_session
            console.log("TODO trigger start_session")
            CMain.s_oMain.gotoGame();
        };

        this._onAudioToggle = function(){
            // Howler.mute(CMain.s_bAudioActive); //TODO Howler
            console.log("TODO check mute")
            CMain.s_bAudioActive = !CMain.s_bAudioActive;
        };

        this._onButCreditsRelease = function(){
            new CCreditsPanel();
        };

        this.resetFullscreenBut = function(){
            if (this._fRequestFullScreen && screenfull_IsEnabled){
                this._oButFullscreen.setActive(CMain.s_bFullscreen);
            }
        };

        this._onFullscreenRelease = function(){
            if(CMain.s_bFullscreen) {
                this._fCancelFullScreen.call(window.document);
            }else{
                this._fRequestFullScreen.call(window.document.documentElement);
            }

            sizeHandler();
        };

        this._onDeleteSavings = function(){
            this._oAreYouSurePanel.show(CMain.TEXT_DELETE_SAVINGS+": "+CMain.START_MONEY+CMain.TEXT_CURRENCY+"\n"+CMain.TEXT_ARE_SURE);
        };

        this._onExitYes = function(){
            clearLocalStorage();
            this._oButDeleteSavings.setVisible(false);
        };

        CMenu.s_oMenu = this;

        this._init();
    }
}