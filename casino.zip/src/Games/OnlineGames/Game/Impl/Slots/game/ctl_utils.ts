import {CMain} from "./CMain";
import {CGame} from "./CGame";
import {CMenu} from "./CMenu";

export const formatEntries = (iValue: number): string => {
    return iValue.toFixed(2);
}

export const isMobile = ():boolean => {
    return false;
}

export const createBitmap = (oSprite: any, iWidth?: any, iHeight?: any): any => {
    var oBmp = new createjs.Bitmap(oSprite);
    var hitObject = new createjs.Shape();

    if (iWidth && iHeight){
        hitObject .graphics.beginFill("#fff").drawRect(0, 0, iWidth, iHeight);
    }else{
        hitObject .graphics.beginFill("#ff0").drawRect(0, 0, oSprite.width, oSprite.height);
    }

    oBmp.hitArea = hitObject;

    return oBmp;
}

export const createSprite = (oSpriteSheet: any, szState: any, iRegX: any,iRegY: any,iWidth: any, iHeight: any): any => {
    if(szState !== null){
        var oRetSprite = new createjs.Sprite(oSpriteSheet, szState);
    }else{
        var oRetSprite = new createjs.Sprite(oSpriteSheet);
    }

    var hitObject = new createjs.Shape();
    hitObject .graphics.beginFill("#000000").drawRect(-iRegX, -iRegY, iWidth, iHeight);

    oRetSprite.hitArea = hitObject;

    return oRetSprite;
}

export const playSound = (szSound: any,iVolume: any,bLoop: any): any => {
    if(CMain.DISABLE_SOUND_MOBILE === false || CMain.s_bMobile === false){
        console.log(szSound)
        console.log(CMain.s_aSounds)
        if (CMain.s_aSounds[szSound]) {
            CMain.s_aSounds[szSound].play();
            CMain.s_aSounds[szSound].volume(iVolume);
            CMain.s_aSounds[szSound].loop(bLoop);
        }

        return CMain.s_aSounds[szSound];
    }
    return null;
}
export const stopSound = (szSound: any): any => {
    if(CMain.DISABLE_SOUND_MOBILE === false || CMain.s_bMobile === false){
        if (CMain.s_aSounds[szSound]) {
            CMain.s_aSounds[szSound].stop();
        }
    }
}

export const setVolume = (szSound: any,iVolume: any): any => {
    if(CMain.DISABLE_SOUND_MOBILE === false || CMain.s_bMobile === false){
        if (CMain.s_aSounds[szSound]) {
            CMain.s_aSounds[szSound].volume(iVolume);
        }
    }
}

function getSize(Name: string) {
    var size;
    const _window: any = window;
    var name = Name.toLowerCase();
    var document = _window.document;
    var documentElement = document.documentElement;
    if (_window["inner" + Name] === undefined) {
        // IE6 & IE7 don't have window.innerWidth or innerHeight
        size = documentElement["client" + Name];
    }
    else if (_window["inner" + Name] != documentElement["client" + Name]) {
        // WebKit doesn't include scrollbars while calculating viewport size so we have to get fancy

        // Insert markup to test if a media query will match document.doumentElement["client" + Name]
        var bodyElement = document.createElement("body");
        bodyElement.id = "vpw-test-b";
        bodyElement.style.cssText = "overflow:scroll";
        var divElement = document.createElement("div");
        divElement.id = "vpw-test-d";
        divElement.style.cssText = "position:absolute;top:-1000px";
        // Getting specific on the CSS selector so it won't get overridden easily
        // @ts-ignore
        divElement.innerHTML = `<style>@media(${name}:${documentElement['client'+ 'Name']}){body#vpw-test-b div#vpw-test-d{${name}:7px!important}}</style>`;
        bodyElement.appendChild(divElement);
        documentElement.insertBefore(bodyElement, document.head);

        if (divElement["offset" + Name] == 7) {
            // Media query matches document.documentElement["client" + Name]
            size = documentElement["client" + Name];
        }
        else {
            // Media query didn't match, use window["inner" + Name]
            size = _window["inner" + Name];
        }
        // Cleanup
        documentElement.removeChild(bodyElement);
    }
    else {
        // Default to use window["inner" + Name]
        size = _window["inner" + Name];
    }
    return size;
};

export const setMute = (szSound: any,bMute: any): any => {
    if(CMain.DISABLE_SOUND_MOBILE === false || CMain.s_bMobile === false){
        CMain.s_aSounds[szSound].mute(bMute);
    }
}
//THIS FUNCTION MANAGES THE CANVAS SCALING TO FIT PROPORTIONALLY THE GAME TO THE CURRENT DEVICE RESOLUTION
export const platformName = "safari";
export const sizeHandler = () => {
    window.scrollTo(0, 1);

    console.log('handler called!!')

    // if (!$("#canvas")){
    //     return;
    // }

    if (true) {
        //TODO Canvas reference required...
        console.log('TODO: CANVAS REFERENCE REQUIRED -- sizeHandler METHOD')
        return;
    }

    var h;
    if(platformName !== null && platformName.toLowerCase() === "safari"){
        h = getIOSWindowHeight();
    }else{
        h = getSize("Height");
    }

    var w = getSize("Width");

    if(CGame.s_bFocus){
        _checkOrientation(w,h);
    }

    var multiplier = Math.min((h / CMain.CANVAS_HEIGHT), (w / CMain.CANVAS_WIDTH));

    var destW = Math.round(CMain.CANVAS_WIDTH * multiplier);
    var destH = Math.round(CMain.CANVAS_HEIGHT * multiplier);

    var iAdd = 0;
    if (destH < h){
        iAdd = h-destH;
        destH += iAdd;
        destW += iAdd*(CMain.CANVAS_WIDTH/CMain.CANVAS_HEIGHT);
    }else  if (destW < w){
        iAdd = w-destW;
        destW += iAdd;
        destH += iAdd*(CMain.CANVAS_HEIGHT/CMain.CANVAS_WIDTH);
    }

    var fOffsetY = ((h / 2) - (destH / 2));
    var fOffsetX = ((w / 2) - (destW / 2));
    var fGameInverseScaling = (CMain.CANVAS_WIDTH/destW);

    if( fOffsetX*fGameInverseScaling < -CMain.EDGEBOARD_X ||
        fOffsetY*fGameInverseScaling < -CMain.EDGEBOARD_Y ){
        multiplier = Math.min( h / (CMain.CANVAS_HEIGHT-(CMain.EDGEBOARD_Y*2)), w / (CMain.CANVAS_WIDTH-(CMain.EDGEBOARD_X*2)));
        destW = Math.round(CMain.CANVAS_WIDTH * multiplier);
        destH = Math.round(CMain.CANVAS_HEIGHT * multiplier);
        fOffsetY = ( h - destH ) / 2;
        fOffsetX = ( w - destW ) / 2;

        fGameInverseScaling = (CMain.CANVAS_WIDTH/destW);
    }

    CGame.s_iOffsetX = (-1*fOffsetX * fGameInverseScaling);
    CGame.s_iOffsetY = (-1*fOffsetY * fGameInverseScaling);

    if(fOffsetY >= 0 ){
        CGame.s_iOffsetY = 0;
    }

    if(fOffsetX >= 0 ){
        CGame.s_iOffsetX = 0;
    }

    if(CGame.s_oGame !== null){
        CGame.s_oGame?.refreshButtonPos( CGame.s_iOffsetX,CGame.s_iOffsetY);
    }
    if(CMenu.s_oMenu !== null){
        CMenu.s_oMenu?.refreshButtonPos( CGame.s_iOffsetX,CGame.s_iOffsetY);
    }


    if(CGame.s_bIsIphone && CMain.s_oStage){
        // canvas = document.getElementById('canvas');
        CMain.s_oStage.canvas.width = destW*2;
        CMain.s_oStage.canvas.height = destH*2;
        // canvas.style.width = destW+"px";
        // canvas.style.height = destH+"px";
        //TODO Replace jquery get by selector with react.ref
        console.log("TODO: CANVAS PASS REFERENCE 0")
        var iScale = Math.min(destW / CMain.CANVAS_WIDTH, destH / CMain.CANVAS_HEIGHT);
        CGame.s_iScaleFactor = iScale*2;
        CMain.s_oStage.scaleX = CMain.s_oStage.scaleY = iScale*2;
    }else if(CMain.s_bMobile || isChrome()){
        // $("#canvas").css("width",destW+"px");
        // $("#canvas").css("height",destH+"px");
        //TODO Replace jquery get by selector with react.ref
        console.log("TODO: CANVAS PASS REFERENCE")
    }else if(CMain.s_oStage){
        CMain.s_oStage.canvas.width = destW;
        CMain.s_oStage.canvas.height = destH;

        CGame.s_iScaleFactor = Math.min(destW / CMain.CANVAS_WIDTH, destH / CMain.CANVAS_HEIGHT);
        CMain.s_oStage.scaleX = CMain.s_oStage.scaleY = CGame.s_iScaleFactor;

    }

    if(fOffsetY < 0){
        '$("#canvas").css("top",fOffsetY+"px");'
        //TODO Replace jquery get by selector with react.ref
        console.log("TODO: CANVAS PASS REFERENCE 2")
    }else{
        // centered game
        fOffsetY = (h - destH)/2;
        // $("#canvas").css("top",fOffsetY+"px");
        //TODO Replace jquery get by selector with react.ref
        console.log("TODO: CANVAS PASS REFERENCE 3")
    }

    // $("#canvas").css("left",fOffsetX+"px");
    //TODO Replace jquery get by selector with react.ref
    console.log("TODO: CANVAS PASS REFERENCE 4")
    fullscreenHandler();
};

function getIOSWindowHeight() {
    // Get zoom level of mobile Safari
    // Note, that such zoom detection might not work correctly in other browsers
    // We use width, instead of height, because there are no vertical toolbars :)
    var zoomLevel = document.documentElement.clientWidth / window.innerWidth;

    // window.innerHeight returns height of the visible area. 
    // We multiply it by zoom and get out real height.
    return window.innerHeight * zoomLevel;
};

function isChrome(){
    var isChrome = /Chrome/.test(navigator.userAgent) && /Google Inc/.test(navigator.vendor);
    return isChrome;
}

function _checkOrientation(iWidth: number,iHeight: number){
    if(CMain.s_bMobile && CMain.ENABLE_CHECK_ORIENTATION){
        //TODO Mobile Oientation update
        console.log("TODO: Mobile orientation check")
        if( iWidth>iHeight ){
            // if( $(".orientation-msg-container").attr("data-orientation") === "landscape" ){
            //     $(".orientation-msg-container").css("display","none");
            //     CMain.s_oMain.startUpdate();
            // }else{
            //     $(".orientation-msg-container").css("display","block");
            //     CMain.s_oMain.stopUpdate();
            // }
        }else{
            // if( $(".orientation-msg-container").attr("data-orientation") === "portrait" ){
            //     $(".orientation-msg-container").css("display","none");
            //     CMain.s_oMain.startUpdate();
            // }else{
            //     $(".orientation-msg-container").css("display","block");
            //     CMain.s_oMain.stopUpdate();
            // }
        }
    }
}

function fullscreenHandler(){
    if (!CMain.ENABLE_FULLSCREEN || !false){
        return;
    }

    // s_bFullscreen = screenfull.isFullscreen;
    //
    // if (s_oInterface !== null){
    //     s_oInterface.resetFullscreenBut();
    // }
    //
    // if (s_oMenu !== null){
    //     s_oMenu.resetFullscreenBut();
    // }
}


export const saveItem = (szItem: string, oValue: any) => {
    if(CMain.s_bStorageAvailable){
        localStorage.setItem(szItem, oValue);
    }
}

export const getItem = (szItem: string): string | null => {
    if(CMain.s_bStorageAvailable){
        return localStorage.getItem(szItem);
    }
    return null;
}


export const clearLocalStorage = () => {
    CMain.TOTAL_MONEY = CMain.START_MONEY;

    if(CMain.s_bStorageAvailable){
        var iCont = 0;
        while(localStorage.key(iCont) !== null){
            var szKey = localStorage.key(iCont);
            if(szKey && szKey.indexOf(CMain.LOCALSTORAGE_STRING) !== -1){
                localStorage.removeItem(szKey);
            }else{
                iCont++;
            }
        }
    }
}
