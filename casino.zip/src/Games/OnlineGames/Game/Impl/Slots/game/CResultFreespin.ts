import {CMain} from "./CMain";
import {CTLText} from "./CTLText";
import {CGfxButton} from "./CGfxButton";
import {createBitmap, playSound, formatEntries} from "./ctl_utils";

export class  CResultFreespin {
    private _oFade: any;
    private _oTextCongrats: any;
    private _oTextWin: any;
    private _oContainerPanel: any;
    private _oListener: any;
    private _oButEx: any;
    private _oContainer: any;
    private _oParentContainer;

    private _init = () => {
        this._oContainer = new createjs.Container();
        this._oContainer.visible = false;
        this._oParentContainer.addChild(this._oContainer);

        this._oFade = new createjs.Shape();
        this._oFade.graphics.beginFill("black").drawRect(0, 0, CMain.CANVAS_WIDTH,CMain.CANVAS_HEIGHT);
        this._oListener = this._oFade.on("click",function(){});
        this._oContainer.addChild(this._oFade);

        var oSpriteBg = CMain.s_oSpriteLibrary!!.getSprite("msg_box_small");

        this._oContainerPanel = new createjs.Container();
        this._oContainerPanel.x = CMain.CANVAS_WIDTH/2;
        this._oContainerPanel.y = CMain.CANVAS_HEIGHT/2;
        this._oContainerPanel.regX = oSpriteBg.width/2;
        this._oContainerPanel.regY = oSpriteBg.height/2;
        this._oContainer.addChild(this._oContainerPanel);

        var oBg = createBitmap(oSpriteBg);
        this._oContainerPanel.addChild(oBg);

        this._oTextCongrats = new CTLText(this._oContainerPanel,
            50, 70, oSpriteBg.width-100, 74,
            74, "center", "#fede00", CMain.FONT_GAME_1, 1,
            0, 0,
            CMain.TEXT_CONGRATS,
            true, true, true,
            false );


        this._oTextWin = new CTLText(this._oContainerPanel,
            50, 160, oSpriteBg.width-100, 210,
            70, "center", "#fede00", CMain.FONT_GAME_1, 1,
            0, 0,
            CMain.TEXT_CONGRATS,
            true, true, true,
            false );


        this._oButEx = new CGfxButton( oSpriteBg.width/2,oSpriteBg.height+80,CMain.s_oSpriteLibrary!!.getSprite('but_yes'),this._oContainerPanel);
        this._oButEx.addEventListener(CMain.ON_MOUSE_UP, this.hide, this);

    };
    private unload = () => {
        this._oButEx.unload();
        this._oFade.off("click",this._oListener);
    };
    private show = (iAmount: number) => {
        this._oButEx.enable();
        if(iAmount === 0){
            this._oTextCongrats.refreshText("");
            this._oTextWin.y = 0;
            this._oTextWin.refreshText(CMain.TEXT_NO_WIN);
        }else{
            this._oTextCongrats.refreshText(CMain.TEXT_CONGRATS);
            this._oTextWin.y = 30;
            this._oTextWin.refreshText(CMain.TEXT_YOU_WON + " " + formatEntries(iAmount));
        }

        this._oContainer.alpha = 1;
        this._oContainer.visible = true;
        this._oContainerPanel.scale = 0;
        this._oFade.alpha = 0;

        var oParent = this;
        createjs.Tween.get(this._oFade).to({alpha: 0.7}, 300, createjs.Ease.quartOut)
        createjs.Tween.get(this._oContainerPanel).to({scale:1}, 1000, createjs.Ease.elasticOut).call(function(){
            setTimeout(function(){oParent.hide();},3000);
        });


        playSound("bonus_end",1,false);
    };
    private hide = () => {
        this._oButEx.disable();
        createjs.Tween.get(this._oFade).to({alpha: 0}, 500, createjs.Ease.quartOut)
        const _oContainer = this._oContainer;
        createjs.Tween.get(this._oContainerPanel).to({scale: 0}, 500, createjs.Ease.backIn).call(function(){
            _oContainer.visible = false;
        });
    };
    
    constructor(oParentContainer: any){
        this._oParentContainer = oParentContainer;
        this._init();
    }
}