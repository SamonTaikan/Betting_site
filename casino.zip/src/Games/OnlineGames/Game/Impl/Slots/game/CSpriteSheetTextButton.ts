import {CTLText} from "./CTLText";
import {createSprite, playSound} from "./ctl_utils";
import {CMain} from "./CMain";

export class CSpriteSheetTextButton {
    
    private _bDisable: any;
    private _iWidth: any;
    private _iHeight: any;
    private _szColor: any;
    private _aCbCompletedColor: any;
    private _aCbOwner: any;
    private _oListenerPress: any;
    private _oListenerUp: any;

    private _oButton: any;
    private _oButtonBg: any;
    private _oText: any;
    private _oContainer: any;

    private iXPos: any;
    private iYPos: any;
    private oSprite: any;
    private szText: any;
    private szFont: any;
    private szColor: any;
    private iFontSize: any;
    private oContainer: any;

    constructor(
        iXPos: any,
        iYPos: any,
        oSprite: any,
        szText: any,
        szFont: any,
        szColor: any,
        iFontSize: any,
        oContainer: any
    ) {
        this.iXPos = iXPos;
        this.iYPos = iYPos;
        this.oSprite = oSprite;
        this.szText = szText;
        this.szFont = szFont;
        this.szColor = szColor;
        this.iFontSize = iFontSize;
        this.oContainer = oContainer;
        this._init(iXPos,iYPos,oSprite,szText,szFont,szColor,iFontSize,oContainer);
    }

    private _init = (iXPos: any, iYPos: any,oSprite: any,szText: any,szFont: any,szColor: any,iFontSize: any,oContainer: any) => {
        this._bDisable = false;
        this._szColor = szColor;
        this._aCbCompletedColor=new Array();
        this._aCbOwner =new Array();
        this._oContainer = this.oContainer;

        this._iWidth = oSprite.width/2;
        this._iHeight = oSprite.height;

        this._oButton = new createjs.Container();
        this._oButton.x = iXPos;
        this._oButton.y = iYPos;
        this._oButton.regX = this._iWidth/2;
        this._oButton.regY = this._iHeight/2;
        this._oButton.cursor = "pointer";

        this._oContainer.addChild(this._oButton);

        var oData = {
            images: [oSprite],
            // width, height & registration point of each sprite
            frames: {width: this._iWidth, height: this._iHeight},
            animations: {state_enable: 0, state_disable: 1}
        };


        var oSpriteSheet = new createjs.SpriteSheet(oData);
        this._oButtonBg = createSprite( oSpriteSheet,"state_enable",0,0,this._iWidth,this._iHeight);
        this._oButton.addChild(this._oButtonBg);


        this._oText = new CTLText(this._oButton,
            10, 10, this._iWidth-20, this._iHeight-26,
            iFontSize, "center", szColor, szFont, 1.1,
            0, 0,
            szText,
            true, true, false,
            false );

        console.log("button set for " + szText)

        this._initListener();
    };

    private _initListener = () => {
        this._oListenerPress = this._oButton.on("mousedown", this.buttonDown);
        this._oListenerUp = this._oButton.on("pressup" , this.buttonRelease);
    };

    private unload = () => {
        this._oButton.off("mousedown",this._oListenerPress);
        this._oButton.off("pressup",this._oListenerUp);

        this._oContainer.removeChild(this._oButton);
    };

    private setVisible = (bVisible: any) => {
        this._oButton.visible = bVisible;
    };

    private enable = () => {
        this._bDisable = false;

        this._oButtonBg.gotoAndStop("state_enable");
        this._oText.setColor(this._szColor);
    };

    private disable = () => {
        this._bDisable = true;

        this._oButtonBg.gotoAndStop("state_disable");
        this._oText.setColor("#636363");
    };

    private setText = (szText: any) => {
        this._oText.refreshText(szText);
    };

    private addEventListener = (iEvent: any,cbCompleted: any, cbOwner: any) => {
        this._aCbCompletedColor[iEvent]=cbCompleted;
        this._aCbOwner[iEvent] = cbOwner;
    };

    private buttonRelease = () => {
        if(this._bDisable){
            return;
        }

        playSound("press_but", 1, false);

        this._oButton.scaleX = 1;
        this._oButton.scaleY = 1;

        if(this._aCbCompletedColor[CMain.ON_MOUSE_UP]){
            this._aCbCompletedColor[CMain.ON_MOUSE_UP].call(this._aCbOwner[CMain.ON_MOUSE_UP]);
        }
    };

    private buttonDown = () => {
        if(this._bDisable){
            return;
        }

        this._oButton.scaleX = 0.9;
        this._oButton.scaleY = 0.9;

        if(this._aCbCompletedColor[CMain.ON_MOUSE_DOWN]){
            this._aCbCompletedColor[CMain.ON_MOUSE_DOWN].call(this._aCbOwner[CMain.ON_MOUSE_DOWN]);
        }
    };

    private setPosition = (iXPos: any,iYPos: any) => {
        this._oButton.x = iXPos;
        this._oButton.y = iYPos;
    };

    private changeText = (szText: any) => {
        this._oText.refreshText(szText);
    };

    private setX = (iXPos: any) => {
        this._oButton.x = iXPos;
    };

    private setY = (iYPos: any) => {
        this._oButton.y = iYPos;
    };

    private getButtonImage = () => {
        return this._oButton;
    };

    private getX = () => {
        return this._oButton.x;
    };

    private getY = () => {
        return this._oButton.y;
    };

    private getText = () => {
        return this._oText.getString();
    };

}