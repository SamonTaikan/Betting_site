import {CMain} from "./CMain";
import {createBitmap} from "./ctl_utils";
import {CTLText} from "./CTLText";
import {CGfxButton} from "./CGfxButton";

export class CMsgBox {
    private _oListenerBlock: any;
    private _oBlock: any;
    private _oBg: any;
    private _oMsgText: any;
    private _oButExit: any;
    private _oContainerPanel: any;
    private _oGroup: any;

    constructor() {
        this._init();
    }

    private _init = () => {
        this._oGroup = new createjs.Container();
        this._oGroup.visible = false;
        CMain.s_oStage.addChild(this._oGroup);

        this._oBlock = new createjs.Shape();
        this._oBlock.graphics.beginFill("rgba(0,0,0,0.7)").drawRect(0, 0, CMain.CANVAS_WIDTH, CMain.CANVAS_HEIGHT);
        this._oListenerBlock = this._oBlock.on("click", function () {
        });
        this._oGroup.addChild(this._oBlock);
        if (!CMain.s_oSpriteLibrary) {
            return;
        }
        var oSpriteBg = CMain.s_oSpriteLibrary.getSprite('msg_box');

        this._oContainerPanel = new createjs.Container();
        this._oContainerPanel.x = CMain.CANVAS_WIDTH / 2;
        this._oContainerPanel.y = CMain.CANVAS_HEIGHT / 2;
        this._oContainerPanel.regX = oSpriteBg.width / 2;
        this._oContainerPanel.regY = oSpriteBg.height / 2;
        this._oContainerPanel.scale = 0;
        this._oGroup.addChild(this._oContainerPanel);

        this._oBg = createBitmap(oSpriteBg);
        this._oContainerPanel.addChild(this._oBg);


        this._oMsgText = new CTLText(this._oContainerPanel,
            70, 60, oSpriteBg.width - 140, 400,
            42, "center", "#fede00", CMain.FONT_GAME_1, 1,
            0, 0,
            " ",
            true, true, true,
            false);


        this._oButExit = new CGfxButton(oSpriteBg.width / 2, oSpriteBg.height - 150, CMain.s_oSpriteLibrary.getSprite('but_yes'), this._oContainerPanel);
        this._oButExit.addEventListener(CMain.ON_MOUSE_UP, this._onExit, this);
    };
    private unload = () => {
        this._oBlock.off("click", this._oListenerBlock);
        this._oButExit.unload();
    };
    private show = (szMsg: any) => {
        this._oMsgText.refreshText(szMsg);
        this._oGroup.visible = true;
        this._oBlock.alpha = 0;

        var oParent = this;
        createjs.Tween.get(this._oBlock).to({alpha: 0.7}, 300, createjs.Ease.quartOut)
        createjs.Tween.get(this._oContainerPanel).to({scale: 1}, 1000, createjs.Ease.elasticOut);
    };
    private hide = () => {
        this._oButExit.disable();

        createjs.Tween.get(this._oBlock).to({alpha: 0}, 500, createjs.Ease.quartOut)
        const _oGroup = this._oGroup;
        createjs.Tween.get(this._oContainerPanel).to({scale: 0}, 500, createjs.Ease.backIn).call(function () {
            _oGroup.visible = false;
        });
    };
    private _onExit = () => {
        this.hide();
    };

}