import {isMobile, playSound, saveItem} from "./ctl_utils";
import {CSpriteLibrary} from "./CSpriteLibrary";
import {CPreloader} from "./CPreloader";
import {CSlotSettings} from "./CSlotSettings";
import {CMsgBox} from "./CMsgBox";
import {CGame} from "./CGame";
import {RefObject} from "react";
import {CMenu} from "./CMenu";
import {wait} from "@testing-library/user-event/dist/utils";

declare global {
    var createjs: any;
}

export type SlotsGameData = {
    start_credit: number,
    min_reel_loop: number,
    reel_delay: number,
    time_show_win: number,
    time_show_all_wins: number,
    restart_credit: boolean,
    check_orientation: boolean,
    audio_enable_on_startup: boolean,
    show_credits: boolean,
    num_spin_for_ads: number,
    fullscreen?: boolean,
    canvasRef: RefObject<HTMLCanvasElement>
}

export class CMain {

    public static ENABLE_CHECK_ORIENTATION: boolean = false;
    public static NUM_SPIN_FOR_ADS: number = 0;

    public static FPS = 60;
    public static FPS_TIME      = 1000 / CMain.FPS;
    public static DISABLE_SOUND_MOBILE  = false;
    public static DISABLE_SOUND_DESKTOP = false;
    public static LOCALSTORAGE_STRING = "slot_zeus_treasure_";
    public static FONT_GAME_1 = "robotoblack";
    public static STATE_LOADING = 0;
    public static STATE_MENU    = 1;
    public static STATE_GAME    = 2;
    public static RESTART_CREDIT = false;

    public static TOTAL_MONEY = 0;
    public static START_MONEY = 0;
    public static WIN_OCCURRENCE = 35;         //WIN PERCENTAGE. SET A VALUE FROM 0 TO 100.
    public static FREESPIN_OCCURRENCE = 10;    //FREESPIN OCCURRENCE IF THERE IS A WINNING COMBO
    public static BONUS_OCCURRENCE = 10;       //BONUS OCCURRENCE IF THERE IS A WINNING COMBO
    public static SLOT_CASH = 100;             //THIS IS THE CURRENT SLOT CASH AMOUNT. THE GAME CHECKS IF THERE IS AVAILABLE CASH FOR WINNINGS.

    public static NUM_FREESPIN = [3,4,5];     //THIS IS THE NUMBER OF FREESPINS IF IN THE FINAL WHEEL THERE ARE 3,4 OR 5 FREESPIN SYMBOLS
    public static BONUS_PRIZE = [10,30,60,90,100]; //THIS IS THE LIST OF BONUS MULTIPLIERS.
    public static BONUS_PRIZE_OCCURRENCE = [40,25,20,10,5];
    public static MAX_PRIZES_BONUS = 5;     //MAX NUMBR OF PRIZES ASSIGNED IN BONUS GAME

    public static CANVAS_WIDTH = 1920;
    public static CANVAS_HEIGHT = 1080;
    public static TEXT_MONEY     = "CREDIT";
    public static TEXT_BET       = "BET";
    public static TEXT_COIN      = "BET";
    public static TEXT_LINES     = "LINES";
    public static TEXT_PAYTABLE  = "INFO";
    public static TEXT_AUTO_SPIN = "AUTO PLAY";
    public static TEXT_SPIN      = "SPIN";
    public static TEXT_STOP      = "STOP";
    public static TEXT_STOP_AUTO = "STOP AUTO";
    public static TEXT_WIN       = "WIN";
    public static TEXT_HELP_BONUS1 = "ON REELS 1 AND 5 ON THE PAYLINE STARTS THE BONUS ROUND";
    public static TEXT_HELP_BONUS2 = "CHOOSE THE RIGHT PLATFORM TO CONTINUE YOUR JOURNEY TOWARDS THE POT OF GOLD!!";
    public static TEXT_HELP_FREESPIN = "GET 3 OR MORE SCATTERS ON ANY REEL ON A PAYLINE TO TRIGGER FREESPINS";
    public static TEXT_CURRENCY  = "";
    public static TEXT_CONGRATS  = "CONGRATULATIONS!!";
    public static TEXT_YOU_WIN = "YOU GOT";
    public static TEXT_FREESPINS = "FREESPINS";
    public static TEXT_YOU_WON = "YOU WON";
    public static TEXT_NO_WIN = "NO WIN";
    public static TEXT_ARE_SURE = "ARE YOU SURE?";
    public static TEXT_SKIP =  "SKIP";
    public static TEXT_DELETE_SAVINGS = "YOUR CREDIT WILL BE RESTORED TO DEFAULT VALUE";
    public static TEXT_RECHARGE = "DO YOU WANT TO RECHARGE YOUR CREDIT?";
    public static TEXT_BONUS_HELP = "Only one platform will lead you to the gold pot. Make the right choice!";
    public static TEXT_ERR_LS = "YOUR WEB BROWSER DOES NOT SUPPORT STORING SETTING LOCALLY. IN SAFARI, THE MOST COMMON CAUSE OF THIS IS USING 'PRIVATE BROWSING MODE'. SOME INFO MAY NOT SAVE OR SOME FEATURE MAY NOT WORK PROPERLY.";

    public static EDGEBOARD_X = 256;
    public static EDGEBOARD_Y = 84;

    public static GAME_STATE_IDLE         = 0;
    public static GAME_STATE_SPINNING     = 1;
    public static GAME_STATE_SHOW_ALL_WIN = 2;
    public static GAME_STATE_SHOW_WIN     = 3;
    public static GAME_STATE_BONUS        = 4;

    public static REEL_STATE_START   = 0;
    public static REEL_STATE_MOVING = 1;
    public static REEL_STATE_STOP    = 2;

    private static SPIN_BUT_STATE_SPIN = "spin";
    private static SPIN_BUT_STATE_STOP = "stop";
    private static SPIN_BUT_STATE_AUTOSPIN = "autospin";
    private static SPIN_BUT_STATE_DISABLE = "disable";
    private static SPIN_BUT_STATE_FREESPIN = "freespin";
    private static SPIN_BUT_STATE_SKIP = "skip";

    public static ON_MOUSE_DOWN = 0;
    public static ON_MOUSE_UP   = 1;
    public static ON_MOUSE_OVER = 2;
    public static ON_MOUSE_OUT  = 3;
    public static ON_DRAG_START = 4;
    public static ON_DRAG_END   = 5;
    public static ON_BUT_YES_DOWN = 6;
    public static ON_CHARACTER_END_JUMP = 7;

    private static BONUS_BUTTON_1 = "up_left";
    private static BONUS_BUTTON_2 = "center_left";
    private static BONUS_BUTTON_3 = "down_left";
    private static BONUS_BUTTON_4 = "up_right";
    private static BONUS_BUTTON_5 = "center_right";
    private static BONUS_BUTTON_6 = "down_right";

    public static REEL_OFFSET_X = 320;
    public static REEL_OFFSET_Y = 150;
    public static START_REEL_OFFSET_X = 0;
    public static START_REEL_OFFSET_Y = 0;

    public static NUM_REELS = 5;
    public static NUM_ROWS = 3;
    public static NUM_SYMBOLS = 10;
    public static WILD_SYMBOL = 7;
    public static BONUS_SYMBOL = 9;
    public static FREESPIN_SYMBOL = 8;

    public static NUM_PAYLINES = 20;
    public static SYMBOL_WIDTH = 240;
    public static SYMBOL_HEIGHT = 230;
    public static SYMBOL_ANIM_WIDTH = 480;
    public static SYMBOL_ANIM_HEIGHT = 460;
    public static WIN_BIG_ANIM_WIDTH = 564;
    public static WIN_BIG_ANIM_HEIGHT = 542;
    public static SPACE_BETWEEN_SYMBOLS = 14.5;
    public static SPACE_HEIGHT_BETWEEN_SYMBOLS = 0;
    public static OFFSET_Y_SYMBOLS = 24;
    public static MAX_FRAMES_REEL_EASE = 24;
    public static MIN_REEL_LOOPS = 0;
    public static SUSPANCE_REEL_LOOPS = 5;
    public static REEL_DELAY = 0;
    public static REEL_START_Y = 80 -((CMain.SYMBOL_HEIGHT +CMain.SPACE_HEIGHT_BETWEEN_SYMBOLS )* 3);
    public static REEL_ARRIVAL_Y =  80 + ((CMain.SYMBOL_HEIGHT+ CMain.SPACE_HEIGHT_BETWEEN_SYMBOLS) * 3);
    public static TIME_SHOW_WIN = 0;
    public static TIME_SHOW_ALL_WINS = 2000;
    public static TIME_SPIN_BUT_CHANGE = 1000;
    public static TIME_HOLD_AUTOSPIN = 1000;
    public static MIN_TIME_EFFECT_FREESPIN = 600;
    public static MAX_TIME_EFFECT_FREESPIN = 3000;

    public static MAX_BET = 0;
    public static MIN_BET = 0;
    public static START_BET = 0;
    public static COIN_BET = [];
    public static ENABLE_FULLSCREEN = false;
    public static SHOW_CREDITS = false;
    public static PAYTABLE_VALUES?: any;

    public static BONUS_FREESPIN = 1;
    public static BONUS_GAME = 2;

    public static REEL_SCALE = 0.85;

    public static STATE_BONUS_IDLE = 0;
    public static STATE_BONUS_KICK = 1;
    public static STATE_BONUS_WIN = 2;
    public static STATE_BONUS_LOSE = 3;


    public static s_bMobile: any;
    public static s_bFullscreen = false;
    public static s_iCntTime = 0;
    public static s_iTimeElaps = 0;
    public static s_iPrevTime = 0;
    public static s_iCntFps = 0;
    public static s_iCurFps = 0;

    public static s_oDrawLayer: any;
    public static s_oStage: any;
    public static s_oAttachSection: any;
    public static s_oMain: CMain;
    public static s_oSpriteLibrary?: CSpriteLibrary;
    public static s_oMsgBox: any;
    public static s_oGameSettings: any;
    public static s_aSounds: any;
    public static s_aSoundsInfo: any;
    public static s_bStorageAvailable = true;

    public static s_bAudioActive: boolean;

    private _oMenu?: CMenu;

    private _bUpdate: any;
    private _iCurResource = 0;
    private RESOURCE_TO_LOAD = 0;
    private _iState = CMain.STATE_LOADING;
    private _oData: SlotsGameData;
    private _oPreloader: CPreloader;
    private _oGame?: CGame;

    constructor(oData: SlotsGameData) {
        CMain.s_oMain = this;
        this._oData = oData;

        var canvas = this._oData.canvasRef.current;
        CMain.s_oStage = new createjs.Stage(canvas);
        CMain.s_oAttachSection = new createjs.Container();
        CMain.s_oStage.addChild(CMain.s_oAttachSection);
        CMain.s_oStage.preventSelection = false;
        createjs.Touch.enable(CMain.s_oStage,true);

        CMain.s_bMobile = isMobile();

        if(CMain.s_bMobile === false){
            CMain.s_oStage.enableMouseOver(20);
        }

        CMain.s_iPrevTime = new Date().getTime();

        createjs.Ticker.framerate = CMain.FPS;
        createjs.Ticker.addEventListener("tick", this._update);

        // if(navigator.userAgent.match(/Windows Phone/i)){
        //     DISABLE_SOUND_MOBILE = true;
        // }

        CMain.s_oSpriteLibrary  = new CSpriteLibrary();

        //ADD PRELOADER
        this._oPreloader = new CPreloader();
        CMain.ENABLE_CHECK_ORIENTATION = this._oData.check_orientation;
        CMain.NUM_SPIN_FOR_ADS = oData.num_spin_for_ads;
        CMain.RESTART_CREDIT = oData.restart_credit;
        CMain.s_bAudioActive = oData.audio_enable_on_startup;
        CMain.TOTAL_MONEY = CMain.START_MONEY = oData.start_credit;
    }

    public preloaderReady = () => {
        this._loadImages();
        if( (CMain.DISABLE_SOUND_DESKTOP === false && CMain.s_bMobile === false) ||
            CMain.s_bMobile === true &&  CMain.DISABLE_SOUND_MOBILE === false  ){
            this._initSounds();
        }
        this._bUpdate = true;
    };
    private soundLoaded = () => {
        this._iCurResource++;

        var iPerc = Math.floor(this._iCurResource/this.RESOURCE_TO_LOAD *100);

        this._oPreloader.refreshLoader(iPerc);
    };

    private _initSounds = () => {
        // Howler.mute(!s_bAudioActive); // TODO - Replace Howler library
        CMain.s_aSoundsInfo = new Array();
        CMain.s_aSoundsInfo.push({path: 'http://localhost:3000/assets/games/online/slots/sounds/',filename:'ambience_game',loop:true,volume:1, ingamename: 'ambience_game'});
        CMain.s_aSoundsInfo.push({path: 'http://localhost:3000/assets/games/online/slots/sounds/',filename:'press_but',loop:false,volume:1, ingamename: 'press_but'});
        CMain.s_aSoundsInfo.push({path: 'http://localhost:3000/assets/games/online/slots/sounds/',filename:'click',loop:false,volume:1, ingamename: 'click'});
        CMain.s_aSoundsInfo.push({path: 'http://localhost:3000/assets/games/online/slots/sounds/',filename:'reel_stop',loop:false,volume:1, ingamename: 'reel_stop'});
        CMain.s_aSoundsInfo.push({path: 'http://localhost:3000/assets/games/online/slots/sounds/',filename:'reel_stop_bonus',loop:false,volume:1, ingamename: 'reel_stop_bonus'});
        CMain.s_aSoundsInfo.push({path: 'http://localhost:3000/assets/games/online/slots/sounds/',filename:'reel_stop_freespin',loop:false,volume:1, ingamename: 'reel_stop_freespin'});
        CMain.s_aSoundsInfo.push({path: 'http://localhost:3000/assets/games/online/slots/sounds/',filename:'start_reel',loop:false,volume:1, ingamename: 'start_reel'});
        CMain.s_aSoundsInfo.push({path: 'http://localhost:3000/assets/games/online/slots/sounds/',filename:'spin_but',loop:false,volume:1, ingamename: 'spin_but'});
        CMain.s_aSoundsInfo.push({path: 'http://localhost:3000/assets/games/online/slots/sounds/',filename:'symbol0',loop:false,volume:1, ingamename: 'symbol0'});
        CMain.s_aSoundsInfo.push({path: 'http://localhost:3000/assets/games/online/slots/sounds/',filename:'symbol1',loop:false,volume:1, ingamename: 'symbol1'});
        CMain.s_aSoundsInfo.push({path: 'http://localhost:3000/assets/games/online/slots/sounds/',filename:'symbol2',loop:false,volume:1, ingamename: 'symbol2'});
        CMain.s_aSoundsInfo.push({path: 'http://localhost:3000/assets/games/online/slots/sounds/',filename:'symbol3',loop:false,volume:1, ingamename: 'symbol3'});
        CMain.s_aSoundsInfo.push({path: 'http://localhost:3000/assets/games/online/slots/sounds/',filename:'symbol4',loop:false,volume:1, ingamename: 'symbol4'});
        CMain.s_aSoundsInfo.push({path: 'http://localhost:3000/assets/games/online/slots/sounds/',filename:'symbol5',loop:false,volume:1, ingamename: 'symbol5'});
        CMain.s_aSoundsInfo.push({path: 'http://localhost:3000/assets/games/online/slots/sounds/',filename:'symbol6',loop:false,volume:1, ingamename: 'symbol6'});
        CMain.s_aSoundsInfo.push({path: 'http://localhost:3000/assets/games/online/slots/sounds/',filename:'symbol7',loop:false,volume:1, ingamename: 'symbol7'});
        CMain.s_aSoundsInfo.push({path: 'http://localhost:3000/assets/games/online/slots/sounds/',filename:'symbol8',loop:false,volume:1, ingamename: 'symbol8'});
        CMain.s_aSoundsInfo.push({path: 'http://localhost:3000/assets/games/online/slots/sounds/',filename:'symbol9',loop:false,volume:1, ingamename: 'symbol9'});
        CMain.s_aSoundsInfo.push({path: 'http://localhost:3000/assets/games/online/slots/sounds/',filename:'avatar_win',loop:false,volume:1, ingamename: 'avatar_win'});
        CMain.s_aSoundsInfo.push({path: 'http://localhost:3000/assets/games/online/slots/sounds/',filename:'bonus_end',loop:false,volume:1, ingamename: 'bonus_end'});
        CMain.s_aSoundsInfo.push({path: 'http://localhost:3000/assets/games/online/slots/sounds/',filename:'bonus_end_win',loop:false,volume:1, ingamename: 'bonus_end_win'});
        CMain.s_aSoundsInfo.push({path: 'http://localhost:3000/assets/games/online/slots/sounds/',filename:'character_jump',loop:false,volume:1, ingamename: 'character_jump'});
        CMain.s_aSoundsInfo.push({path: 'http://localhost:3000/assets/games/online/slots/sounds/',filename:'character_landing',loop:false,volume:1, ingamename: 'character_landing'});
        CMain.s_aSoundsInfo.push({path: 'http://localhost:3000/assets/games/online/slots/sounds/',filename:'soundtrack_bonus',loop:true,volume:1, ingamename: 'soundtrack_bonus'});
        CMain.s_aSoundsInfo.push({path: 'http://localhost:3000/assets/games/online/slots/sounds/',filename:'character_landing_pot',loop:false,volume:1, ingamename: 'character_landing_pot'});
        CMain.s_aSoundsInfo.push({path: 'http://localhost:3000/assets/games/online/slots/sounds/',filename:'character_falling',loop:false,volume:1, ingamename: 'character_falling'});
        CMain.s_aSoundsInfo.push({path: 'http://localhost:3000/assets/games/online/slots/sounds/',filename:'bonus_mult',loop:false,volume:1, ingamename: 'bonus_mult'});
        CMain.s_aSoundsInfo.push({path: 'http://localhost:3000/assets/games/online/slots/sounds/',filename:'suspance',loop:true,volume:1, ingamename: 'suspance'});

        this.RESOURCE_TO_LOAD += CMain.s_aSoundsInfo.length;

        CMain.s_aSounds = new Array();
        for(var i=0; i<CMain.s_aSoundsInfo.length; i++){
            this.tryToLoadSound(CMain.s_aSoundsInfo[i], false);
        }

    };
    private tryToLoadSound = (oSoundInfo: any, bDelay: any) => {
        //TODO - replace Howler library

    };
    private _loadImages = () => {
        console.log('loading sprites')
        if (!CMain.s_oSpriteLibrary) {
            return;
        }
        CMain.s_oSpriteLibrary.init( this._onImagesLoaded,this._onAllImagesLoaded, this );
        CMain.s_oSpriteLibrary.addSprite("bg_game","http://localhost:3000/assets/games/online/slots/sprites/bg_game.jpg");
        CMain.s_oSpriteLibrary.addSprite("paytable1","http://localhost:3000/assets/games/online/slots/sprites/paytable1.jpg");
        CMain.s_oSpriteLibrary.addSprite("paytable2","http://localhost:3000/assets/games/online/slots/sprites/paytable2.jpg");
        CMain.s_oSpriteLibrary.addSprite("paytable3","http://localhost:3000/assets/games/online/slots/sprites/paytable3.jpg");
        CMain.s_oSpriteLibrary.addSprite("paytable4","http://localhost:3000/assets/games/online/slots/sprites/paytable4.jpg");
        CMain.s_oSpriteLibrary.addSprite("mask_slot","http://localhost:3000/assets/games/online/slots/sprites/mask_slot.png");
        CMain.s_oSpriteLibrary.addSprite("win_frame_anim_0","http://localhost:3000/assets/games/online/slots/sprites/win_frame_anim_0.png");
        CMain.s_oSpriteLibrary.addSprite("win_frame_anim_1","http://localhost:3000/assets/games/online/slots/sprites/win_frame_anim_1.png");
        CMain.s_oSpriteLibrary.addSprite("win_frame_anim_big_0","http://localhost:3000/assets/games/online/slots/sprites/win_frame_anim_big_0.png");
        CMain.s_oSpriteLibrary.addSprite("win_frame_anim_big_1","http://localhost:3000/assets/games/online/slots/sprites/win_frame_anim_big_1.png");
        CMain.s_oSpriteLibrary.addSprite("win_frame_anim_big_2","http://localhost:3000/assets/games/online/slots/sprites/win_frame_anim_big_2.png");
        CMain.s_oSpriteLibrary.addSprite("win_frame_anim_big_3","http://localhost:3000/assets/games/online/slots/sprites/win_frame_anim_big_3.png");
        CMain.s_oSpriteLibrary.addSprite("win_frame_anim_big_4","http://localhost:3000/assets/games/online/slots/sprites/win_frame_anim_big_4.png");
        CMain.s_oSpriteLibrary.addSprite("win_frame_anim_big_5","http://localhost:3000/assets/games/online/slots/sprites/win_frame_anim_big_5.png");
        CMain.s_oSpriteLibrary.addSprite("win_frame_anim_big_6","http://localhost:3000/assets/games/online/slots/sprites/win_frame_anim_big_6.png");
        CMain.s_oSpriteLibrary.addSprite("win_frame_anim_big_7","http://localhost:3000/assets/games/online/slots/sprites/win_frame_anim_big_7.png");
        CMain.s_oSpriteLibrary.addSprite("but_text","http://localhost:3000/assets/games/online/slots/sprites/but_text.png");
        CMain.s_oSpriteLibrary.addSprite("msg_box","http://localhost:3000/assets/games/online/slots/sprites/msg_box.png");
        CMain.s_oSpriteLibrary.addSprite("msg_box_small","http://localhost:3000/assets/games/online/slots/sprites/msg_box_small.png");
        CMain.s_oSpriteLibrary.addSprite("but_arrow_next","http://localhost:3000/assets/games/online/slots/sprites/but_arrow_next.png");
        CMain.s_oSpriteLibrary.addSprite("but_arrow_prev","http://localhost:3000/assets/games/online/slots/sprites/but_arrow_prev.png");
        CMain.s_oSpriteLibrary.addSprite("bg_loading_bonus","http://localhost:3000/assets/games/online/slots/sprites/bg_loading_bonus.jpg");
        CMain.s_oSpriteLibrary.addSprite("but_exit_info","http://localhost:3000/assets/games/online/slots/sprites/but_exit_info.png");
        CMain.s_oSpriteLibrary.addSprite("bg_freespins","http://localhost:3000/assets/games/online/slots/sprites/bg_freespins.png");
        CMain.s_oSpriteLibrary.addSprite("amount_freespins","http://localhost:3000/assets/games/online/slots/sprites/amount_freespins.png");
        CMain.s_oSpriteLibrary.addSprite("amount_freespin_win","http://localhost:3000/assets/games/online/slots/sprites/amount_freespin_win.png");
        CMain.s_oSpriteLibrary.addSprite("amount_bonus_win","http://localhost:3000/assets/games/online/slots/sprites/amount_bonus_win.png");

        for(var i=0;i<62;i++){
            CMain.s_oSpriteLibrary.addSprite("logo_"+i,"http://localhost:3000/assets/games/online/slots/sprites/logo/logo_"+i+".png");
        }

        for(var t=0;t<CMain.NUM_SYMBOLS;t++){
            CMain.s_oSpriteLibrary.addSprite("symbol_"+t,"http://localhost:3000/assets/games/online/slots/sprites/symbol_"+t+".png");
            for(var k=0;k<8;k++){
                CMain.s_oSpriteLibrary.addSprite("symbol_"+t+"_"+k,"http://localhost:3000/assets/games/online/slots/sprites/symbols/symbol_"+t+"_"+k+".jpg");
            }
        }

        CMain.s_oSpriteLibrary.addSprite("bet_but","http://localhost:3000/assets/games/online/slots/sprites/paylines/bet_but.png");
        CMain.s_oSpriteLibrary.addSprite("but_credits","http://localhost:3000/assets/games/online/slots/sprites/but_credits.png");
        CMain.s_oSpriteLibrary.addSprite("but_delete_savings","http://localhost:3000/assets/games/online/slots/sprites/but_delete_savings.png");
        CMain.s_oSpriteLibrary.addSprite("but_exit","http://localhost:3000/assets/games/online/slots/sprites/but_exit.png");
        CMain.s_oSpriteLibrary.addSprite("but_fullscreen","http://localhost:3000/assets/games/online/slots/sprites/but_fullscreen.png");
        CMain.s_oSpriteLibrary.addSprite("but_no","http://localhost:3000/assets/games/online/slots/sprites/but_no.png");
        CMain.s_oSpriteLibrary.addSprite("but_play","http://localhost:3000/assets/games/online/slots/sprites/but_play.png");
        CMain.s_oSpriteLibrary.addSprite("but_yes","http://localhost:3000/assets/games/online/slots/sprites/but_yes.png");
        CMain.s_oSpriteLibrary.addSprite("ctl_logo","http://localhost:3000/assets/games/online/slots/sprites/ctl_logo.png");
        CMain.s_oSpriteLibrary.addSprite("audio_icon","http://localhost:3000/assets/games/online/slots/sprites/audio_icon.png");
        CMain.s_oSpriteLibrary.addSprite("bg_menu","http://localhost:3000/assets/games/online/slots/sprites/bg_menu.jpg");
        CMain.s_oSpriteLibrary.addSprite("logo_menu","http://localhost:3000/assets/games/online/slots/sprites/logo_menu.png");

        for(var j=1;j<CMain.NUM_PAYLINES+1;j++){
            CMain.s_oSpriteLibrary.addSprite("payline_"+j,"http://localhost:3000/assets/games/online/slots/sprites/paylines/payline_"+j+".png");
        }

        for(var t=0;t<191;t++){
            CMain.s_oSpriteLibrary.addSprite("suspance_"+t,"http://localhost:3000/assets/games/online/slots/sprites/suspance/suspance_"+t+".png");
        }


        for(var t=0;t<289;t++){
            CMain.s_oSpriteLibrary.addSprite("avatar_"+t,"http://localhost:3000/assets/games/online/slots/sprites/avatar/avatar_"+t+".png");
        }

        this.RESOURCE_TO_LOAD += CMain.s_oSpriteLibrary.getNumSprites();

        CMain.s_oSpriteLibrary.loadSprites();
        console.log('sprites loaded')
    };
    private _onImagesLoaded = () => {
        this._iCurResource++;

        var iPerc = Math.floor(this._iCurResource/this.RESOURCE_TO_LOAD *100);

        this._oPreloader.refreshLoader(iPerc);

    };
    private _onAllImagesLoaded = () => {
        setTimeout(() => {
            this.settingPhase(this._oData);
            this._oGame = new CGame(this._oData);

            this._iState = CMain.STATE_GAME;
        }, 1500)

    };
    public _onRemovePreloader = () => {
    };
    private settingPhase = (oInfos: any) => {

        try{
            saveItem(CMain.LOCALSTORAGE_STRING+"ls_available","ok");
        }catch(evt){
            // localStorage not defined
            CMain.s_bStorageAvailable = false;
        }

        CMain.s_oGameSettings = new CSlotSettings();
        CMain.s_oMsgBox = new CMsgBox();

        this._oPreloader.unload();
        console.log("oinfos ", oInfos)

        CMain.COIN_BET = oInfos.bets ?? [];
        CMain.START_BET = oInfos.start_bet;
        CMain.MIN_BET  = oInfos.bets ?? [ 10 ][0];
        CMain.MIN_REEL_LOOPS = this._oData.min_reel_loop;
        CMain.REEL_DELAY = this._oData.reel_delay;
        CMain.TIME_SHOW_WIN = this._oData.time_show_win;
        CMain.TIME_SHOW_ALL_WINS = this._oData.time_show_all_wins;
        //TOTAL_MONEY = oInfos.start_money;
        CMain.ENABLE_FULLSCREEN = this._oData.fullscreen ?? false;
        CMain.SHOW_CREDITS = this._oData.show_credits;
        CMain.ENABLE_CHECK_ORIENTATION = this._oData.check_orientation;
        CMain.PAYTABLE_VALUES = oInfos.paytable ?? [];
        playSound("ambience_game",1,true);
        this.gotoMenu();
    };
    public gotoMenu = () => {
        this._oMenu = new CMenu();
        this._iState = CMain.STATE_MENU;
    };
    public gotoGame = () => {
        this._oGame = new CGame(this._oData);

        this._iState = CMain.STATE_GAME;
    };
    public stopUpdate = () => {
        this._bUpdate = false;
        createjs.Ticker.paused = true;
        console.log("TODO: Replace JQuery stopUpdate function!")
        // $("#block_game").css("display","block"); // TODO Grab by reference not JQuery by selector

        if(CMain.DISABLE_SOUND_MOBILE === false || CMain.s_bMobile === false){
            // Howler.mute(true); //TODO Howler library
        }

    };
    public startUpdate = () => {
        CMain.s_iPrevTime = new Date().getTime();
        this._bUpdate = true;
        createjs.Ticker.paused = false;
        console.log("TODO: Replace JQuery startUpdate function!")
        // $("#block_game").css("display","none"); // TODO Grab by reference not JQuery by selector

        if(CMain.DISABLE_SOUND_MOBILE === false || CMain.s_bMobile === false){
            if(CMain.s_bAudioActive){
                // Howler.mute(false); // TODO Howler Library
            }
        }

    };
    private stopUpdateNoBlock = () => {
        this._bUpdate = false;
        createjs.Ticker.paused = true;
    };
    private startUpdateNoBlock = () => {
        CMain.s_iPrevTime = new Date().getTime();
        this._bUpdate = true;
        createjs.Ticker.paused = false;
    };

    private _update = (event: any) => {
        if(this._bUpdate === false){
            return;
        }

        var iCurTime = new Date().getTime();
        CMain.s_iTimeElaps = iCurTime - CMain.s_iPrevTime;
        CMain.s_iCntTime += CMain.s_iTimeElaps;
        CMain.s_iCntFps++;
        CMain.s_iPrevTime = iCurTime;

        if ( CMain.s_iCntTime >= 1000 ){
            CMain.s_iCurFps = CMain.s_iCntFps;
            CMain.s_iCntTime-=1000;
            CMain.s_iCntFps = 0;
        }
        if(this._iState === CMain.STATE_GAME){
            this._oGame?.update();
        }

        CMain.s_oStage.update(event);
    };


}