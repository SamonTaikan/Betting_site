import {CMain} from "./CMain";
import {CTLText} from "./CTLText";
import {CGfxButton} from "./CGfxButton";
import {createBitmap} from "./ctl_utils";

export class CAreYouSurePanel {
    private _aCbCompleted: any;
    private _aCbOwner: any;
    private _oListenerBlock: any;

    private _oBg: any;
    private _oMsg: any;
    private _oButYes: any;
    private _oButNo: any;
    private _oContainerPanel: any;
    private _oContainer: any;
    private _oFade: any;

    constructor() {
        this._init();
    }

    private _init = () => {
        this._aCbCompleted = new Array();
        this._aCbOwner = new Array();

        this._oContainer = new createjs.Container();
        this._oContainer.visible = false;
        CMain.s_oStage.addChild(this._oContainer);

        this._oFade = new createjs.Shape();
        this._oListenerBlock = this._oFade.on("click",function(){});
        this._oFade.alpha = 0;
        this._oFade.graphics.beginFill("black").drawRect(0,0,CMain.CANVAS_WIDTH,CMain.CANVAS_HEIGHT);
        this._oContainer.addChild(this._oFade);

        var oSpriteBg = CMain.s_oSpriteLibrary!!.getSprite('msg_box_small');

        this._oContainerPanel = new createjs.Container();
        this._oContainerPanel.x = CMain.CANVAS_WIDTH/2;
        this._oContainerPanel.y = CMain.CANVAS_HEIGHT/2;
        this._oContainerPanel.regX = oSpriteBg.width * 0.5;
        this._oContainerPanel.regY = oSpriteBg.height * 0.5;
        this._oContainer.addChild(this._oContainerPanel);


        this._oBg = createBitmap(oSpriteBg);
        this._oContainerPanel.addChild(this._oBg);

        this._oMsg = new CTLText(this._oContainerPanel,
            50, 80, oSpriteBg.width-100, 140,
            70, "center", "#fede00", CMain.FONT_GAME_1, 1,
            0, 0,
            CMain.TEXT_ARE_SURE,
            true, true, true,
            false );



        this._oButYes = new CGfxButton( oSpriteBg.width - 130,  304, CMain.s_oSpriteLibrary!!.getSprite('but_yes'), this._oContainerPanel);
        this._oButYes.addEventListener(CMain.ON_MOUSE_UP, this._onButYes, this);

        this._oButNo = new CGfxButton( 130,  304, CMain.s_oSpriteLibrary!!.getSprite('but_no'), this._oContainerPanel);
        this._oButNo.addEventListener(CMain.ON_MOUSE_UP, this._onButNo, this);

        this.disableButtons();
    };
    private addEventListener = (iEvent: any, cbCompleted: any, cbOwner: any) => {
        this._aCbCompleted[iEvent] = cbCompleted;
        this._aCbOwner[iEvent] = cbOwner;
    };
    private disableButtons = () => {
        this._oButYes.disable();
        this._oButNo.disable();
    };
    private enableButtons = () => {
        this._oButNo.enable();
        this._oButYes.enable();
    };
    private show = (szMsg: any) => {
        this._oMsg.refreshText( szMsg);

        this._oContainer.visible = true;
        this._oContainerPanel.scale = 0;
        this._oFade.alpha = 0;
        const _This = this;
        createjs.Tween.get(this._oFade).to({alpha: 0.7}, 300, createjs.Ease.quartOut)
        createjs.Tween.get(this._oContainerPanel).to({scale:1}, 1000, createjs.Ease.elasticOut).call(function(){
            //s_oMain.stopUpdateNoBlock();
            _This.enableButtons();
        });
    };
    private hide = (bExit: any) => {
        //s_oMain.startUpdateNoBlock();

        createjs.Tween.get(this._oFade).to({alpha: 0}, 500, createjs.Ease.quartOut)
        const _aCbCompleted = this._aCbCompleted;
        const _aCbOwner = this._aCbCompleted;
        const _oContainer = this._oContainer;
        createjs.Tween.get(this._oContainerPanel).to({scale: 0}, 500, createjs.Ease.backIn).call(function(){
            _oContainer.visible = false;
            if(bExit){
                if (_aCbCompleted[CMain.ON_BUT_YES_DOWN]) {
                    _aCbCompleted[CMain.ON_BUT_YES_DOWN].call(_aCbOwner[CMain.ON_BUT_YES_DOWN]);
                }
            }
        });
    };
    private unload = () => {
        this._oButNo.unload();
        this._oButYes.unload();
        this._oFade.off("click",this._oListenerBlock);
    };
    private _onButYes = () => {
        this.disableButtons();
        this.hide(true);
    };
    private _onButNo = () => {
        this.disableButtons();
        this.hide(false);
    };
}