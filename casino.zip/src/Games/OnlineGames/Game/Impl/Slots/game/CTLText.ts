export class CTLText {

    private _oContainer: any;

    private _x: any;
    private _y: any;
    private _iWidth: any;
    private _iHeight: any;

    private _bMultiline: any;

    private _iFontSize: any;
    private _szAlign: any;
    private _szColor: any;
    private _szFont: any;

    private _iPaddingH: any;
    private _iPaddingV: any;

    private _bVerticalAlign: any;
    private _bFitText: any;
    private _bDebug: any;

    // RESERVED
    private _oDebugShape: any;
    private _fLineHeightFactor: any;

    private _oText: any = null;

    constructor(
        oContainer: any,
        x: any,
        y: any,
        iWidth: any,
        iHeight: any,
        iFontSize: any,
        szAlign: any,
        szColor: any,
        szFont: any,
        iLineHeightFactor: any,
        iPaddingH: any,
        iPaddingV: any,
        szMsg: any,
        bFitText: any,
        bVerticalAlign: any,
        bMultiline: any,
        bDebug: any
    ) {

        this._oContainer = oContainer;

        this._x = x;
        this._y = y;
        this._iWidth = iWidth;
        this._iHeight = iHeight;

        this._bMultiline = bMultiline;

        this._iFontSize = iFontSize;
        this._szAlign = szAlign;
        this._szColor = szColor;
        this._szFont = szFont;

        this._iPaddingH = iPaddingH;
        this._iPaddingV = iPaddingV;

        this._bVerticalAlign = bVerticalAlign;
        this._bFitText = bFitText;
        this._bDebug = bDebug;

        // RESERVED
        this._oDebugShape = null;
        this._fLineHeightFactor = iLineHeightFactor;

        this._oText = null;
        if (szMsg) {
            this._createText(szMsg);
        }
    }

    private _autofit = () => {
        if (this._bFitText) {

            var iFontSize = this._iFontSize;

            while (
                this._oText.getBounds().height > (this._iHeight - this._iPaddingV * 2) ||
                this._oText.getBounds().width > (this._iWidth - this._iPaddingH * 2)
                ) {
                iFontSize--;

                this._oText.font = iFontSize + "px " + this._szFont;
                this._oText.lineHeight = Math.round(iFontSize * this._fLineHeightFactor);

                this._updateY();
                this._verticalAlign();

                if (iFontSize < 8) {
                    break;
                }
            }
            ;

            this._iFontSize = iFontSize;
        }
    };
    private _verticalAlign = () => {
        if (this._bVerticalAlign) {
            var iCurHeight = this._oText.getBounds().height;
            this._oText.y -= (iCurHeight - this._iHeight) / 2 + (this._iPaddingV);
        }
    };
    private _updateY = () => {

        this._oText.y = this._y + this._iPaddingV;

        switch (this._oText.textBaseline) {
            case "middle": {
                this._oText.y += (this._oText.lineHeight / 2) +
                    (this._iFontSize * this._fLineHeightFactor - this._iFontSize);
            }
                break;
        }
    };
    private _createText = (szMsg: any) => {

        if (this._bDebug) {
            this._oDebugShape = new createjs.Shape();
            this._oDebugShape.graphics.beginFill("rgba(255,0,0,0.5)").drawRect(
                this._x, this._y, this._iWidth, this._iHeight);
            this._oContainer.addChild(this._oDebugShape);
        }

        this._oText = new createjs.Text(szMsg, this._iFontSize + "px " + this._szFont, this._szColor);
        this._oText.textAlign = "middle";
        this._oText.textBaseline = "middle";
        this._oText.lineHeight = Math.round(this._iFontSize * this._fLineHeightFactor);
        this._oText.textAlign = this._szAlign;


        if (this._bMultiline) {
            this._oText.lineWidth = this._iWidth - (this._iPaddingH * 2);
        } else {
            this._oText.lineWidth = null;
        }

        switch (this._szAlign) {
            case "center": {
                this._oText.x = this._x + (this._iWidth / 2);
            }
                break;
            case "left": {
                this._oText.x = this._x + this._iPaddingH;
            }
                break;
            case "right": {
                this._oText.x = this._x + this._iWidth - this._iPaddingH;
            }
                break;
        }

        this._oContainer.addChild(this._oText);

        this.refreshText(szMsg);

    };
    private setVerticalAlign = (bVerticalAlign: any) => {
        this._bVerticalAlign = bVerticalAlign;
    };
    private setOutline = (iSize: any) => {
        if (this._oText !== null) {
            this._oText.outline = iSize;
        }
    };
    private setShadow = (szColor: any,iOffsetX: any,iOffsetY: any,iBlur: any) => {
        if (this._oText !== null) {
            this._oText.shadow = new createjs.Shadow(szColor, iOffsetX, iOffsetY, iBlur);
        }
    };
    private setColor = (szColor: any) => {
        this._oText.color = szColor;
    };
    private setAlpha = (iAlpha: any) => {
        this._oText.alpha = iAlpha;
    };
    private setY = (iNewY: any) => {
        this._oText.y = iNewY;
        this._y = iNewY;
    };
    private removeTweens = () => {
        createjs.Tween.removeTweens(this._oText);
    };
    private getText = () => {
        return this._oText;
    };
    private getString = () => {
        return this._oText.text;
    };
    private getY = () => {
        return this._y;
    };
    private getFontSize = () => {
        return this._iFontSize;
    };
    private refreshText = (szMsg: any) => {
        if (szMsg === "") {
            szMsg = " ";
        }
        if (this._oText === null) {
            this._createText(szMsg);
        }

        if (this._oText !== null) {
            this._oText.text = szMsg;

            this._oText.font = this._iFontSize + "px " + this._szFont;
            this._oText.lineHeight = Math.round(this._iFontSize * this._fLineHeightFactor);
        }
        this._autofit();
        this._updateY();
        this._verticalAlign();
    }

}