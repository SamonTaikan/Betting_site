import {CMain} from "./CMain";
import {createSprite, playSound} from "./ctl_utils";

export class CBonusBut{
    private _bDisabled: any;

    private _iScaleFactor: any;

    private _aCbCompleted: any;
    private _aCbOwner: any;
    private _aParams: any;
    private _oListenerDown: any;
    private _oListenerRelease: any;
    private _oListenerOver: any;

    private _oContainer: any;
    private _oButton: any;
    private _oPot: any;
    private _oTween: any;
    private _oParent: any;
    private _oParentContainer: any;

    constructor(
        iXPos: any,
        iYPos: any,
        bFinalPrize: any,
        oSprite: any,
        oParentContainer: any
    ){
        this._oParentContainer = oParentContainer;
        this._init(iXPos,iYPos,bFinalPrize,oSprite, oParentContainer);
    }

    private _init = (iXPos: any,iYPos: any,bFinalPrize: any,oSprite: any, oParentContainer: any) => {
        this._bDisabled = false;

        this._iScaleFactor = 1;

        this._aCbCompleted=new Array();
        this._aCbOwner =new Array();

        this._oContainer = new createjs.Container();
        this._oContainer.x = iXPos;
        this._oContainer.y = iYPos;
        this._oContainer.scaleX =   this._oContainer.scaleY = this._iScaleFactor;
        oParentContainer.addChild(this._oContainer);

        var oData = {   // image to use
            images: [oSprite],
            // width, height & registration point of each sprite
            frames: {width: oSprite.width/2, height: oSprite.height,regX:oSprite.width/4,regY:oSprite.height/2},
            animations: {  state_0: 0,state_1:1 }
        };

        var oSpriteSheet = new createjs.SpriteSheet(oData);

        this._oButton = createSprite(oSpriteSheet, "state_0",oSprite.width/4,oSprite.height/2,oSprite.width/2,oSprite.height);
        this._oContainer.addChild(this._oButton);

        if(bFinalPrize){
            //ATTACH GOLD POT
            var aSprites = new Array();
            for(var k=0;k<56;k++){
                aSprites.push(CMain.s_oSpriteLibrary!!.getSprite("character_pot_"+k));
            }
            // @ts-ignore
            var oData = {
                images: aSprites,
                // width, height & registration point of each sprite
                frames: {width: 283, height: 459, regX: 141, regY: 459},
                animations: {start:0,anim:[8,55,"stop"],stop:55}
            };

            var oSpriteSheet = new createjs.SpriteSheet(oData);
            this._oPot = createSprite(oSpriteSheet, "start",166,538,332,538);
            this._oPot.y = -32;
            this._oContainer.addChild(this._oPot);
        }

        this._initListener();
    };

    private unload = () => {
        if(CMain.s_bMobile){
            this._oContainer.off("mousedown", this._oListenerDown);
            this._oContainer.off("click" , this._oListenerRelease);
        } else {
            this._oContainer.off("mousedown", this._oListenerDown);
            this._oContainer.off("mouseover", this._oListenerOver);
            this._oContainer.off("click" , this._oListenerRelease);
        }

        this._oParentContainer.removeChild(this._oContainer);
    };

    private setVisible = (bVisible: any) => {
        this._oContainer.visible = bVisible;
    };

    private setClickable = (bVal: any) => {
        this._bDisabled = !bVal;
    };

    private _initListener = () => {
        if(CMain.s_bMobile){
            this._oListenerDown = this._oContainer.on("mousedown", this.buttonDown);
            this._oListenerRelease = this._oContainer.on("click" , this.buttonRelease);
        } else {
            this._oListenerDown = this._oContainer.on("mousedown", this.buttonDown);
            this._oListenerOver = this._oContainer.on("mouseover", this.buttonOver);
            this._oListenerRelease = this._oContainer.on("click" , this.buttonRelease);
        }
    };

    private addEventListener = (iEvent: any,cbCompleted: any, cbOwner: any ) => {
        this._aCbCompleted[iEvent]=cbCompleted;
        this._aCbOwner[iEvent] = cbOwner;
    };

    public addEventListenerWithParams = (iEvent: any,cbCompleted: any, cbOwner: any,aParams: any) => {
        this._aCbCompleted[iEvent]=cbCompleted;
        this._aCbOwner[iEvent] = cbOwner;
        this._aParams = aParams;
    };

    private buttonRelease = () => {
        if(this._bDisabled){
            return;
        }
        this._oContainer.scaleX = this._iScaleFactor;
        this._oContainer.scaleY = this._iScaleFactor;

        playSound("click",1,false);

        if(this._aCbCompleted[CMain.ON_MOUSE_UP]){
            this._aCbCompleted[CMain.ON_MOUSE_UP].call(this._aCbOwner[CMain.ON_MOUSE_UP],this._aParams);
        }
    };

    private buttonDown = () => {
        if(this._bDisabled){
            return;
        }

        if(this._aCbCompleted[CMain.ON_MOUSE_DOWN]){
            this._aCbCompleted[CMain.ON_MOUSE_DOWN].call(this._aCbOwner[CMain.ON_MOUSE_DOWN],this._aParams);
        }
    };

    private buttonOver = (evt: any) => {
        if(!CMain.s_bMobile){
            if(this._bDisabled){
                return;
            }
            evt.target.cursor = "pointer";
        }
    };

    private trembleAnimation = () => {
        this._oTween = createjs.Tween.get(this._oContainer).to({rotation: 5}, 75, createjs.Ease.quadOut).to({rotation: -5}, 140, createjs.Ease.quadIn).to({rotation: 0}, 75, createjs.Ease.quadIn);
    };

    public moveY = (iFinalY: any,iTime: any,iDelay: any,oEasing: any) => {
        this._oTween = createjs.Tween.get(this._oContainer).wait(iDelay).to({y:iFinalY}, iTime, oEasing);
    };

    private playPotAnim = () => {
        this._oPot.gotoAndPlay("anim");
    };

    private setPosition = (iXPos: any,iYPos: any) => {
        this._oContainer.x = iXPos;
        this._oContainer.y = iYPos;
    };

    private setX = (iXPos: any) => {
        this._oContainer.x = iXPos;
    };

    private setY = (iYPos: any) => {
        this._oContainer.y = iYPos;
    };

    private getButtonImage = () => {
        return this._oContainer;
    };

    private getX = () => {
        return this._oContainer.x;
    };

    private getY = () => {
        return this._oContainer.y;
    };
}