import {CMain} from "./CMain";

export class CSlotSettings{

    public static s_aSymbolData: any;
    public static s_aPaylineCombo: any;
    public static s_aSymbolAnims: any;
    public static s_aRandSymbols: any;

    constructor() {
        console.log('Slot constructor called!!')
        this._init();
    }

    private _init = () => {
        console.log("Init called!!")
        this._initSymbolSpriteSheets();
        this._initSymbolAnims();
        this._initSymbolsOccurence();
    };
    private _initSymbolSpriteSheets = () => {
        CSlotSettings.s_aSymbolData = new Array();
        console.log("SET TO ", CSlotSettings.s_aRandSymbols)
        if (!CMain.s_oSpriteLibrary) return;
        for (var i = 0; i < CMain.NUM_SYMBOLS; i++) {
            var oSprite = CMain.s_oSpriteLibrary.getSprite('symbol_' + i);
            var oData = {   // image to use
                images: [oSprite],
                // width, height & registration point of each sprite
                frames: {width: CMain.SYMBOL_WIDTH, height: oSprite.height, regX: 0, regY: 0},
                animations: {static: 0, moving: 1}
            };

            CSlotSettings.s_aSymbolData[i] = new createjs.SpriteSheet(oData);
        }
    };
    private _initSymbolsOccurence = () => {
        CSlotSettings.s_aRandSymbols = new Array();

        var i;

        for (i = 0; i < 1; i++) {
            CSlotSettings.s_aRandSymbols.push(9);
        }

        for (i = 0; i < 2; i++) {
            CSlotSettings.s_aRandSymbols.push(8);
        }

        for (i = 0; i < 3; i++) {
            CSlotSettings.s_aRandSymbols.push(7);
        }

        for (i = 0; i < 4; i++) {
            CSlotSettings.s_aRandSymbols.push(6);
        }


        for (i = 0; i < 5; i++) {
            CSlotSettings.s_aRandSymbols.push(5);
        }

        for (i = 0; i < 6; i++) {
            CSlotSettings.s_aRandSymbols.push(4);
        }


        for (i = 0; i < 7; i++) {
            CSlotSettings.s_aRandSymbols.push(3);
        }


        for (i = 0; i < 8; i++) {
            CSlotSettings.s_aRandSymbols.push(2);
            CSlotSettings.s_aRandSymbols.push(1);
            CSlotSettings.s_aRandSymbols.push(0);
        }

    };
    private _initSymbolAnims = () => {
        CSlotSettings.s_aSymbolAnims = new Array();
        if (!CMain.s_oSpriteLibrary) return;
        for (var k = 0; k < CMain.NUM_SYMBOLS; k++) {
            var oData = {
                framerate: CMain.FPS,
                images: [CMain.s_oSpriteLibrary.getSprite("symbol_" + k + "_0"),
                    CMain.s_oSpriteLibrary.getSprite("symbol_" + k + "_1"),
                    CMain.s_oSpriteLibrary.getSprite("symbol_" + k + "_2"),
                    CMain.s_oSpriteLibrary.getSprite("symbol_" + k + "_3"),
                    CMain.s_oSpriteLibrary.getSprite("symbol_" + k + "_4"),
                    CMain.s_oSpriteLibrary.getSprite("symbol_" + k + "_5"),
                    CMain.s_oSpriteLibrary.getSprite("symbol_" + k + "_6"),
                    CMain.s_oSpriteLibrary.getSprite("symbol_" + k + "_7")],

                // width, height & registration point of each sprite
                frames: {width: CMain.SYMBOL_ANIM_WIDTH, height: CMain.SYMBOL_ANIM_HEIGHT},
                animations: {static: 0, anim: [0, 119]}
            };

            CSlotSettings.s_aSymbolAnims[k] = new createjs.SpriteSheet(oData);


        }

    };
}
