import {CMain} from "./CMain";

export class CScoreText{

    private _oScoreHit: any;
    private _oParentContainer: any;

    constructor(
        iScore: any,
        x: any,
        y: any,
        oParentContainer: any
    ){
        this._oParentContainer = oParentContainer;
        this._init(iScore,x,y);
    }

    private _init = (iScore: any,x: any,y: any) => {

        this._oScoreHit = new createjs.Text("00000","100px "+ CMain.FONT_GAME_1, "#fede00");
        this._oScoreHit.textAlign="center";
        this._oScoreHit.text = iScore;
        this._oScoreHit.x = x;
        this._oScoreHit.y = y;
        this._oScoreHit.alpha = 0;
        this._oScoreHit.shadow = new createjs.Shadow("#000", 1, 1, 1);
        this._oParentContainer.addChild(this._oScoreHit);

        var oParent = this;
        createjs.Tween.get(this._oScoreHit).to({alpha:1}, 200, createjs.Ease.quadIn).call(function(){oParent.moveUp();});
    };
    private moveUp = () => {
        var iNewY = this._oScoreHit.y-400;
        var oParent = this;
        createjs.Tween.get(this._oScoreHit).to({y:iNewY}, 1500, createjs.Ease.sineIn).call(function(){oParent.unload();});
        createjs.Tween.get(this._oScoreHit).wait(800).to({alpha:0}, 500);
    };
    private unload = () => {
        this._oParentContainer.removeChild(this._oScoreHit);
    };
}