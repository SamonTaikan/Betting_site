import {createBitmap, formatEntries} from "./ctl_utils";
import {CBonusPanel} from "./CBonusPanel";
import {CMain} from "./CMain";
import {CTLText} from "./CTLText";

export class CBonusResultPanel{
    private _oContainer: any;
    private _oContainerPanel: any;
    private _oParentContainer: any;
    constructor(
        iPrize: any,
        oParentContainer: any){
        this._oParentContainer = oParentContainer;
        this._init(iPrize);
    }

    private _init = (iPrize: any) => {
        this._oContainer = new createjs.Container();
        this._oParentContainer.addChild(this._oContainer);

        var oSpriteBg = CMain.s_oSpriteLibrary!!.getSprite("msg_box_small");

        this._oContainerPanel = new createjs.Container();
        this._oContainerPanel.x = CMain.CANVAS_WIDTH/2;
        this._oContainerPanel.y = CMain.CANVAS_HEIGHT/2;
        this._oContainerPanel.regX = oSpriteBg.width/2;
        this._oContainerPanel.regY = oSpriteBg.height/2;
        this._oContainerPanel.scale = 0;
        this._oContainer.addChild(this._oContainerPanel);

        var oBg = createBitmap(oSpriteBg);
        this._oContainerPanel.addChild(oBg);

        var oCongratsText = new CTLText(this._oContainerPanel,
            50, 80, oSpriteBg.width-100, 74,
            74, "center", "#fede00", CMain.FONT_GAME_1, 1,
            0, 0,
            CMain.TEXT_CONGRATS,
            true, true, false,
            false );


        var oWonText = new CTLText(this._oContainerPanel,
            50, 160, oSpriteBg.width-100, 280,
            70, "center", "#fede00", CMain.FONT_GAME_1, 1,
            0, 0,
            CMain.TEXT_YOU_WIN+"\n"+formatEntries(iPrize),
            true, true, true,
            false );



        var oParent = this;
        createjs.Tween.get(this._oContainerPanel).to({scale:1}, 1000, createjs.Ease.elasticOut).call(function(){
            setTimeout(function(){
                oParent.hide();
            },3000);
        });

    };

    private hide = () => {
        const _oParentContainer = this._oParentContainer;
        const _oContainer = this._oContainer;
        createjs.Tween.get(this._oContainerPanel).to({scale: 0}, 500, createjs.Ease.backIn).call(function(){
            _oParentContainer.removeChild(_oContainer);
            CBonusPanel.s_oBonusPanel.hide();
        });
    };

    private unload = () => {
        this._oParentContainer.removeChild(this._oContainer);
    };

}