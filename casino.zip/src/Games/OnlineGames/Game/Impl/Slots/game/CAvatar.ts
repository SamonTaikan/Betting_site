import {CMain} from "./CMain";
import {CGame} from "./CGame";
import {createSprite} from "./ctl_utils";

export class CAvatar {

    private _pStartPosAvatar: any;
    private _oSpriteAvatar: any;
    private _oContainer: any;
    private _oParentContainer: any;

    constructor(
        oParentContainer: any
    ){
        this._oParentContainer = oParentContainer;
        this._init();
    }

    private _init = () => {
        this._pStartPosAvatar = {x:-100,y: CMain.CANVAS_HEIGHT};

        this._oContainer = new createjs.Container();
        this._oContainer.x = this._pStartPosAvatar.x;
        this._oContainer.y = this._pStartPosAvatar.y;
        this._oParentContainer.addChild(this._oContainer);



        var aSprites = new Array();
        for(var t=0;t<289;t++){
            aSprites.push(CMain.s_oSpriteLibrary!!.getSprite("avatar_"+t))
        }

        var oData = {   // image to use
            images: aSprites,
            framerate:60,
            // width, height & registration point of each sprite
            frames: {width: 382, height: 518,regX:0,regY:518},

            animations: {
                idle: [0, 121],win:[122,288,"idle"]
            }
        };

        var oSpriteSheet = new createjs.SpriteSheet(oData);
        this._oSpriteAvatar =  createSprite(oSpriteSheet, "start",0,635,649,635);
        this._oContainer.addChild(this._oSpriteAvatar);

        this.refreshButtonPos();
    };
    private _hideAllAnims = () => {

    };
    private refreshButtonPos = () => {

        if(CGame.s_iOffsetX  > 150){
            this._oContainer.x = this._pStartPosAvatar.x + CGame.s_iOffsetX;
        }else{
            this._oContainer.x = 0;
        }

        this._oContainer.y = this._pStartPosAvatar.y - CGame.s_iOffsetY;
    };
    private show = (szAnim: any) => {
        this._oSpriteAvatar.gotoAndPlay(szAnim);
    };
}