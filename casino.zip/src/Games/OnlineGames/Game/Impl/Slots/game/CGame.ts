import {CMain} from "./CMain";
import {createBitmap, createSprite, playSound, saveItem, setVolume, stopSound} from "./ctl_utils";
import {CInterface} from "./CInterface";
import {CAvatar} from "./CAvatar";
import {CPayTablePanel} from "./CPayTablePanel";
import {CBonusPanel} from "./CBonusPanel";
import {CFreespinPanel} from "./CFreespinPanel";
import {CResultFreespin} from "./CResultFreespin";
import {CRechargePanel} from "./CRechargePanel";
import {CSuspanceEffect} from "./CSuspanceEffect";
import {CTweenController} from "./CTweenController";
import {CStaticSymbolCell} from "./CStaticSymbolCell";
import {CSlotSettings} from "./CSlotSettings";
import {CReelColumn} from "./CReelColumn";

export class CGame {

    public static s_iOffsetX: number = 0;
    public static s_iOffsetY: number = 0;
    public static s_iScaleFactor = 1;
    public static s_bIsIphone = false;
    public static s_bFocus = true;

    public static s_oGame: CGame | null;
    public static s_oTweenController: CTweenController;
    private _bUpdate = false;
    private _bReadyToStop = false;
    private _bFreespinEnable: any;
    private _bAutoSpin: any;
    private _bActivateFreespin: any;
    private _iCurState: any;
    private _iCurReelLoops: any;
    private _iNextColToStop: any;
    private _iNumReelsStopped: any;
    private _iLastLineActive: any;
    private _iTimeElaps: any;
    private _iCurWinShown: any;
    private _iCurBet: any = "0.1";
    private _iTotBet: any;
    private _iMoney: any;
    private _iCurNumBonusSymbolsInReels: any;
    private _iCurNumFreespinSymbolsInReels: any;

    private _iTotWin: any;
    private _iFreeSpinWinAmount: any;
    private _fBonusWin: any;
    private _iFreeSpinWin: any;
    private _iTotFreeSpin: any;
    private _iNumAds: any;
    private _aBonusId: any;
    private _iCurCoinIndex: any;
    private _iCurMinLoops: any;
    private _aMovingColumns: any;
    private _aStaticSymbols: any;
    private _aWinningLine: any;
    private _aReelSequence: any;
    private _aFinalSymbolCombo: any;
    private _aSuspanceReel: any;
    private _pStartPosLogo: any;

    private _oBg: any;
    private _oBgFreespin: any;
    private _oLogo: any;
    private _oFrontSkin: any;
    private _oFreespinPanel: any;
    private _oFreespinResult: any;
    private _oInterface: any;
    private _oPayTable: any = null;
    private _oBonusPanel: any;
    private _oContainerSlot: any;
    private _oContainerReels: any;
    private _oAvatar: any;

    constructor(_oData: any) {
        CGame.s_oGame = this;
        this._init();
    }

    private _init = () => {
        console.log("Game initialising...")
        this._iCurState = CMain.GAME_STATE_IDLE;
        this._iCurReelLoops = 0;
        this._iNumReelsStopped = 0;
        this._iNumAds = 0;
        this._iFreeSpinWinAmount = 0;
        this._iTimeElaps = 0;
        this._aReelSequence = new Array(0,1,2,3,4);
        this._iNextColToStop = this._aReelSequence[0];
        this._iLastLineActive = CMain.NUM_PAYLINES;
        this._iMoney = CMain.TOTAL_MONEY;

        this._iCurBet = CMain.START_BET;
        this._iCurBet = parseFloat((this._iCurBet ?? 0.0).toFixed(2));

        for(var k=0;k<CMain.COIN_BET.length;k++){
            if(this._iCurBet === CMain.COIN_BET[k]){
                this._iCurCoinIndex = k;
                break;
            }
        }
        this._iTotBet = this._iCurBet * this._iLastLineActive;

        this._bAutoSpin = false;
        this._bFreespinEnable = false;
        this._iTotFreeSpin = 0;
        this._iFreeSpinWin = 0;
        this._aBonusId = [];

        CGame.s_oTweenController = new CTweenController();

        this._oBg = createBitmap(CMain.s_oSpriteLibrary!!.getSprite('bg_game'));
        // CMain.s_oAttachSection.addChild(this._oBg);

        this._oBgFreespin = createBitmap(CMain.s_oSpriteLibrary!!.getSprite("bg_freespins"));
        this._oBgFreespin.alpha = 0;
        CMain.s_oAttachSection.addChild(this._oBgFreespin);

        this._oContainerSlot = new createjs.Container();
        this._oContainerSlot.x = CMain.REEL_OFFSET_X;
        this._oContainerSlot.y = CMain.REEL_OFFSET_Y;
        this._oContainerSlot.scaleX = this._oContainerSlot.scaleY = CMain.REEL_SCALE;
        CMain.s_oAttachSection.addChild(this._oContainerSlot);

        this._initReels();

        this._oFrontSkin = createBitmap(CMain.s_oSpriteLibrary!!.getSprite('mask_slot'));
        this._oFrontSkin.x = -139;
        this._oFrontSkin.y = -58;
        this._oContainerSlot.addChild(this._oFrontSkin);

        //ADD SUSPANCE ANIMS
        this._aSuspanceReel = new Array();
        for(var t=1;t<CMain.NUM_REELS;t++){
            this._aSuspanceReel[t] = new CSuspanceEffect(CMain.START_REEL_OFFSET_X + (t)*(CMain.SYMBOL_WIDTH + CMain.SPACE_BETWEEN_SYMBOLS),CMain.START_REEL_OFFSET_Y,this._oContainerSlot);
        }

        var aSpritesLogo = new Array();
        for(var i=0;i<62;i++){
            aSpritesLogo.push(CMain.s_oSpriteLibrary!!.getSprite('logo_'+i));
        }
        var oData = {   // image to use
            images: aSpritesLogo,
            // width, height & registration point of each sprite
            frames: {width: 512, height: 209,regX:256,regY:0},
            animations: {  normal: 0,freespin:[1,61] }
        };

        this._pStartPosLogo = {x:750,y:-100};
        var oSpriteSheet = new createjs.SpriteSheet(oData);
        this._oLogo = createSprite(oSpriteSheet, "normal",256,0,512,209);
        this._oLogo.x = this._pStartPosLogo.x;
        this._oLogo.y = this._pStartPosLogo.y;
        this._oContainerSlot.addChild(this._oLogo);

        this._oInterface = new CInterface(this._iCurBet,this._iTotBet,this._oContainerSlot);
        this._initStaticSymbols();


        this._oAvatar = new CAvatar(CMain.s_oAttachSection);
        this._oAvatar.show("idle");


        this._oPayTable = new CPayTablePanel();

        this._oBonusPanel = new CBonusPanel();

        this._oFreespinPanel = new CFreespinPanel(CMain.s_oStage);

        this._oFreespinResult = new CResultFreespin(CMain.s_oStage);

        this.refreshButtonPos(CGame.s_iOffsetX, CGame.s_iOffsetY);

        playSound("ambience_game",1,true);
        console.log("Game initialised")

        this._bUpdate = true;

        if(this._iMoney < this._iTotBet){
            var oRechargePanel = new CRechargePanel();
        }
    };
    private unload = () => {
        stopSound("ambience_game");

        this._oInterface.unload();
        this._oPayTable.unload();

        for(var k=0;k<this._aMovingColumns.length;k++){
            this._aMovingColumns[k].unload();
        }

        for(var i=0;i<CMain.NUM_ROWS;i++){
            for(var j=0;j<CMain.NUM_REELS;j++){
                this._aStaticSymbols[i][j].unload();
            }
        }
        CMain.s_oMsgBox.unload();
        CMain.s_oAttachSection.removeAllChildren();
        CGame.s_oGame = null;
    };
    public refreshButtonPos = (param?: any, param2?: any) => {
        this._oInterface.refreshButtonPos();
        this._oPayTable.refreshButtonPos();
        this._oBonusPanel.refreshButtonPos();
        this._oAvatar.refreshButtonPos();
    };
    private _initReels = () => {
        this._oContainerReels = new createjs.Container();
        this._oContainerSlot.addChild(this._oContainerReels);

        var iXPos = CMain.START_REEL_OFFSET_X = 122;
        var iYPos = CMain.START_REEL_OFFSET_Y = 83;

        var oMaskReel = new createjs.Shape();
        oMaskReel.graphics.beginFill("rgba(255,0,0,0.01)").drawRect(iXPos, iYPos,
            (CMain.SYMBOL_WIDTH *CMain.NUM_REELS) + (CMain.SPACE_BETWEEN_SYMBOLS*(CMain.NUM_REELS-1)),
            (CMain.SYMBOL_HEIGHT*CMain.NUM_ROWS) + (CMain.SPACE_HEIGHT_BETWEEN_SYMBOLS*(CMain.NUM_ROWS-1)));
        this._oContainerSlot.addChild(oMaskReel);

        this._generateLosingPattern();

        var iCurDelay = 0;
        this._aMovingColumns = new Array();
        for(var i=0;i<CMain.NUM_REELS;i++){
            this._aMovingColumns[i] = new CReelColumn(i,iXPos,iYPos,iCurDelay,new Array(this._aFinalSymbolCombo[0][i],this._aFinalSymbolCombo[1][i],this._aFinalSymbolCombo[2][i]),this._oContainerReels);
            this._aMovingColumns[i+CMain.NUM_REELS] = new CReelColumn(i+CMain.NUM_REELS,iXPos,iYPos + ( ( CMain.SYMBOL_HEIGHT + CMain.SPACE_HEIGHT_BETWEEN_SYMBOLS)*CMain.NUM_ROWS),iCurDelay,
                new Array(this._aFinalSymbolCombo[0][i],this._aFinalSymbolCombo[1][i],this._aFinalSymbolCombo[2][i]),this._oContainerReels );
            iXPos += CMain.SYMBOL_WIDTH + CMain.SPACE_BETWEEN_SYMBOLS;
            iCurDelay += CMain.REEL_DELAY;
        }

        this._oContainerReels.mask = oMaskReel;

    };
    private _initStaticSymbols = () => {
        var iXPos = CMain.REEL_OFFSET_X+CMain.START_REEL_OFFSET_X;
        var iYPos = CMain.REEL_OFFSET_Y+CMain.START_REEL_OFFSET_Y;
        this._aStaticSymbols = new Array();
        for(var i=0;i<CMain.NUM_ROWS;i++){
            this._aStaticSymbols[i] = new Array();
            for(var j=0;j<CMain.NUM_REELS;j++){
                var oSymbol = new CStaticSymbolCell(i,j,iXPos,iYPos);
                this._aStaticSymbols[i][j] = oSymbol;

                iXPos += (CMain.SYMBOL_WIDTH + CMain.SPACE_BETWEEN_SYMBOLS)*CMain.REEL_SCALE;
            }
            iXPos = CMain.REEL_OFFSET_X+CMain.START_REEL_OFFSET_X;
            iYPos += (CMain.SYMBOL_HEIGHT + CMain.SPACE_HEIGHT_BETWEEN_SYMBOLS)*CMain.REEL_SCALE;
        }
    };
    private _generateRandSymbols = () => {
        var aRandSymbols = new Array();
        for (var i = 0; i < CMain.NUM_ROWS; i++) {
            var iRandIndex = Math.floor(Math.random()* CSlotSettings.s_aRandSymbols.length);
            aRandSymbols[i] = CSlotSettings.s_aRandSymbols[iRandIndex];
        }

        return aRandSymbols;
    };
    public reelArrived = (iReelIndex: any,iCol: any) => {

        if(this._iCurReelLoops > this._iCurMinLoops ){
            if (this._iNextColToStop === iCol) {

                if (this._aMovingColumns[iReelIndex].isReadyToStop() === false) {
                    var iNewReelInd = iReelIndex;

                    if (iReelIndex < CMain.NUM_REELS) {
                        iNewReelInd += CMain.NUM_REELS;

                        this._aMovingColumns[iNewReelInd].setReadyToStop();

                        this._aMovingColumns[iReelIndex].restart(new Array(this._aFinalSymbolCombo[0][iReelIndex],
                            this._aFinalSymbolCombo[1][iReelIndex],
                            this._aFinalSymbolCombo[2][iReelIndex]), true);

                    }else {
                        iNewReelInd -= CMain.NUM_REELS;
                        this._aMovingColumns[iNewReelInd].setReadyToStop();

                        this._aMovingColumns[iReelIndex].restart(new Array(this._aFinalSymbolCombo[0][iNewReelInd],
                            this._aFinalSymbolCombo[1][iNewReelInd],
                            this._aFinalSymbolCombo[2][iNewReelInd]), true);


                    }

                }
            }else {
                this._aMovingColumns[iReelIndex].restart(this._generateRandSymbols(),false);
            }

        }else {
            this._aMovingColumns[iReelIndex].restart(this._generateRandSymbols(), false);

            if(this._bReadyToStop && (iReelIndex === 0 || iReelIndex === CMain.NUM_REELS-1)){
                this._iCurReelLoops++;
            }

        }
    };
    public stopNextReel = () => {
        this._iNumReelsStopped++;

        if(this._iNumReelsStopped%2 === 0){
            console.log("1 HIDE ALL")
            for(var k=1;k<CMain.NUM_REELS;k++){
                this._aSuspanceReel[k].hide();
            }
            //CHECK IF THERE ARE FREESPINS OR BONUS SYMBOLS IN RELL
            for(var k=0;k<CMain.NUM_ROWS;k++){
                if(this._aFinalSymbolCombo[k][this._iNextColToStop] === CMain.BONUS_SYMBOL){
                    this._iCurNumBonusSymbolsInReels++;
                }
                if(this._aFinalSymbolCombo[k][this._iNextColToStop] === CMain.FREESPIN_SYMBOL){
                    this._iCurNumFreespinSymbolsInReels++;
                }
            }


            this._iNextColToStop = this._aReelSequence[this._iNumReelsStopped/2];
            if (this._iNumReelsStopped === (CMain.NUM_REELS*2) ) {
                this._endReelAnimation();
            }
        }



        if(this._iNextColToStop >1 && (this._iCurNumBonusSymbolsInReels === 2 || this._iCurNumFreespinSymbolsInReels === 2)){
            this._iCurReelLoops = 0;
            this._iCurMinLoops = CMain.SUSPANCE_REEL_LOOPS;
            console.log("SHOW "+this._iNextColToStop);
            this._aSuspanceReel[this._iNextColToStop].show();
        }else{
            this._iCurMinLoops = CMain.MIN_REEL_LOOPS;
        }
    };
    private _realEndReelAnimation = () => {
        console.log("2 HIDE ALL")
        for(var k=1;k<CMain.NUM_REELS;k++){
            this._aSuspanceReel[k].hide();
        }

        if(this._aBonusId.indexOf(CMain.BONUS_GAME) !== -1 || this._iTotFreeSpin>0){
            this.resetAutoSpin();
            this._oInterface.disableGuiButtons(this._bAutoSpin,this._iTotFreeSpin>0?true:false);
        }else{
            if(!this._bAutoSpin){
                this._oInterface.enableGuiButtons();
            }else{
                this._oInterface.enableSpin(true);
            }
        }
        this._oInterface.setSpinState(CMain.TEXT_SPIN);

        if(this._oLogo.currentAnimation !== "normal"){
            this._oInterface.refreshFreeSpinNum(this._iTotFreeSpin);
        }

        //INCREASE MONEY IF THERE ARE COMBOS
        if(this._aWinningLine.length > 0){
            if(this._oLogo.currentAnimation === "normal"){
                this._oAvatar.show("win");
                playSound("avatar_win",1,false);
            }

            //HIGHLIGHT WIN COMBOS IN PAYTABLE
            for(var i=0;i<this._aWinningLine.length;i++){
                if(this._aWinningLine[i].value<7){
                    this._oPayTable.highlightCombo(this._aWinningLine[i].value,this._aWinningLine[i].num_win);
                }
                if(this._aWinningLine[i].line > 0){
                    this._oInterface.showLine(this._aWinningLine[i].line);
                }

                var aList = this._aWinningLine[i].list;
                for(var k=0;k<aList.length;k++){
                    this._aStaticSymbols[aList[k].row][aList[k].col].showWinFrame();
                }
            }

            if(this._iTotWin>0){
                this._oInterface.refreshWinText(this._iTotWin);
            }


            CMain.TIME_SHOW_ALL_WINS = 2000;


            this._iTimeElaps = 0;
            this._iCurState = CMain.GAME_STATE_SHOW_ALL_WIN;

            this._oInterface.refreshMoney(this._iMoney);
        }else{
            if(this._iTotFreeSpin > 0){
                this._oInterface.disableSpin(this._iTotFreeSpin>0?false:true);
                this.onSpin();
            }else{
                if(this._oLogo.currentAnimation === "freespin"){
                    this._oFreespinResult.show(this._iFreeSpinWinAmount);
                    this._oLogo.gotoAndStop("normal");

                    this._oInterface.refreshFreeSpinNum("");
                    this._oInterface.refreshFreeSpinAmount(0);
                    createjs.Tween.get(this._oBgFreespin).to({alpha:0}, 2000, createjs.Ease.cubicOut);

                    setVolume("ambience_game",1);
                    stopSound("freespin_soundtrack");

                    this._oInterface.enableGuiButtons();
                }

                if(this._bAutoSpin){
                    if(this._iMoney < this._iTotBet && this._iTotFreeSpin === 0){

                        this._oInterface.enableGuiButtons();

                        this.resetAutoSpin();
                        this._oInterface.enableGuiButtons();
                        this._iCurState = CMain.GAME_STATE_IDLE;
                    }else{
                        this.onSpin();
                    }
                }else{
                    this._oInterface.enableGuiButtons();
                    this._iCurState = CMain.GAME_STATE_IDLE;
                }
            }
        }

        if(this._iMoney < this._iTotBet && this._iTotFreeSpin === 0){
            this._oInterface.enableGuiButtons();
            this.resetAutoSpin();
        }else{
            if(!this._bAutoSpin){
                if(this._oLogo.currentAnimation !== "freespin"){
                    if(this._iTotFreeSpin>0 || this._aBonusId.indexOf(CMain.BONUS_GAME) !== -1){
                        this._oInterface.enableSpin(false);
                    }else{
                        this._oInterface.enableGuiButtons();
                        this._oInterface.disableBetBut(false);
                    }
                }else if(this._aWinningLine.length>0){
                    this._oInterface.enableSpin(false);
                    this._oInterface.disableBetBut(true);
                }
            }
        }
        this._oInterface.refreshFreeSpinAmount(this._iFreeSpinWinAmount);
    };
    private refreshMoney = (iMoney: any) => {
        this._iMoney = iMoney;
        this._oInterface.refreshMoney(this._iMoney);

        saveItem(CMain.LOCALSTORAGE_STRING+"score",this._iMoney);
    };
    private _endReelAnimation = () => {
        this._bReadyToStop = false;

        this._iCurReelLoops = 0;
        this._iNumReelsStopped = 0;
        this._iCurWinShown = 0;
        this._iNextColToStop = this._aReelSequence[0];

        this._realEndReelAnimation();

    };
    public hidePayTable = () => {
        this._oPayTable.hide();
    };
    public showWin = () => {
        if(this._iCurState !== CMain.GAME_STATE_SHOW_WIN){
            return;
        }

        var iLineIndex;

        if(this._iCurWinShown>0 ){
            iLineIndex = this._aWinningLine[this._iCurWinShown-1].line;

            this._oInterface.hideLine(iLineIndex);

            var aList = this._aWinningLine[this._iCurWinShown-1].list;
            for(var k=0;k<aList.length;k++){
                this._aMovingColumns[aList[k].col].setVisible(aList[k].row,true);
                this._aMovingColumns[aList[k].col+CMain.NUM_REELS].setVisible(aList[k].row,true);
            }
        }

        if(this._iCurWinShown === this._aWinningLine.length){
            this._iCurWinShown = 0;

            if(this._oLogo.currentAnimation === "freespin" && this._iTotFreeSpin === 0){
                this._oFreespinResult.show(this._iFreeSpinWinAmount);
                this._oLogo.gotoAndStop("normal");

                this._oInterface.refreshFreeSpinNum("");
                this._oInterface.refreshFreeSpinAmount("");
                createjs.Tween.get(this._oBgFreespin).to({alpha:0}, 2000, createjs.Ease.cubicOut);
                this._bFreespinEnable = false;
                /*
                setVolume("ambience_game",1);
                stopSound("freespin_soundtrack");
                */
                this._oInterface.enableGuiButtons();
            }

            if(this._aBonusId.indexOf(CMain.BONUS_GAME) !== -1){

                this._hideAllWins();
                // $(CMain.s_oMain).trigger("bonus_call",{bet:CMain.COIN_BET[this._iCurCoinIndex]});
                //TODO trigger bonus_call
                console.log("TODO trigger: bonus_call", {bet:CMain.COIN_BET[this._iCurCoinIndex]});

            }else if(this._bActivateFreespin){

                this._bActivateFreespin = false;
                this._oFreespinPanel.show(this._iFreeSpinWin);
            }else if(this._iTotFreeSpin > 0){
                this._oInterface.disableSpin(this._iTotFreeSpin>0?false:true);
                this.onSpin();
            }else if(this._bAutoSpin){
                this.onSpin();
            }else{
                this._oInterface.enableGuiButtons();
                this._oInterface.disableBetBut(false);

                this._iCurState = CMain.GAME_STATE_IDLE;
                this._oInterface.enableGuiButtons();
            }

            return;
        }

        var iCol;
        var iRow;
        iLineIndex = this._aWinningLine[this._iCurWinShown].line;
        var aList = this._aWinningLine[this._iCurWinShown].list;

        if(iLineIndex === 0){
            var iNumSymbols = aList.length;
            var iIndex = Math.floor(iNumSymbols/2);
            iRow = aList[iIndex].row;
            iCol = aList[iIndex].col;
        }else{

            this._oInterface.showLine(iLineIndex);

            //DETECT WHICH REEL WE HAVE TO SHOW THE BIG ANIMATION
            iCol = 2;
            var bSkipCheck = false;
            if(aList.length < 3){
                if(this._aWinningLine[this._iCurWinShown].value === CMain.FREESPIN_SYMBOL){
                    iCol = aList[0].col;
                    iRow = aList[0].row;
                    bSkipCheck = true;
                }else{
                    iCol = aList.length - 1;
                    iRow = aList[iCol].row;
                }
            }else{
                iRow = aList[iCol].row;
            }

            //USUALLY WINNING ANIMS IS PLAYED IN THE THIRD REEL. IF IN THAT REEL THERE IS A WILD EXPANDED,
            //CHECK PREVIOUS REEL
            while (!bSkipCheck && (this._aFinalSymbolCombo[iRow][iCol] === CMain.WILD_SYMBOL ) ){
                iCol--;

                if(iCol<0){
                    iCol = 0;
                    iRow = aList[iCol].row;
                    break;
                }else{
                    iRow = aList[iCol].row;
                }
            }
        }

        //SET THE REGISTRATION POINT AND POSITION OF THE WINNING ANIMATION TO ALLOW A CORRECT SCALING
        var oPos = {x:0,y:0};
        var oRegPoint = {x:0,y:0};
        if(iRow === 0){
            if(iCol === 0){
                oRegPoint = {x:0,y:0};
            }else if(iCol === 4){
                oRegPoint = {x:CMain.TIME_SHOW_WIN,y:0};
                oPos = {x:CMain.SYMBOL_WIDTH,y:0};
            }else{
                oRegPoint = {x:CMain.TIME_SHOW_WIN/2  ,y:0};
                oPos = {x:CMain.SYMBOL_WIDTH/2 ,y:0};
            }
        }else if(iRow === 1){
            if(iCol === 0){
                oRegPoint = {x:0,y:CMain.WIN_BIG_ANIM_HEIGHT/2 };
                oPos = {x:0,y:CMain.SYMBOL_HEIGHT/2 };
            }else if(iCol === 4){
                oRegPoint = {x:CMain.TIME_SHOW_WIN,y:CMain.WIN_BIG_ANIM_HEIGHT/2 };
                oPos = {x:CMain.SYMBOL_WIDTH,y:CMain.SYMBOL_HEIGHT/2 };
            }else{
                oRegPoint = {x:CMain.TIME_SHOW_WIN/2 ,y:CMain.WIN_BIG_ANIM_HEIGHT/2 };
                oPos = {x:CMain.SYMBOL_WIDTH/2 ,y:CMain.SYMBOL_HEIGHT/2 };
            }
        }else{
            if(iCol === 0){
                oRegPoint = {x:0,y:CMain.WIN_BIG_ANIM_HEIGHT};
                oPos = {x:0,y:CMain.SYMBOL_HEIGHT};
            }else if(iCol === 4){
                oRegPoint = {x:CMain.TIME_SHOW_WIN ,y:CMain.WIN_BIG_ANIM_HEIGHT};
                oPos = {x:CMain.SYMBOL_WIDTH,y:CMain.SYMBOL_HEIGHT};
            }else{
                oRegPoint = {x:CMain.TIME_SHOW_WIN/2 ,y:CMain.WIN_BIG_ANIM_HEIGHT};
                oPos = {x:CMain.SYMBOL_WIDTH/2 ,y:CMain.SYMBOL_HEIGHT};
            }
        }


        this._aStaticSymbols[iRow][iCol].show(this._aFinalSymbolCombo[iRow][iCol]+1,this._aWinningLine[this._iCurWinShown].amount,oPos,oRegPoint,(this._bAutoSpin || this._bActivateFreespin === false && this._iTotFreeSpin >0)?1:3);

        this._iCurWinShown++;
    };
    private _hideAllWins = () => {

        for(var i=0;i<CMain.NUM_ROWS;i++){
            for(var j=0;j<CMain.NUM_REELS;j++){
                this._aStaticSymbols[i][j].hideWinFrame();
            }
        }

        this._oInterface.hideAllLines();
    };
    private _prepareForWinsShowing = () => {
        this._iTimeElaps = CMain.TIME_SHOW_WIN;
        this._iCurState = CMain.GAME_STATE_SHOW_WIN;
        this.showWin();
    };
    public activateLines = (iLine: any) => {
        this._iLastLineActive = iLine;
        this.removeWinShowing();

        var iNewTotalBet = this._iCurBet * this._iLastLineActive;

        this._iTotBet = iNewTotalBet;
        this._oInterface.refreshTotalBet(this._iTotBet);
        this._oInterface.refreshNumLines(this._iLastLineActive);

        if(iNewTotalBet>this._iMoney){
            this._oInterface.disableSpin(this._iTotFreeSpin>0?false:true);
        }else{
            this._oInterface.enableSpin(this._iTotFreeSpin>0?false:true);
        }
    };
    public addLine = () => {
        if(this._iLastLineActive === CMain.NUM_PAYLINES){
            this._iLastLineActive = 1;
        }else{
            this._iLastLineActive++;
        }

        var iNewTotalBet = this._iCurBet * this._iLastLineActive;

        this._iTotBet = iNewTotalBet;
        this._oInterface.refreshTotalBet(this._iTotBet);
        this._oInterface.refreshNumLines(this._iLastLineActive);


        this._oInterface.enableSpin(this._iTotFreeSpin>0?false:true);
    };
    private resetCoinBet = () => {
        this._iCurCoinIndex = 0;

        var iNewBet = CMain.COIN_BET[this._iCurCoinIndex];

        var iNewTotalBet = iNewBet * this._iLastLineActive;

        this._iCurBet = iNewBet;
        this._iTotBet = iNewTotalBet;
        this._oInterface.refreshBet(this._iCurBet);
        this._oInterface.refreshTotalBet(this._iTotBet);


        this._oInterface.enableSpin(this._iTotFreeSpin>0?false:true);
    };
    public changeCoinBet = () => {
        this._iCurCoinIndex++;
        if(this._iCurCoinIndex === CMain.COIN_BET.length){
            this._iCurCoinIndex = 0;
        }
        var iNewBet = parseFloat(CMain.COIN_BET[this._iCurCoinIndex]);

        var iNewTotalBet = iNewBet * this._iLastLineActive;

        this._iCurBet = iNewBet;
        this._iCurBet = Math.floor(this._iCurBet * 100)/100;
        this._iTotBet = iNewTotalBet;
        this._oInterface.refreshBet(this._iCurBet);
        this._oInterface.refreshTotalBet(this._iTotBet);


        this._oInterface.enableSpin(this._iTotFreeSpin>0?false:true);
    };
    private removeWinShowing = () => {
        this._oPayTable.resetHighlightCombo();

        this._oInterface.resetWin();

        for(var i=0;i<CMain.NUM_ROWS;i++){
            for(var j=0;j<CMain.NUM_REELS;j++){
                this._aStaticSymbols[i][j].hide();
                this._aMovingColumns[j].setVisible(i,true);
                this._aMovingColumns[j+CMain.NUM_REELS].setVisible(i,true);
            }
        }

        for(var k=0;k<this._aMovingColumns.length;k++){
            this._aMovingColumns[k].activate();
        }

        this._iCurState = CMain.GAME_STATE_IDLE;
    };
    //THIS FUNCTION IS CALLED WHEN STOP BUTTON IS CLICKED DURING A SPIN
    public forceStopReel = () => {

        if(this._iTotFreeSpin === 0){
            this.resetAutoSpin();
        }


        this._iCurState = CMain.GAME_STATE_IDLE;
        for(var i=0;i<CMain.NUM_REELS;i++){
            var iNewY = CMain.REEL_OFFSET_Y+( ( CMain.SYMBOL_HEIGHT + CMain.SPACE_HEIGHT_BETWEEN_SYMBOLS)*CMain.NUM_ROWS);
            this._aMovingColumns[i].forceStop(new Array( this._aFinalSymbolCombo[0][i],this._aFinalSymbolCombo[1][i],this._aFinalSymbolCombo[2][i]),CMain.START_REEL_OFFSET_Y-27);
            this._aMovingColumns[i+CMain.NUM_REELS].forceStop(null,iNewY);

        }

        this._endReelAnimation();
    };
    public onSpin = () => {
        this._iCurMinLoops = CMain.MIN_REEL_LOOPS;
        this._iCurNumBonusSymbolsInReels = 0;
        this._iCurNumFreespinSymbolsInReels = 0;

        if( ( (this._iTotFreeSpin > 0 && this._oLogo.currentAnimation !== "freespin") || this._aBonusId.indexOf(CMain.BONUS_GAME) !== -1
            || (this._iTotFreeSpin === 0 && this._oLogo.currentAnimation === "freespin"))
            && (this._iCurState === CMain.GAME_STATE_SHOW_ALL_WIN  || this._iCurState === CMain.GAME_STATE_SHOW_WIN) ){

            this._hideAllWins();

            this.removeWinShowing();

            this._iCurWinShown = this._aWinningLine.length;
            this._iCurState = CMain.GAME_STATE_SHOW_WIN;
            this.showWin();
            return;
        }else if(this._aBonusId.indexOf(CMain.BONUS_FREESPIN) !== -1 && (this._iCurState === CMain.GAME_STATE_SHOW_ALL_WIN  || this._iCurState === CMain.GAME_STATE_SHOW_WIN)){
            this._hideAllWins();
            this._oInterface.disableSpin(true);
            this.removeWinShowing();
            this._bActivateFreespin = false;
            this._oFreespinPanel.show(this._iFreeSpinWin);
            return;
        }

        if(this._iMoney < this._iTotBet && this._iTotFreeSpin === 0){
            this.resetAutoSpin();
            var oRechargePanel = new CRechargePanel();
            return;
        }

        this._bReadyToStop = false;
        playSound("spin_but",1,false);

        this._oInterface.disableBetBut(true);

        this.removeWinShowing();

        if(this._oLogo.currentAnimation === "freespin"){
            this._iTotBet = 0;
        }else{
            this._iTotBet = this._iCurBet * this._iLastLineActive;
        }


        this._aBonusId = [];
        this._hideAllWins();
        this._oInterface.disableGuiButtons(this._bAutoSpin,this._iTotFreeSpin>0?true:false);


        this._iMoney -= this._iTotBet;
        this._oInterface.refreshMoney(this._iMoney);

        // $(CMain.s_oMain).trigger("bet_placed",{bet:CMain.COIN_BET[this._iCurCoinIndex],tot_bet:this._iTotBet,payline:this._iLastLineActive});
        console.log("TODO: bet_placed",{bet:CMain.COIN_BET[this._iCurCoinIndex],tot_bet:this._iTotBet,payline:this._iLastLineActive});

        this._iCurState = CMain.GAME_STATE_SPINNING;

    };
    private onSpinReceived = (oData: any) => {
        this._iNumAds++;
        if(this._iNumAds === CMain.NUM_SPIN_FOR_ADS){
            this._iNumAds = 0;
            // $(CMain.s_oMain).trigger("show_interlevel_ad"); //TODO trigger
            console.log("TODO: Trigger show_interlevel_ad")
        }

        if ( oData.res === true ){
            //console.log(oData)
            this._aFinalSymbolCombo = oData.pattern;
            this._aWinningLine = oData.win_lines;
            var fWinAmount = parseFloat(oData.tot_win);
            var bBonusWin = oData.bonus;
            this._iFreeSpinWin = parseInt(oData.num_freespin);

            this._iMoney = parseFloat(oData.money);

            if( this._oLogo.currentAnimation !== "normal" && this._bActivateFreespin === false){
                this._iFreeSpinWinAmount += fWinAmount;
            }
            this._iTotFreeSpin = this._iFreeSpinWin;
            if(fWinAmount > 0 || bBonusWin === true || this._iTotFreeSpin > 0){
                this._bActivateFreespin = false;

                if( oData.freespin ){
                    this._aBonusId.push(CMain.BONUS_FREESPIN);
                    this._bActivateFreespin = true;
                    this._iFreeSpinWinAmount = 0;
                }

                if( bBonusWin ){
                    this._aBonusId.push(CMain.BONUS_GAME);
                }
                //GET TOTAL WIN FOR THIS SPIN
                this._iTotWin = fWinAmount;

            }else{
                this._aWinningLine = new Array();

            }

            this._bReadyToStop = true;
            // $(CMain.s_oMain).trigger("save_score",this._iMoney); // TODO TRIGGER: save_score
            console.log("TODO: Trigger save_score")

            saveItem(CMain.LOCALSTORAGE_STRING+"score",this._iMoney);
        }else{
            this._generateLosingPattern();
        }

    };
    private onBonusStart = (oData: any) => {
        // trace(oData)
        console.log("TODO: trace(-) ", oData)
        this._iMoney    = parseFloat(oData.money);
        this._fBonusWin = parseFloat(oData.bonus_win);

        this._oBonusPanel.show(JSON.parse(oData.prize_list),this._iCurBet,oData.final_prize);

        this._iCurState = CMain.GAME_STATE_BONUS;

        // $(CMain.s_oMain).trigger("save_score",this._iMoney);
        console.log("TODO: save_score ", this._iMoney)

        saveItem(CMain.LOCALSTORAGE_STRING+"score",this._iMoney);
    };
    //AUTOSPIN BUTTON CLICKED
    private onAutoSpin = (bAutoSpin: any) => {
        this._bAutoSpin = bAutoSpin;

        if(bAutoSpin && this._iCurState === CMain.GAME_STATE_IDLE){
            this.onSpin();
        }
    };
    private onStopAutoSpin = () => {
        this.resetAutoSpin();

        if(this._iCurState !== CMain.GAME_STATE_SPINNING && this._iCurState !== CMain.GAME_STATE_BONUS){
            this._oInterface.enableGuiButtons();
        }
    };
    private resetAutoSpin = () => {
        this._bAutoSpin = false;
        this._oInterface.setAutoSpinState(CMain.TEXT_AUTO_SPIN);
    };
    private _generateLosingPattern = () => {
        var aFirstCol = new Array();
        console.log("ASYNC WHEN NEEDED IS ", CSlotSettings.s_aRandSymbols)
        for(var i=0;i<CMain.NUM_ROWS;i++){
            var iRandIndex = Math.floor(Math.random()* (CSlotSettings.s_aRandSymbols.length-2));
            var iRandSymbol = CSlotSettings.s_aRandSymbols[iRandIndex];
            aFirstCol[i] = iRandSymbol;
        }

        this._aFinalSymbolCombo = new Array();
        for(var i=0;i<CMain.NUM_ROWS;i++){
            this._aFinalSymbolCombo[i] = new Array();
            for(var j=0;j<CMain.NUM_REELS;j++){

                if(j === 0){
                    this._aFinalSymbolCombo[i][j] = aFirstCol[i];
                }else{
                    do{
                        var iRandIndex = Math.floor(Math.random()* (CSlotSettings.s_aRandSymbols.length-2));
                        var iRandSymbol = CSlotSettings.s_aRandSymbols[iRandIndex];
                    }while(aFirstCol[0] === iRandSymbol || aFirstCol[1] === iRandSymbol || aFirstCol[2] === iRandSymbol);
                    this._aFinalSymbolCombo[i][j] = iRandSymbol;
                }
            }
        }

        this._aWinningLine = new Array();
        this._bReadyToStop = true;

    };
    public onInfoClicked = () => {
        if(this._iCurState === CMain.GAME_STATE_SPINNING){
            return;
        }

        if(this._oPayTable.isVisible()){
            this._oPayTable.hide();
        }else{
            this._oPayTable.show();
        }
    };
    public exitFromFreespinPanel = () => {

        this._bFreespinEnable = true;
        this._oInterface.refreshFreeSpinNum(this._iTotFreeSpin);
        this._oInterface.refreshFreeSpinAmount(0);
        this._oLogo.gotoAndPlay("freespin");

        createjs.Tween.get(this._oBgFreespin).to({alpha:1}, 2000, createjs.Ease.cubicOut);

        this._oInterface.disableSpin(this._iTotFreeSpin>0?false:true);
        this._iCurState = CMain.GAME_STATE_IDLE;
        this.onSpin();
    };
    public exitFromBonus = (iTotBonusWin: any) => {
        this._oInterface.refreshMoney(this._iMoney);
        this._oInterface.refreshWinText(iTotBonusWin);

        if(this._bActivateFreespin){
            this._bActivateFreespin = false;
            this._oFreespinPanel.show(this._iFreeSpinWin);
        }else if(this._bAutoSpin){
            this.onSpin();
        }else{
            this._oInterface.enableGuiButtons();
            this._oInterface.disableBetBut(false);
            this._oInterface.enableSpin(this._iTotFreeSpin>0?false:true);

            this._oInterface.enableGuiButtons();
        }

        this._iCurState = CMain.GAME_STATE_IDLE;

    };
    public onExit = () => {
        // $(CMain.s_oMain).trigger("start_session"); // TODO TRIGGER: start_session
        console.log("TODO: Trigger start_sessionn")

        this.unload();
        CMain.s_oMain.gotoMenu();
    };
    private getState = () => {
        return this._iCurState;
    };
    public update = () => {
        if(this._bUpdate === false){
            return;
        }

        switch(this._iCurState){
            case CMain.GAME_STATE_SPINNING:{
                for(var i=0;i<this._aMovingColumns.length;i++){
                    this._aMovingColumns[i].update();
                }
                break;
            }
            case CMain.GAME_STATE_SHOW_ALL_WIN:{

                this._iTimeElaps += CMain.s_iTimeElaps;
                if(this._iTimeElaps> CMain.TIME_SHOW_ALL_WINS){
                    this._iTimeElaps = 0;
                    this._hideAllWins();

                    if(this._bAutoSpin){
                        this._iCurWinShown = this._aWinningLine.length;
                    }else{
                        this._iCurWinShown = 0;
                    }
                    this._prepareForWinsShowing();
                }
                break;
            }
            case CMain.GAME_STATE_SHOW_WIN:{

                break;
            }

        }

    };
}