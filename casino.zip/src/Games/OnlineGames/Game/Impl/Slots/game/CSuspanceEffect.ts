import {createSprite, playSound, stopSound} from "./ctl_utils";
import {CMain} from "./CMain";

export class CSuspanceEffect {

    private _oSpriteSuspance: any;
    private _oContainer: any;
    private _oParentContainer: any;

    private _init = (iX: any, iY: any) => {
        this._oContainer = new createjs.Container();
        this._oContainer.visible = false;
        this._oContainer.x = iX - 92;
        this._oContainer.y = iY - 34;
        this._oParentContainer.addChild(this._oContainer);

        var aSprites = new Array();
        for (var k = 0; k < 191; k++) {
            aSprites.push(CMain.s_oSpriteLibrary!!.getSprite("suspance_" + k));
        }

        var oData = {   // image to use
            images: aSprites,
            framerate: 60,
            // width, height & registration point of each sprite
            frames: {width: 426, height: 754},
            animations: {start: 0, start_anim: [0, 61, "anim"], anim: [62, 126], end: [127, 190, "stop"], stop: 191}
        };

        var oSpriteSheet = new createjs.SpriteSheet(oData);
        this._oSpriteSuspance = createSprite(oSpriteSheet, "start", 0, 0, 426, 754);
        this._oSpriteSuspance.on("animationend", this._onAnimEnd, this);
        this._oContainer.addChild(this._oSpriteSuspance);

    };
    private show = () => {
        if (this._oContainer.visible) {
            return;
        }
        this._oContainer.visible = true;
        this._oContainer.alpha = 0;

        this._oSpriteSuspance.gotoAndPlay("start_anim");


        createjs.Tween.get(this._oContainer).to({alpha: 1}, 500, createjs.Ease.cubicOut);

        playSound("suspance", 1, true);
    };
    private hide = () => {
        this._oSpriteSuspance.gotoAndPlay("end");

        stopSound("suspance");
    };
    private _onAnimEnd = (evt: any) => {
        if (evt.name === "end") {
            this._oContainer.visible = false;
            this._oSpriteSuspance.gotoAndStop("start");
        }
    };

    constructor(
        iX: any,
        iY: any,
        oParentContainer: any
    ) {
        this._oParentContainer = oParentContainer;
        this._init(iX, iY);
    }
}