import {CMain} from "./CMain";
import { CTLText } from "./CTLText";
import {createBitmap, sizeHandler, formatEntries} from "./ctl_utils";
import {CGfxButton} from "./CGfxButton";
import {CBetBut} from "./CBetBut";
import {CGame} from "./CGame";
import {CAreYouSurePanel} from "./CAreYouSurePanel";
import {CToggle} from "./CToggle";
import {CSpriteSheetTextButton} from "./CSpriteSheetTextButton";

export const screenfull_IsEnabled = false;
export class CInterface {
    
    public static s_oInterface: CInterface | null;
    private _bShowingLine: any;
    private _aLinesBut: any;
    private _aPayline: any;
    private _oSpinBut: any;
    private _oInfoBut: any;
    private _oAddLineBut: any;
    private _oBetCoinBut: any;
    private _oAutoSpinBut: any;
    private _oButExit: any;

    private _pStartPosSpin: any;
    private _pStartPosAutoSpin: any;
    private _pStartPosCoin: any;
    private _pStartPosLines: any;
    private _pStartPosInfo: any;
    private _pStartPosMoney: any;
    private _pStartPosFreespinText: any;
    private _pStartPosWinFreespinText: any;

    private _oContainerFreespin: any;
    private _oContainerWinFreespin: any;
    private _oMoneyText: any;
    private _oTotalBetText: any;
    private _oWinText: any;
    private _oFreeSpinNumText: any;
    private _oFreeSpinWinText: any;
    private _oAudioToggle: any;
    private _oButFullscreen: any;

    private _oAreYouSurePanel: any;

    private _pStartPosAudio: any;
    private _pStartPosFullscreen: any;
    private _pStartPosExit: any;

    private _fRequestFullScreen: any = null;
    private _fCancelFullScreen: any = null;

    constructor(
        iCurBet: any,
        iTotBet: any,
        oContainerSlot: any
    ) {
        CInterface.s_oInterface = this;
        this._init(iCurBet,iTotBet,oContainerSlot);
    }

    private _init = (iCurBet: any,iTotBet: any,oContainerSlot: any) => {
        console.log('interface init called!')
        this._initPaylines(oContainerSlot);

        var oSprite = CMain.s_oSpriteLibrary!!.getSprite('but_text');
        this._pStartPosInfo = {x:272,y:CMain.CANVAS_HEIGHT - oSprite.height/2 - 170};
        this._oInfoBut = new CSpriteSheetTextButton(this._pStartPosInfo.x,this._pStartPosInfo.y,oSprite,CMain.TEXT_PAYTABLE,CMain.FONT_GAME_1,"#8d4402",34,oContainerSlot);
        this._oInfoBut.addEventListener(CMain.ON_MOUSE_UP, this._onInfo, this);

        // this._pStartPosCoin = {x:520,y:CMain.CANVAS_HEIGHT - oSprite.height/2 - 170};
        // this._oBetCoinBut = new CSpriteSheetTextButton(this._pStartPosCoin.x, this._pStartPosCoin.y,oSprite,TEXT_COIN +" " + formatEntries(iCurBet),CMain.FONT_GAME_1,"#8d4402",34,oContainerSlot);
        // this._oBetCoinBut.addEventListener(CMain.ON_MOUSE_UP, this._onBet, this);

        this._pStartPosLines = {x:758,y:CMain.CANVAS_HEIGHT - oSprite.height/2 - 170};
        this._oAddLineBut = new CSpriteSheetTextButton(this._pStartPosLines.x,this._pStartPosLines.y,oSprite,CMain.TEXT_LINES + " " + CMain.NUM_PAYLINES,CMain.FONT_GAME_1,"#8d4402",34,oContainerSlot);
        this._oAddLineBut.addEventListener(CMain.ON_MOUSE_UP, this._onAddLine, this);

        // this._pStartPosAutoSpin = {x:996 ,y:CMain.CANVAS_HEIGHT - oSprite.height/2 - 170};
        // this._oAutoSpinBut = new CSpriteSheetTextButton(this._pStartPosAutoSpin.x,this._pStartPosAutoSpin.y,oSprite,TEXT_AUTO_SPIN,CMain.FONT_GAME_1,"#8d4402",34,oContainerSlot);
        // this._oAutoSpinBut.addEventListener(CMain.ON_MOUSE_UP, this._onAutoSpin, this);

        this._pStartPosSpin = {x:1234,y:CMain.CANVAS_HEIGHT - oSprite.height/2 -170};
        this._oSpinBut = new CSpriteSheetTextButton(this._pStartPosSpin.x,this._pStartPosSpin.y,oSprite,CMain.TEXT_SPIN,CMain.FONT_GAME_1,"#8d4402",34,oContainerSlot);
        this._oSpinBut.addEventListener(CMain.ON_MOUSE_UP, this._onSpin, this);


        this._pStartPosMoney = {x:148,y:CMain.CANVAS_HEIGHT - 290};
        // @ts-ignore
        this._oMoneyText = new CTLText(oContainerSlot,
            this._pStartPosMoney.x, this._pStartPosMoney.y, 278, 30,
            30, "left", "#fede00", CMain.FONT_GAME_1, 1,
            0, 0,
            CMain.TEXT_MONEY +": " + formatEntries(CMain.TOTAL_MONEY)+CMain.TEXT_CURRENCY,
            true, true, false,
            false );


        this._oTotalBetText = new CTLText(oContainerSlot,
            776, this._pStartPosMoney.y, 278, 30,
            30, "left", "#fede00", CMain.FONT_GAME_1, 1,
            0, 0,
            CMain.TEXT_BET +": "+formatEntries(iTotBet)+CMain.TEXT_CURRENCY,
            true, true, false,
            false );

        this._oWinText = new CTLText(oContainerSlot,
            1086, this._pStartPosMoney.y, 278, 30,
            30, "left", "#fede00", CMain.FONT_GAME_1, 1,
            0, 0,
            CMain.TEXT_WIN + ": 0.00"+CMain.TEXT_CURRENCY,
            true, true, false,
            false );

        var oSpriteFreespinBg = CMain.s_oSpriteLibrary!!.getSprite("amount_freespins");

        this._pStartPosFreespinText = {x:300,y:5};
        this._oContainerFreespin = new createjs.Container();
        this._oContainerFreespin.visible = false;
        this._oContainerFreespin.x = this._pStartPosFreespinText.x;
        this._oContainerFreespin.y = this._pStartPosFreespinText.y;
        this._oContainerFreespin.regX = oSpriteFreespinBg.width/2;
        this._oContainerFreespin.regY = oSpriteFreespinBg.height/2;
        oContainerSlot.addChild(this._oContainerFreespin);

        var oBg = createBitmap(oSpriteFreespinBg);
        this._oContainerFreespin.addChild(oBg);

        this._oFreeSpinNumText = new CTLText(this._oContainerFreespin,
            20, oSpriteFreespinBg.height/2, oSpriteFreespinBg.width-40, oSpriteFreespinBg.height/2-10,
            48, "center", "#fce0ab", CMain.FONT_GAME_1, 1,
            0, 0,
            "0",
            true, true, false,
            false );


        var oSpriteFreespinWinBg = CMain.s_oSpriteLibrary!!.getSprite("amount_freespin_win");
        this._pStartPosWinFreespinText = {x:1200,y:5};
        this._oContainerWinFreespin = new createjs.Container();
        this._oContainerWinFreespin.visible = false;
        this._oContainerWinFreespin.x = this._pStartPosWinFreespinText.x;
        this._oContainerWinFreespin.y = this._pStartPosWinFreespinText.y;
        this._oContainerWinFreespin.regX = oSpriteFreespinWinBg.width/2;
        this._oContainerWinFreespin.regY = oSpriteFreespinWinBg.height/2;
        oContainerSlot.addChild(this._oContainerWinFreespin);


        var oBg = createBitmap(oSpriteFreespinWinBg);
        this._oContainerWinFreespin.addChild(oBg);


        this._oFreeSpinWinText = new CTLText(this._oContainerWinFreespin,
            20, oSpriteFreespinWinBg.height/2, oSpriteFreespinWinBg.width-40, oSpriteFreespinWinBg.height/2-10,
            48, "center", "#fce0ab", CMain.FONT_GAME_1, 1,
            0, 0,
            "0",
            true, true, false,
            false );

        var oSpriteExit = CMain.s_oSpriteLibrary!!.getSprite("but_exit");
        this._pStartPosExit = {x: CMain.CANVAS_WIDTH - (oSpriteExit.width/2) - 4, y: (oSpriteExit.height/2)+ 4};
        this._oButExit = new CGfxButton(this._pStartPosExit.x,this._pStartPosExit.y,"",CMain.s_oAttachSection);
        this._oButExit.addEventListener(CMain.ON_MOUSE_UP,this._onExit,this);

        if(CMain.DISABLE_SOUND_MOBILE === false || CMain.s_bMobile === false){
            var oSprite = CMain.s_oSpriteLibrary!!.getSprite('audio_icon');
            this._pStartPosAudio = {x:oSprite.width/4+4,y:this._pStartPosExit.y};

            this._oAudioToggle = new CToggle(this._pStartPosAudio.x,this._pStartPosAudio.y,'',CMain.s_bAudioActive,CMain.s_oAttachSection);
            this._oAudioToggle.addEventListener(CMain.ON_MOUSE_UP, this._onAudioToggle, this);

            this._pStartPosFullscreen = {x: this._pStartPosAudio.x + oSprite.width/2 + 4,y:this._pStartPosAudio.y};
        }else{
            this._pStartPosFullscreen = {x:oSprite.width/2+4,y:this._pStartPosExit.y};
        }

        var doc = window.document;
        var docEl = doc.documentElement;
        this._fRequestFullScreen = docEl.requestFullscreen/* || docEl.mozRequestFullScreen || docEl.webkitRequestFullScreen || docEl.msRequestFullscreen*/; //TODO Fullscreen
        this._fCancelFullScreen = doc.exitFullscreen/* || doc.mozCancelFullScreen || doc.webkitExitFullscreen || doc.msExitFullscreen*/;

        if(CMain.ENABLE_FULLSCREEN === false){
            this._fRequestFullScreen = false;
        }

        if (this._fRequestFullScreen && screenfull_IsEnabled){
            oSprite = CMain.s_oSpriteLibrary!!.getSprite('but_fullscreen');
            this._oButFullscreen = new CToggle(this._pStartPosFullscreen.x,this._pStartPosFullscreen.y,'',CMain.s_bFullscreen,CMain.s_oAttachSection);
            this._oButFullscreen.addEventListener(CMain.ON_MOUSE_UP, this._onFullscreenRelease, this);
        }

        this._oAreYouSurePanel = new CAreYouSurePanel();
        this._oAreYouSurePanel.addEventListener(CMain.ON_BUT_YES_DOWN,this._onExitYes,this);

        if(!CMain.s_bMobile){
            document.onkeyup   = this.onKeyUp;
        }

        this.refreshButtonPos();
    };
    private onKeyUp = (evt: any) => {
        if(!evt){
            evt = window.event;
        }

        if(evt.keyCode === 13){
            CInterface.s_oInterface?._onSpin();
        }

        evt.preventDefault();
        return false;
    };
    private refreshButtonPos = () => {
        if( (this._pStartPosSpin.x - CGame.s_iOffsetX )> CMain.CANVAS_WIDTH - 210){
            this._oSpinBut.setPosition(this._pStartPosSpin.x - CGame.s_iOffsetX,this._pStartPosSpin.y - CGame.s_iOffsetY);
        }

        if(CMain.DISABLE_SOUND_MOBILE === false || CMain.s_bMobile === false){
            this._oAudioToggle.setPosition(this._pStartPosAudio.x + CGame.s_iOffsetX,CGame.s_iOffsetY + this._pStartPosAudio.y);
        }
        if (this._fRequestFullScreen && screenfull_IsEnabled){
            this._oButFullscreen.setPosition(this._pStartPosFullscreen.x + CGame.s_iOffsetX,this._pStartPosFullscreen.y + CGame.s_iOffsetY);
        }

        this._oButExit.setPosition(this._pStartPosExit.x-CGame.s_iOffsetX,this._pStartPosExit.y + CGame.s_iOffsetY);
    };
    private unload = () => {
        this._oSpinBut.unload();
        this._oSpinBut = null;
        this._oInfoBut.unload();
        this._oInfoBut = null;
        this._oAddLineBut.unload();
        this._oAddLineBut = null;
        // this._oBetCoinBut.unload();
        // this._oBetCoinBut = null;
        // this._oAutoSpinBut.unload();
        // this._oAutoSpinBut = null;
        this._oButExit.unload();
        this._oAreYouSurePanel.unload();


        if(CMain.DISABLE_SOUND_MOBILE === false || CMain.s_bMobile === false){
            this._oAudioToggle.unload();
            this._oAudioToggle = null;
        }

        if (this._fRequestFullScreen && screenfull_IsEnabled){
            this._oButFullscreen.unload();
        }

        for(var i=0;i<CMain.NUM_PAYLINES;i++){
            this._aLinesBut[i].unload();
        }

        CInterface.s_oInterface = null;
    };
    private _initPaylines = (oContainerSlot: any) => {
        var oSprite = CMain.s_oSpriteLibrary!!.getSprite('bet_but');
        this._aLinesBut = new Array();

        var iPadding = -14;
        var iSpriteHeight = 82;
        var iHalfButHeight = iSpriteHeight/2;
        var iYOffset = iHalfButHeight+50;


        //LINE 4
        var oBut = new CBetBut(-oSprite.width/4 + 70, iYOffset,'bet_but4',oContainerSlot);
        oBut.addEventListenerWithParams(CMain.ON_MOUSE_UP, this._onBetLineClicked, this,4);
        this._aLinesBut[3] = oBut;

        iYOffset+= iSpriteHeight + iPadding;

        //LINE 2
        oBut = new CBetBut( -oSprite.width/4 + 70, iYOffset,'bet_but2',oContainerSlot);
        oBut.addEventListenerWithParams(CMain.ON_MOUSE_UP, this._onBetLineClicked, this,2);
        this._aLinesBut[1] = oBut;

        iYOffset+= iSpriteHeight + iPadding;

        //LINE 20
        oBut = new CBetBut( -oSprite.width/4 + 70, iYOffset,'bet_but20',oContainerSlot);
        oBut.addEventListenerWithParams(CMain.ON_MOUSE_UP, this._onBetLineClicked, this,20);
        this._aLinesBut[19] = oBut;

        iYOffset+= iSpriteHeight + iPadding;

        //LINE 16
        oBut = new CBetBut( -oSprite.width/4 + 70, iYOffset,'bet_but16',oContainerSlot);
        oBut.addEventListenerWithParams(CMain.ON_MOUSE_UP, this._onBetLineClicked, this,16);
        this._aLinesBut[15] = oBut;

        iYOffset+= iSpriteHeight + iPadding;

        //LINE 10
        oBut = new CBetBut( -oSprite.width/4 + 70, iYOffset,'bet_but10',oContainerSlot);
        oBut.addEventListenerWithParams(CMain.ON_MOUSE_UP, this._onBetLineClicked, this,10);
        this._aLinesBut[9] = oBut;

        iYOffset+= iSpriteHeight + iPadding;

        //LINE 1
        oBut = new CBetBut( -oSprite.width/4 + 70, iYOffset,'bet_but1',oContainerSlot);
        oBut.addEventListenerWithParams(CMain.ON_MOUSE_UP, this._onBetLineClicked, this,1);
        this._aLinesBut[0] = oBut;

        iYOffset+= iSpriteHeight + iPadding +1;

        //LINE 11
        oBut = new CBetBut( -oSprite.width/4 + 70, iYOffset,'bet_but11',oContainerSlot);
        oBut.addEventListenerWithParams(CMain.ON_MOUSE_UP, this._onBetLineClicked, this,11);
        this._aLinesBut[10] = oBut;

        iYOffset+= iSpriteHeight + iPadding ;


        //LINE 17
        oBut = new CBetBut( -oSprite.width/4 + 70, iYOffset,'bet_but17',oContainerSlot);
        oBut.addEventListenerWithParams(CMain.ON_MOUSE_UP, this._onBetLineClicked, this,17);
        this._aLinesBut[16] = oBut;

        iYOffset+= iSpriteHeight + iPadding;


        //LINE 3
        oBut = new CBetBut( -oSprite.width/4 + 70, iYOffset,'bet_but3',oContainerSlot);
        oBut.addEventListenerWithParams(CMain.ON_MOUSE_UP, this._onBetLineClicked, this,3);
        this._aLinesBut[2] = oBut;

        iYOffset+= iSpriteHeight + iPadding;

        //LINE 5
        oBut = new CBetBut( -oSprite.width/4 + 70, iYOffset,'bet_but5',oContainerSlot);
        oBut.addEventListenerWithParams(CMain.ON_MOUSE_UP, this._onBetLineClicked, this,5);
        this._aLinesBut[4] = oBut;

        iYOffset = iHalfButHeight+50;


        //RIGHT COLUMN
        //LINE 14
        var oBut = new CBetBut(  1434 -oSprite.width/4, iYOffset,'bet_but14',oContainerSlot);
        oBut.addEventListenerWithParams(CMain.ON_MOUSE_UP, this._onBetLineClicked, this,14);
        this._aLinesBut[13] = oBut;

        iYOffset+= iSpriteHeight + iPadding;

        //LINE 12
        oBut = new CBetBut( 1434 -oSprite.width/4, iYOffset,'bet_but12',oContainerSlot);
        oBut.addEventListenerWithParams(CMain.ON_MOUSE_UP, this._onBetLineClicked, this,12);
        this._aLinesBut[11] = oBut;

        iYOffset+= iSpriteHeight + iPadding;

        //LINE 9
        oBut = new CBetBut( 1434 -oSprite.width/4, iYOffset,'bet_but9',oContainerSlot);
        oBut.addEventListenerWithParams(CMain.ON_MOUSE_UP, this._onBetLineClicked, this,9);
        this._aLinesBut[8] = oBut;

        iYOffset+= iSpriteHeight + iPadding;

        //LINE 18
        oBut = new CBetBut( 1434 -oSprite.width/4, iYOffset,'bet_but18',oContainerSlot);
        oBut.addEventListenerWithParams(CMain.ON_MOUSE_UP, this._onBetLineClicked, this,18);
        this._aLinesBut[17] = oBut;

        iYOffset+= iSpriteHeight + iPadding;

        //LINE 6;
        oBut = new CBetBut( 1434 -oSprite.width/4, iYOffset,'bet_but6',oContainerSlot);
        oBut.addEventListenerWithParams(CMain.ON_MOUSE_UP, this._onBetLineClicked, this,6);
        this._aLinesBut[5] = oBut;

        iYOffset+= iSpriteHeight + iPadding+1;

        //LINE 7;
        oBut = new CBetBut( 1434 -oSprite.width/4, iYOffset,'bet_but7',oContainerSlot);
        oBut.addEventListenerWithParams(CMain.ON_MOUSE_UP, this._onBetLineClicked, this,7);
        this._aLinesBut[6] = oBut;

        iYOffset+= iSpriteHeight + iPadding;

        //LINE 19;
        oBut = new CBetBut( 1434 -oSprite.width/4, iYOffset,'bet_but19',oContainerSlot);
        oBut.addEventListenerWithParams(CMain.ON_MOUSE_UP, this._onBetLineClicked, this,19);
        this._aLinesBut[18] = oBut;

        iYOffset+= iSpriteHeight + iPadding;

        //LINE 8
        oBut = new CBetBut( 1434 -oSprite.width/4, iYOffset,'bet_but8',oContainerSlot);
        oBut.addEventListenerWithParams(CMain.ON_MOUSE_UP, this._onBetLineClicked, this,8);
        this._aLinesBut[7] = oBut;

        iYOffset+= iSpriteHeight + iPadding;

        //LINE 13
        oBut = new CBetBut( 1434 -oSprite.width/4, iYOffset,'bet_but13',oContainerSlot);
        oBut.addEventListenerWithParams(CMain.ON_MOUSE_UP, this._onBetLineClicked, this,13);
        this._aLinesBut[12] = oBut;

        iYOffset+= iSpriteHeight + iPadding;

        //LINE 15
        oBut = new CBetBut( 1434 -oSprite.width/4, iYOffset,'bet_but15',oContainerSlot);
        oBut.addEventListenerWithParams(CMain.ON_MOUSE_UP, this._onBetLineClicked, this,15);
        this._aLinesBut[14] = oBut;




        var aPos = [{x:122,y:470},{x:122,y:200},{x:122,y:678},{x:122,y:126},{x:122,y:180},{x:122,y:122},{x:122,y:460},{x:122,y:198},{x:122,y:130},{x:122,y:228},
            {x:122,y:214},{x:122,y:190},{x:122,y:420},{x:122,y:126},{x:122,y:422},{x:122,y:230},{x:122,y:470},{x:122,y:148},{x:122,y:120},{x:122,y:260}];
        this._aPayline = new Array();
        for(var k = 0;k<CMain.NUM_PAYLINES;k++){
            // @ts-ignore
            var oBmp = createBitmap(CMain.s_oSpriteLibrary!!.getSprite("payline_"+(k+1)));
            oBmp.x = aPos[k].x;
            oBmp.y = aPos[k].y;
            oBmp.visible = false;

            oContainerSlot.addChild(oBmp);
            this._aPayline[k] = oBmp;
        }
    };
    private refreshMoney = (iMoney: any) => {
        this._oMoneyText.refreshText(CMain.TEXT_MONEY +": " + formatEntries(iMoney) + CMain.TEXT_CURRENCY);
    };
    private refreshBet = (iBet: any) => {
        // this._oBetCoinBut.setText(TEXT_COIN +" " + formatEntries(iBet));
    };
    private refreshTotalBet = (iTotBet: any) => {
        this._oTotalBetText.refreshText(CMain.TEXT_BET +": "+ formatEntries(iTotBet) +CMain.TEXT_CURRENCY);
    };
    private refreshNumLines = (iLines: any) => {
        this._bShowingLine = true;
        this._oAddLineBut.setText(CMain.TEXT_LINES + " " + iLines);

        for(var i=0;i<CMain.NUM_PAYLINES;i++){
            if(i<iLines){
                this._aLinesBut[i].setOn();
                this._aPayline[i].visible = true;
            }else{
                this._aLinesBut[i].setOff();
            }
        }

        setTimeout(function(){
            for(var i=0;i<CMain.NUM_PAYLINES;i++){
                CInterface.s_oInterface!!._aPayline[i].visible = false;
            }
            CInterface.s_oInterface!!._bShowingLine = false;
        },1000);
    };
    private resetWin = () => {
        this._oWinText.refreshText(CMain.TEXT_WIN+": "+ formatEntries(0) );
    };
    private refreshWinText = (iWin: any) => {
        this._oWinText.refreshText(CMain.TEXT_WIN + ": "+ formatEntries(iWin) );
    };
    private refreshFreeSpinNum = (iNum: any) => {
        this._oFreeSpinNumText.refreshText(iNum);

        if(iNum === ""){
            this._oContainerFreespin.visible = false;
            this._oContainerWinFreespin.visible = false;
        }else{
            this._oContainerFreespin.visible = true;
            this._oContainerWinFreespin.visible = true;
        }
    };
    private refreshFreeSpinAmount = (iAmount: any) => {
        if(iAmount === ""){
            this._oFreeSpinWinText.refreshText(iAmount);
        }else{
            this._oFreeSpinWinText.refreshText(formatEntries(iAmount));
        }
    };
    private showLine = (iLine: any) => {
        if(iLine > 0){
            this._aPayline[iLine-1].visible = true;
        }
    };
    private hideLine = (iLine: any) => {
        if(iLine > 0){
            this._aPayline[iLine-1].visible = false;
        }
    };
    private hideAllLines = () => {
        for(var i=0;i<CMain.NUM_PAYLINES;i++){
            this._aPayline[i].visible = false;
        }
    };
    private disableBetBut = (bDisable: any) => {
        for(var i=0;i<CMain.NUM_PAYLINES;i++){
            this._aLinesBut[i].disable(bDisable);
        }
    };
    private enableGuiButtons = () => {
        this._oSpinBut.enable();
        // this._oAutoSpinBut.enable();
        // this._oBetCoinBut.enable();
        this._oAddLineBut.enable();
        this._oInfoBut.enable();

        if(!CMain.s_bMobile){
            document.onkeyup   = this.onKeyUp;
        }
    };
    private enableSpin = (bAutoSpin: any) => {
        this._oSpinBut.enable();
        if(bAutoSpin){
            // this._oAutoSpinBut.enable();
        }

        if(!CMain.s_bMobile){
            document.onkeyup   = this.onKeyUp;
        }
    };
    private disableSpin = (bAutoSpin: any) => {
        this._oSpinBut.disable();

        if(bAutoSpin){
            // this._oAutoSpinBut.disable();
        }

        if(!CMain.s_bMobile){
            document.onkeyup   = null;
        }
    };
    private disableGuiButtons = (bAutoSpin: any, bFreespin: any) => {
        if(!CMain.s_bMobile){
            document.onkeyup   = null;
        }

        if(!bFreespin){
            if(bAutoSpin){
                this._oSpinBut.disable();
                // this._oAutoSpinBut.setText(TEXT_STOP_AUTO);
            }else{
                // this._oAutoSpinBut.disable();
                this._oSpinBut.setText(CMain.TEXT_SKIP)
            }

        }else{
            // this._oAutoSpinBut.disable();
            this.disableSpin(true);
        }


        // this._oBetCoinBut.disable();
        this._oAddLineBut.disable();
        this._oInfoBut.disable();
    };
    private setAutoSpinState = (szText: any) => {
        // this._oAutoSpinBut.setText(szText);
    };
    private setSpinState = (szText: any) => {
        this._oSpinBut.setText(szText);
    };
    private _onBetLineClicked = (iLine: any) => {
        if(this._bShowingLine){
            return;
        }

        this.refreshNumLines(iLine);

        CGame.s_oGame?.activateLines(iLine);
    };
    private _onSpin = () => {
        if(this._oSpinBut.getText() === CMain.TEXT_SKIP){
            console.log(this._oSpinBut.getText())
            CGame.s_oGame?.forceStopReel();
            this._oSpinBut.setText(CMain.TEXT_SPIN);
        }else{
            CGame.s_oGame?.onSpin();
        }

    };
    private _onAddLine = () => {
        CGame.s_oGame?.addLine();
    };
    private _onInfo = () => {
        CGame.s_oGame?.onInfoClicked();
    };
    private _onBet = () => {
        CGame.s_oGame?.changeCoinBet();
    };
    private resetFullscreenBut = () => {
        if (this._fRequestFullScreen && screenfull_IsEnabled){
            this._oButFullscreen.setActive(CMain.s_bFullscreen);
        }
    };
    private _onFullscreenRelease = () => {
        if(CMain.s_bFullscreen) {
            this._fCancelFullScreen.call(window.document);
        }else{
            this._fRequestFullScreen.call(window.document.documentElement);
        }

        sizeHandler();
    };
    private _onAudioToggle = () => {
        // Howler.mute(CMain.s_bAudioActive); // TODO Howler Audio library
        CMain.s_bAudioActive = !CMain.s_bAudioActive;
    };
    private _onExit = () => {
        this._oAreYouSurePanel.show(CMain.TEXT_ARE_SURE);
    };
    private _onExitYes = () => {
        CGame.s_oGame?.onExit();
    };
}