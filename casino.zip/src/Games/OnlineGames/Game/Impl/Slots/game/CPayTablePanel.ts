import {CGame} from "./CGame";
import {CMain} from "./CMain";
import {createBitmap} from "./ctl_utils";
import {CTLText} from "./CTLText";
import {CGfxButton} from "./CGfxButton";

export class CPayTablePanel {
    private _iCurPage: any;
    private _aNumSymbolComboText: any;
    private _aWinComboText: any;
    private _aPages: any;
    private _oCurPage: any;
    private _oButExit: any;
    private _oButArrowNext: any;
    private _oButArrowPrev: any;
    private _oContainer: any;

    constructor() {
        this._init();
    }
    private _init = () => {
        this._iCurPage = 0;
        this._aPages = new Array();

        this._oContainer = new createjs.Container();
        this._oContainer.on("click", function () {
        });
        this._oContainer.visible = false;
        CMain.s_oAttachSection.addChild(this._oContainer);

        //ATTACH PAGE 1
        var oContainerPage = new createjs.Container();
        this._oContainer.addChild(oContainerPage);

        var oBg = createBitmap(CMain.s_oSpriteLibrary!!.getSprite('paytable1'));
        oContainerPage.addChild(oBg);

        //LIST OF COMBO TEXT

        this._createPayouts(oContainerPage);

        this._aPages[0] = oContainerPage;

        //ATTACH PAGE 2
        oContainerPage = new createjs.Container();
        oContainerPage.visible = false;
        this._oContainer.addChild(oContainerPage);

        oBg = createBitmap(CMain.s_oSpriteLibrary!!.getSprite('paytable2'));
        oContainerPage.addChild(oBg);

        this._aPages[1] = oContainerPage;

        this._oCurPage = this._aPages[this._iCurPage];

        //ATTACH PAGE 3
        oContainerPage = new createjs.Container();
        oContainerPage.visible = false;
        this._oContainer.addChild(oContainerPage);

        oBg = createBitmap(CMain.s_oSpriteLibrary!!.getSprite('paytable3'));
        oContainerPage.addChild(oBg);

        var oText = new CTLText(oContainerPage,
            1000, 366, 546, 118,
            36, "center", "#fede00", CMain.FONT_GAME_1, 1,
            0, 0,
            CMain.TEXT_HELP_BONUS1,
            true, true, true,
            false);


        var oText2 = new CTLText(oContainerPage,
            1000, 544, 546, 280,
            36, "center", "#fede00", CMain.FONT_GAME_1, 1,
            0, 0,
            CMain.TEXT_HELP_BONUS2,
            true, true, true,
            false);


        this._aPages[2] = oContainerPage;

        //ATTACH PAGE 4
        oContainerPage = new createjs.Container();
        oContainerPage.visible = false;
        this._oContainer.addChild(oContainerPage);

        oBg = createBitmap(CMain.s_oSpriteLibrary!!.getSprite('paytable4'));
        oContainerPage.addChild(oBg);

        var iYPos = 400;
        for (var j = 0; j < 3; j++) {
            var _oText = new createjs.Text((j + 3) + "X  " + CMain.NUM_FREESPIN[j], "40px " + CMain.FONT_GAME_1, "#fede00");
            _oText.textAlign = "middle";
            _oText.x = CMain.CANVAS_WIDTH / 2 + 44;
            _oText.y = iYPos;
            _oText.textBaseline = "alphabetic";
            oContainerPage.addChild(_oText);

            iYPos += 42;
        }

        var oText = new CTLText(oContainerPage,
            CMain.CANVAS_WIDTH / 2 - 280, 550, 560, 280,
            56, "center", "#fede00", CMain.FONT_GAME_1, 1,
            0, 0,
            CMain.TEXT_HELP_FREESPIN,
            true, true, true,
            false);


        this._aPages[3] = oContainerPage;

        this._oCurPage = this._aPages[this._iCurPage];

        //ATTACH ARROW
        this._oButArrowNext = new CGfxButton(CMain.CANVAS_WIDTH - 270, CMain.CANVAS_HEIGHT / 2, CMain.s_oSpriteLibrary!!.getSprite('but_arrow_next'), this._oContainer);
        this._oButArrowNext.addEventListener(CMain.ON_MOUSE_UP, this._onNext, this);

        this._oButArrowPrev = new CGfxButton(270, CMain.CANVAS_HEIGHT / 2, CMain.s_oSpriteLibrary!!.getSprite('but_arrow_prev'), this._oContainer);
        this._oButArrowPrev.addEventListener(CMain.ON_MOUSE_UP, this._onPrev, this);

        var oSprite = CMain.s_oSpriteLibrary!!.getSprite('but_exit_info');
        this._oButExit = new CGfxButton(1566, 266, oSprite, this._oContainer);
        this._oButExit.addEventListener(CMain.ON_MOUSE_UP, this._onExit, this);
    };

    private unload = () => {
        return;
        this._oContainer.off("click", function () {
        });
        this._oButExit.unload();

        this._oButArrowNext.unload();
        this._oButArrowPrev.unload();

        CMain.s_oAttachSection.removeChild(this._oContainer);

        for (var i = 0; i < this._aNumSymbolComboText.length; i++) {
            this._oContainer.removeChild(this._aNumSymbolComboText[i]);
        }

        for (var j = 0; j < this._aWinComboText.length; j++) {
            this._oContainer.removeChild(this._aWinComboText[j]);
        }

    };

    private _createPayouts = (oContainerPage: any) => {
        this._aNumSymbolComboText = new Array();
        this._aWinComboText = new Array();

        var aPos = [{x: 1164, y: 744}, {x: 800, y: 744}, {x: 1290, y: 558}, {x: 940, y: 558}, {
            x: 590,
            y: 558
        }, {x: 1164, y: 374}, {x: 800, y: 374}];
        var iCurPos = 0;
        for (var i = 0; i < CMain.PAYTABLE_VALUES.length; i++) {
            var aSymbolPayouts = CMain.PAYTABLE_VALUES[i];
            do {
                var iIndex = aSymbolPayouts.indexOf(0);
                if (iIndex !== -1) {
                    aSymbolPayouts.splice(iIndex, 1);
                }

            } while (iIndex !== -1);

            var iLen = aSymbolPayouts.length;

            if (iLen === 0) {
                continue;
            }

            var iOffsetY = 40;
            if (iLen === 4) {
                iOffsetY = 32;
            }

            var iYPos = aPos[iCurPos].y;
            this._aNumSymbolComboText[i] = new Array();
            this._aWinComboText[i] = new Array();

            for (var j = 0; j < iLen; j++) {
                var oTextMult = new createjs.Text("X" + (5 - j), "40px " + CMain.FONT_GAME_1, "#ffffff");
                oTextMult.textAlign = "center";
                oTextMult.x = aPos[iCurPos].x;
                oTextMult.y = iYPos;
                oTextMult.textBaseline = "alphabetic";
                oContainerPage.addChild(oTextMult);

                this._aNumSymbolComboText[i][j] = oTextMult;

                var oText = new createjs.Text(aSymbolPayouts[iLen - j - 1], "40px " + CMain.FONT_GAME_1, "#fede00");
                oText.textAlign = "center";
                oText.x = oTextMult.x + 70;
                oText.y = oTextMult.y;
                oText.textBaseline = "alphabetic";
                oContainerPage.addChild(oText);

                this._aWinComboText[i][j] = oText;

                iYPos += iOffsetY;
            }

            iCurPos++;
        }
    };

    private _onNext = () => {
        if (this._iCurPage === this._aPages.length - 1) {
            this._iCurPage = 0;
        } else {
            this._iCurPage++;
        }


        this._oCurPage.visible = false;
        this._aPages[this._iCurPage].visible = true;
        this._oCurPage = this._aPages[this._iCurPage];
    };

    private _onPrev = () => {
        if (this._iCurPage === 0) {
            this._iCurPage = this._aPages.length - 1;
        } else {
            this._iCurPage--;
        }


        this._oCurPage.visible = false;
        this._aPages[this._iCurPage].visible = true;
        this._oCurPage = this._aPages[this._iCurPage];
    };

    private refreshButtonPos = (iNewX: any, iNewY: any) => {

    };

    private show = () => {
        this._iCurPage = 0;
        this._oCurPage.visible = false;
        this._aPages[this._iCurPage].visible = true;
        this._oCurPage = this._aPages[this._iCurPage];

        this._oContainer.visible = true;
    };

    private hide = () => {
        this._oContainer.visible = false;
    };

    private resetHighlightCombo = () => {
        for (var i = 0; i < this._aNumSymbolComboText.length; i++) {
            if (this._aNumSymbolComboText[i] !== undefined) {
                for (var j = 0; j < this._aNumSymbolComboText[i].length; j++) {
                    this._aNumSymbolComboText[i][j].color = "#ffffff";
                    this._aWinComboText[i][j].color = "#ffff00";
                    createjs.Tween.removeTweens(this._aWinComboText[i][j]);
                    this._aWinComboText[i][j].alpha = 1;
                }
            }

        }
    };

    private highlightCombo = (iSymbolValue: any, iNumCombo: any) => {

        this._aWinComboText[iSymbolValue][CMain.NUM_REELS - iNumCombo].color = "#ff9000";

        this.tweenAlpha(this._aWinComboText[iSymbolValue][CMain.NUM_REELS - iNumCombo], 0);

    };

    private tweenAlpha = (oText: any, iAlpha: any) => {
        createjs.Tween.get(oText, {loop: -1}).to({alpha: 0}, 200).to({alpha: 1}, 200);
    };

    private _onExit = () => {
        CGame.s_oGame?.hidePayTable();
    };

    private isVisible = () => {
        return this._oContainer.visible;
    };

}