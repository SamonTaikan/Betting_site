import {CMain} from "./CMain";
import {CTLText} from "./CTLText";
import {createBitmap} from "./ctl_utils";
import {CGfxButton} from "./CGfxButton";

export class CRechargePanel {
    private _oListenerBlock: any;
    private _oFade: any;
    private _oContainerPanel: any;
    private _oButYes: any;
    private _oButNo: any;
    private _oPanel: any;
    private _oContainer: any;
    private _pStartPanelPos: any;

    constructor() {
        this._init();
    }

    private _init = () => {

        this._oContainer = new createjs.Container();
        CMain.s_oStage.addChild(this._oContainer);

        this._oFade = new createjs.Shape();
        this._oListenerBlock = this._oFade.on("click", function () {
        });
        this._oFade.alpha = 0;
        this._oFade.graphics.beginFill("black").drawRect(0, 0, CMain.CANVAS_WIDTH, CMain.CANVAS_HEIGHT);
        this._oContainer.addChild(this._oFade);

        var oSpriteBg = CMain.s_oSpriteLibrary!!.getSprite('msg_box_small');

        this._oContainerPanel = new createjs.Container();
        this._oContainerPanel.x = CMain.CANVAS_WIDTH / 2;
        this._oContainerPanel.y = CMain.CANVAS_HEIGHT / 2;
        this._oContainerPanel.regX = oSpriteBg.width * 0.5;
        this._oContainerPanel.regY = oSpriteBg.height * 0.5;
        this._oContainer.addChild(this._oContainerPanel);


        this._oPanel = createBitmap(oSpriteBg);
        this._oContainerPanel.addChild(this._oPanel);


        var oTitle = new CTLText(this._oContainerPanel,
            50, 60, oSpriteBg.width - 100, 180,
            90, "center", "#fede00", CMain.FONT_GAME_1, 1,
            40, 10,
            CMain.TEXT_RECHARGE,
            true, true, true,
            false);


        var oSprite = CMain.s_oSpriteLibrary!!.getSprite('but_no');
        this._oButNo = new CGfxButton(130, 380, oSprite, this._oContainerPanel);
        this._oButNo.addEventListener(CMain.ON_MOUSE_UP, this.hide, this);

        this._oButYes = new CGfxButton(oSpriteBg.width - 130, 380, CMain.s_oSpriteLibrary!!.getSprite('but_yes'), this._oContainerPanel);
        this._oButYes.addEventListener(CMain.ON_MOUSE_UP, this._onRecharge, this);

        this.disableButtons();

        this._oContainer.visible = true;
        this._oContainerPanel.scale = 0;
        this._oFade.alpha = 0;
        const _oThis = this;
        createjs.Tween.get(this._oFade).to({alpha: 0.7}, 300, createjs.Ease.quartOut);
        createjs.Tween.get(this._oContainerPanel).to({scale: 1}, 1000, createjs.Ease.elasticOut).call(function () {
            _oThis.enableButtons();
        });
    };
    private unload = () => {
        this._oButNo.unload();
        this._oButYes.unload();
        this._oFade.off("click", this._oListenerBlock);

        CMain.s_oStage.removeChild(this._oContainer);

    };
    private disableButtons = () => {
        this._oButYes.disable();
        this._oButNo.disable();
    };
    private enableButtons = () => {
        this._oButNo.enable();
        this._oButYes.enable();
    };
    private hide = () => {
        var oParent = this;

        createjs.Tween.get(this._oFade).to({alpha: 0}, 500, createjs.Ease.quartOut)
        createjs.Tween.get(this._oContainerPanel).to({scale: 0}, 500, createjs.Ease.backIn).call(function () {
            oParent.unload();
        });
    };

    private _onRecharge = () => {
        const _oThis = this;
        _oThis.hide();
        // $(s_oMain).trigger("recharge"); // TODO JQuery Select
        console.log('JQUERY LINE 111')
    };

}

