import React, { Component, useEffect, useRef } from "react";

import "./Slots.scss";
import DiceTabs from "../Dice/DiceTabs/DiceTabs";
import { currencies } from "../../../../../Utilities/Currencies";
import { axiosGet } from "../../../../../Utilities/HTTPClient";
import { CMain } from "./game/CMain";

type SlotsState = {
  payLines: number;
  autoing?: boolean;
  spinning?: boolean;
  wagerId?: number;
  wagerAmount: number;
  stopOnMultiplier?: number;
  skipUpdate?: boolean;
  participants: Array<any>;
};

const Canvas = (props: any) => {
  const slotsCanvas = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const render = () => {
      new CMain({
        start_credit: 100, //STARTING CREDIT WHEN PLAYER PLAYS THE FIRST TIME
        min_reel_loop: 0, //NUMBER OF REEL LOOPS BEFORE SLOT STOPS
        reel_delay: 6, //NUMBER OF FRAMES TO DELAY THE REELS THAT START AFTER THE FIRST ONE
        time_show_win: 2000, //DURATION IN MILLISECONDS OF THE WINNING COMBO SHOWING
        time_show_all_wins: 2000, //DURATION IN MILLISECONDS OF ALL WINNING COMBO
        restart_credit: false, //IF YOU WANT TO RESTART USER CREDIT WITH DEFAULT VALUE SET THIS TO TRUE
        check_orientation: false, //SET TO FALSE IF YOU DON'T WANT TO SHOW ORIENTATION ALERT ON MOBILE DEVICES
        audio_enable_on_startup: false, //ENABLE/DISABLE AUDIO WHEN GAME STARTS
        show_credits: true, //SHOW CREDITS ON/OFF
        num_spin_for_ads: 20, //NUMBER OF TURNS PLAYED BEFORE AD SHOWING //
        canvasRef: slotsCanvas,

        //////// THIS FEATURE  IS ACTIVATED ONLY WITH CTL ARCADE PLUGIN.///////////////////////////
        /////////////////// YOU CAN GET IT AT: ////////////////////////////////////////////////////
        // http://codecanyon.net/item/ctl-arcade-wordpress-plugin/13856421
      });
    };
    const animationFrameId = window.requestAnimationFrame(render);

    console.log("slotsCanvas:::", slotsCanvas)

    return () => {
      window.cancelAnimationFrame(animationFrameId);
    };
  }, [slotsCanvas.current]);

  {
    return (
      <canvas
        ref={slotsCanvas}
        id="canvas"
        className="ani_hack"
        style={{
          top: "0",
          width: "100%",
          height: "100%",
          position:'absolute',
        }}
        width="1920"
        height="1080"
      />
    );
  }
};

class Slots extends Component<any, SlotsState> {
  private slotsRef?: React.Ref<any>;
  private autoInterval?: NodeJS.Timer;

  constructor(props: any) {
    super(props);
    this.state = {
      payLines: 1,
      wagerAmount: 0.02,
      participants: [],
    };
  }

  wager = async (amount: number, payLineCount: number) =>
    axiosGet(
      `/game/slots/wager?&wager_amount=${amount}&wager_parameters=${payLineCount}`
    );

  render() {
    return (
      <div className="DiceGame">
        <ul className="CrashGameContent">
          <li className="Small">
            <div className="DiceGame-GameTabs">
              <DiceTabs>
                {/*@ts-ignore*/}
                <div label="Manual">{this.renderCrashOptions(0)}</div>
                {/*@ts-ignore*/}
                <div label="Auto">{this.renderCrashOptions(1)}</div>
              </DiceTabs>
            </div>
          </li>
          <li className="Large" style={{ padding: "2%", position: "relative" }}>
              <Canvas ref={this.slotsRef} timer={1000} />
          </li>
        </ul>
        <div className="GameContentBar"></div>
      </div>
    );
  }

  renderCrashOptions(type: number) {
    let buttonState = "";
    return (
      <div>
        {/*@ts-ignore*/}
        <div width="730" className="CrashGameCanvas">
          <div className="CanvasRow">
            <div className="RowHeader">
              <div className="Left">Bet Amount</div>
              <div className="Right">
                {currencies.get(this.props.currency)!!.symbol +
                  this.state.wagerAmount.toFixed(2)}
              </div>
            </div>
            <div className="RowHeader">
              <div className="CanvasField">
                <div className="AmountField">
                  <div className="Value">
                    <div className="ValueIcon">
                      {
                        <input
                          type="number"
                          step=".01"
                          min={0}
                          max={1000}
                          key={this.state.wagerAmount}
                          onChange={(e: any) => {
                            this.setState({
                              wagerAmount: Number(e.target.value),
                              skipUpdate: true,
                            });
                          }}
                          defaultValue={this.state.wagerAmount.toFixed(2)}
                        />
                      }
                    </div>
                    <img
                      src={`/assets/currencies/${
                        currencies.get(this.props.currency)!!.img
                      }`}
                      className="Currency"
                    />
                  </div>
                  <div
                    className="Action"
                    onClick={() => {
                      if (this.state.wagerAmount > 0) {
                        this.setState({
                          wagerAmount: this.state.wagerAmount / 2,
                        });
                      }
                    }}
                  >
                    ½
                  </div>
                  <a className="ValueDivider"></a>
                  <div
                    className="Action"
                    onClick={() => {
                      if (
                        this.state.wagerAmount > 0 &&
                        this.state.wagerAmount * 2 < this.props.balance
                      ) {
                        this.setState({
                          wagerAmount: this.state.wagerAmount * 2,
                        });
                      }
                    }}
                  >
                    2x
                  </div>
                  <a className="ValueDivider"></a>
                  <div
                    className="Action"
                    onClick={() => {
                      if (this.props.balance > 0) {
                        this.setState({ wagerAmount: this.props.balance });
                      }
                    }}
                  >
                    max
                  </div>
                </div>
              </div>
            </div>
          </div>
          {type == 1 ? this.getAutomaticForm() : <div />}
          <div className="CanvasRow">
            <div className="RollDiceCanvas">
              <button
                className={buttonState}
                id="spin_butt"
                onClick={() => {
                  if (this.state.autoing) {
                    if (this.autoInterval) {
                      clearInterval(this.autoInterval);
                    }
                    this.setState({ spinning: false, autoing: false });
                    return;
                  }
                  if (this.state.spinning) return;
                  this.setState({ spinning: true }, () => {
                    if (type == 1) {
                      this.setState({ autoing: true }, () => {
                        this.autoInterval = setInterval(() => {
                          //TODO
                        }, 500);
                      });
                    } else {
                      this.placeBet();
                    }
                  });
                }}
              >
                Spin
              </button>
            </div>
          </div>
          <div className="CanvasRow">
            <div className="CrashParticipants">
              <ul className="Headers">
                <li>Name</li>
                <li>Amount</li>
                <li>Multiplier</li>
              </ul>
              {this.state.participants.map((p: any, id) => {
                return (
                  <ul key={id}>
                    <li>{p.name}</li>
                    <li>
                      <span className="dRrTFD positive">
                        <img
                          src={`/assets/currencies/${
                            currencies.get(this.props.currency)!!.img
                          }`}
                          className="Currency"
                        />
                        <span className="ixoRjG">{p.amount}</span>
                      </span>
                    </li>
                    <li>
                      <span className="ixoRjG">
                        {p.multiplier
                          ? Number(p.multiplier).toFixed(2) + "x"
                          : "-"}
                      </span>
                    </li>
                  </ul>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    );
  }

  placeBet() {
    this.wager(this.state.wagerAmount, this.state.payLines).then((r) => {
      if (r.result == -1) {
        window.alert("Bet failed");
      }
    });
  }

  getAutomaticForm() {
    return (
      <div className="CanvasRow">
        <div className="RowHeader">
          <div className="Left">Stop on Multiplier</div>
        </div>
        <div className="RowHeader">
          <div className="CanvasField">
            <div className="AmountField">
              <div className="IconValue">
                <div className="ProfitValue">
                  <input
                    type="number"
                    step="0.01"
                    min={1.1}
                    max={100}
                    onChange={(e) =>
                      this.setState({
                        stopOnMultiplier: Number(e.target.value),
                      })
                    }
                    defaultValue={this.state.stopOnMultiplier}
                  />
                </div>
                <div className="ProfitCurrency">
                  <img
                    src={`/assets/currencies/${
                      currencies.get(this.props.currency)!!.img
                    }`}
                    className="Currency"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Slots;
