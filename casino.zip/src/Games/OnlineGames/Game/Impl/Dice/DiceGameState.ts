export type DiceGameState = {
    balance: number,
    rollOver: boolean,
    skipUpdate?: boolean,
    rolling: boolean,
    rollThreshold: number,
    multiplier: number,
    winChance: number,
    w: number,
    wagerAmount: number,
    onWinReset: boolean,
    onWinIncreaseBy: number,
    onLossReset: boolean,
    onLossIncreaseBy: number,
    stopOnLoss: number,
    stopOnWin: number,
    sessionProfit: number,
    previousResult: number | null,
    rollHistory: Array<any>,
    earnings: number
    autoing: boolean
    startedAutoValue: number
    wonPrevious: boolean
    wagered: number
    wager: number
    profit: number
    wins: number | undefined
    losses: number | undefined
    winningsData: Array<any>
    lossesData: Array<any>
}