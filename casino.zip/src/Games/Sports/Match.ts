export type Match = {
    matchId: string
    matchTitle: string
    odds: Array<string>
    selected?: boolean
}