export interface GameInformationResponse {
    id: number,
    title: string
}