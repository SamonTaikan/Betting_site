export interface BetOverviewResponse {
    id: string,
    username: string,
    time: Date,
    game: number,
    currency: string,
    value: number,
    clientSeed: string,
    serverSeed: string,
    nonce: number,
    earnings: number,
    wager: number,
    multiplier: number
}