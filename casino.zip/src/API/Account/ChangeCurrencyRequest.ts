export type ChangeCurrencyRequest = {
    currency: string
}