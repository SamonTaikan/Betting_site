export interface AccountSettingsResponse {
    emailAddress: string
    phoneNumber: string
}