export type Offer = {
    title: string
    prize: string
    splash: string
    action: string
    url: string
    terms: string
}