import {currencies} from "../../Utilities/Currencies";
import {AccountBalance} from "../../API/Account/AccountInformationResponse";
import {safelyNavigateToPage} from "../../Utilities/Tracking";
import React from "react";
import {ChangeCurrencyRequest} from "../../API/Account/ChangeCurrencyRequest";
import {axiosPost} from "../../Utilities/HTTPClient";

export const setCurrency = async (body: ChangeCurrencyRequest) => axiosPost(`/admin/auth/set-primary-currency`, body)

export const currencyBar = (
    balances: AccountBalance[],
    balance: number,
    currency: string,
    dropdownEnabled: boolean,
    pageLoadedAt: Date,
    toggleDropdown: () => void,
    setCurrency: (balance: AccountBalance) => void,
    large?: boolean
): JSX.Element => {
    return (<ul className={`MainHeaderUser ${large ? 'largeBar' : ''}`}>
    <li key={-10} className={`MainHeaderUserLoggedIn ${!dropdownEnabled ? 'fixedHeight' : ''}`}>
            <div className="CurrentBalance" onClick={() => toggleDropdown()}>
                <img height={15} src={`/assets/currencies/${currencies.get(currency)!!.img}`} className="Currency" />
                <span>{currencies.get(currency)!!.symbol} {currencies.get(currency)!!.format(balance)}</span>

                <div className="BalancesDropdown">
                    <img width={15} src="/assets/landing/dropdown.svg" />
                </div>
            </div>
            <ul className={dropdownEnabled ? "Currencies" : "Currencies CurrentsToggled"}>
                {
                    balances ? balances.map((balance: AccountBalance, index: number) => {
                        return (<li key={index} className="CurrentBalance" onClick={() => setCurrency(balance)}>
                            <img height={16} src={`/assets/currencies/${currencies.get(balance.currency)!!.img}`} className="Currency" />
                            <span>{currencies.get(balance.currency)!!.symbol} {currencies.get(balance.currency)!!.formatNoLabel(balance.balance)}</span>
                        </li>)
                    }) : <p/>
                }
            </ul>
        </li>
        <li key={-11} className="WalletButton" onClick={() => safelyNavigateToPage(pageLoadedAt, "/account") }>
            <a>Wallet</a>
        </li>
    </ul>)
}