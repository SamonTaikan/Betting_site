export type CarouselItem = {
    splash: string
    url: string
}