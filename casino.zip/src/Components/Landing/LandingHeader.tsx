import React, {Component} from 'react';
import {currencies, numberWithCommas} from "../../Utilities/Currencies";
import {axiosPost} from "../../Utilities/HTTPClient";
import {ChangeCurrencyRequest} from "../../API/Account/ChangeCurrencyRequest";
import {AccountBalance} from "../../API/Account/AccountInformationResponse";
import {safelyNavigateToPage} from "../../Utilities/Tracking";
import {currencyBar, setCurrency} from "../Header/currencyBar";

type HeaderProps = {
    pageLoadedAt: Date
    openLoginModal: any
    username?: string
    balance: number
    balances?: Array<AccountBalance>
    currency: string
    online: number
}

type HeaderState = {
    currenciesDropdown: boolean
}

class LandingHeader extends Component<HeaderProps, HeaderState> {

    constructor(props: HeaderProps) {
        super(props);
        this.state = {
            currenciesDropdown: false
        }
    }

    getAccountBar() {
        if (this.props.username) {
            return currencyBar(
                this.props.balances!!,
                this.props.balance,
                this.props.currency,
                this.state.currenciesDropdown,
                this.props.pageLoadedAt,
                () => this.setState({currenciesDropdown: !this.state.currenciesDropdown}),
                (balance: AccountBalance) => setCurrency({currency: balance.currency}).then(r => {
                    window.location.reload()
                }).catch(e => {
                    window.location.reload()
                })
            )
        }
        return (<div className="MainHeaderUser">
            <button className="LoginButton" onClick={() => this.props.openLoginModal()}>
                {/*<i className="fa-sharp fa-solid fa-right-to-bracket"></i>*/}
                <img width={20} src="/assets/landing/sign-in.svg" />
                Sign In</button>
        </div>)
    }

    render() {
        return (
            <header className="Landing-header">
                <div className="LandingUserBar">
                    <div className="Logospace">
                        <img src="/assets/logo.png"/>
                    </div>
                    <div className="Promotions">
                        <ul>
                            <li className="First">
                                {/*<i className="fa-solid fa-wifi members-online fill-gradient-radial2"></i>*/}
                                <img width={30} className="members-online" src="/assets/landing/wifi.svg" />
                                <span>{numberWithCommas(this.props.online)}</span>
                                <div className="VerticalRule" style={{height: '25px'}}/>
                            </li>
                            <li>
                                {/*<i className="fa-solid fa-shield-check"></i>*/}
                                <img width={20} src="/assets/landing/shield.svg" />
                                <span onClick={() => safelyNavigateToPage(this.props.pageLoadedAt, "/safer-gambling")}>Safer Gambling</span>
                            </li>
                            <li>
                                {/*<i className="fa-solid fa-gem"></i>*/}
                                <img width={20} src="/assets/landing/diamond.svg" />
                                <span onClick={() => safelyNavigateToPage(this.props.pageLoadedAt, "/")}>Buy & Sell GP</span>
                            </li>
                        </ul>
                    </div>
                    <div className="Userbar">
                        {this.getAccountBar()}
                    </div>
                </div>
                <div className="LandingNavBar">
                    <div className="Feedfilter">
                        <div className="feed-filter-link">
                            <div className="feed-filter-link__icon Active">
                                <img width={20} src="/assets/landing/crown.svg" />
                            </div>
                        </div>

                    </div>
                    <div className="Navigation">
                        <a className="landing-nav-link FirstLink" href="/register">
                            <div className="landing-nav-link__icon">
                                {/*<i className="fa-solid fa-user"></i>*/}
                                <div className="NavLink">
                                    <img width={20} src="/assets/landing/register.svg" />
                                </div>
                                <div className="NavLinkHover">
                                    <img width={20} src="/assets/landing/register_hover.svg" />
                                </div>
                            </div>
                            <div className="landing-nav-link__count">
                                Register
                            </div>
                        </a>
                        <a className="landing-nav-link SecondLink" href="/games">
                            <div className="landing-nav-link__icon">
                                {/*<i className="fa-solid fa-gamepad-modern"></i>*/}
                                <div className="NavLink">
                                    <img width={20} src="/assets/landing/game.svg" />
                                </div>
                                <div className="NavLinkHover">
                                    <img width={20} src="/assets/landing/game_hover.svg" />
                                </div>
                            </div>
                            <div className="landing-nav-link__count">
                                Games
                            </div>
                        </a>
                        <a className="landing-nav-link ThirdLink" href="/games">
                            <div className="landing-nav-link__icon">
                                {/*<i className="fa-solid fa-bolt-lightning"></i>*/}
                                <div className="NavLink">
                                    <img width={20} src="/assets/landing/lightning.svg" />
                                </div>
                                <div className="NavLinkHover">
                                    <img width={20} src="/assets/landing/lightning_hover.svg" />
                                </div>
                            </div>
                            <div className="landing-nav-link__count">
                                Promotions
                            </div>
                        </a>
                        <a className="landing-nav-link FourthLink" href="/games">
                            <div className="landing-nav-link__icon">
                                {/*<i className="fa-solid fa-play"></i>*/}
                                <div className="NavLink">
                                    <img width={20} style={{padding: '2.5px'}} src="/assets/landing/play.svg" />
                                </div>
                                <div className="NavLinkHover">
                                    <img width={20} style={{padding: '2.5px'}} src="/assets/landing/play_hover.svg" />
                                </div>
                            </div>
                            <div className="landing-nav-link__count">
                                Livestreams
                            </div>
                        </a>
                    </div>
                </div>
            </header>
        );
    }
}

export default LandingHeader;