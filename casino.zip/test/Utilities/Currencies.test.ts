import {toRuneScapeFormatFromDecimal, toRuneScapeFormatFromExact} from "@/Utilities/Currencies";

test('Formats RSGP values correctly.', () => {
    expect(toRuneScapeFormatFromExact(10_000_000_032)).toBe("10B");
    expect(toRuneScapeFormatFromExact(1_000_030_044)).toBe("1B");
    expect(toRuneScapeFormatFromExact(100_020_136)).toBe("100M");
    expect(toRuneScapeFormatFromExact(100_200_234)).toBe("100M");
    expect(toRuneScapeFormatFromExact(11_700_745)).toBe("11M");
    expect(toRuneScapeFormatFromExact(9_700_670)).toBe("9.7M");
    expect(toRuneScapeFormatFromExact(768_930)).toBe("768K");
});

test('Formats decimal RSGP values correctly.', () => {
    expect(toRuneScapeFormatFromDecimal(0.01)).toBe("10K");
    expect(toRuneScapeFormatFromDecimal(0.31)).toBe("310K");
    expect(toRuneScapeFormatFromDecimal(10.00)).toBe("10M");
});